"""Wiring only: run options, selection of what runs, shared fixtures, prerequisites, summary.

Run-time inputs:  --system  --subsystem  --component  --suite  (and --env)
What runs = cases in the chosen suite
            x components in the run's scope AND in the case's (Applicable - Excluded)
            (cases with Applicable "n/a" run once, unless the run is narrowed to components)
"""
from __future__ import annotations

import json
from collections import defaultdict
from pathlib import Path
from types import SimpleNamespace

import pytest

from framework import reporting
from framework.connections import client_factory, pinned_swaggers
from framework.case_reader import SUITES, TestDataError, read_workbook
from framework.component_selector import select
from framework.flows import CaseRun
from framework.record_source import RecordSource
from framework.request_builder import RequestBuilder
from framework.result_checker import expected_kind
from framework.settings import ROOT, ConfigError, Settings
from framework.swagger import Swagger, UnknownEndpoint
from framework.services import SERVICE_CLASSES, Services, known_endpoints
from framework.vehicle_sample import VehicleSample


# ---------------- run-time inputs ----------------
def pytest_addoption(parser):
    g = parser.getgroup("servio")
    g.addoption("--env", default=None, help="environment from config/settings.yaml")
    g.addoption("--system", default=None, help="e.g. fleet_rul")
    g.addoption("--subsystem", default=None, help="e.g. cooling")
    g.addoption("--component", default=None, help="e.g. radiator")
    g.addoption("--suite", default=None, help="Smoke, Sanity or Regression")
    g.addoption("--vehicle-sample", type=int, default=None,
                help="per-vehicle cases check at most N vehicles (0 = every vehicle)")
    g.addoption("--vehicle-seed", type=int, default=None, help="repeat a previous vehicle sample")
    g.addoption("--headed", action="store_true", help="UI cases: show the browser")


def pytest_configure(config):
    config.addinivalue_line("markers", "case(tc_id): the TC-ID (Test Cases sheet) this test implements")
    try:
        settings = Settings(config.getoption("--env"))
        cases = read_workbook(settings.excel)
        scope = settings.components_in_scope(config.getoption("--system"),
                                             config.getoption("--subsystem"),
                                             config.getoption("--component"))
        suite = config.getoption("--suite")
        if suite and suite.capitalize() not in SUITES:
            raise ConfigError(f"--suite '{suite}' is not one of {SUITES}")
        swaggers = pinned_swaggers(settings)
        # Every service endpoint must exist in its API's pinned Swagger, every MCP tool in the pinned tool list.
        endpoints = known_endpoints()
        for key, cls in SERVICE_CLASSES.items():
            if cls.API not in settings.apis:
                raise ConfigError(f"service '{key}' belongs to API '{cls.API}', which is not under apis: in settings.yaml")
            for name, (method, path) in cls.ENDPOINTS.items():
                if cls.API in swaggers:
                    swaggers[cls.API].check(method, path, where=f"service '{key}.{name}'")
            tools_file = settings.apis[cls.API].tools_file
            if getattr(cls, "TOOLS", None) and tools_file:
                pinned = {t["name"] for t in json.loads(tools_file.read_text())["tools"]}
                for tool in set(cls.TOOLS) - pinned:
                    raise ConfigError(f"service '{key}' calls MCP tool '{tool}', which is not in {tools_file.name}")
        file_backed = {s["endpoint"] for s in settings.record_sources.values() if s["type"] == "file"}
        api_backed = {s["endpoint"] for s in settings.record_sources.values() if s["type"] == "api"}
        # Fail fast: check every word in the Test Cases and Test Data sheets, and every API path, before any call is made.
        known = list(settings.components)
        for path in api_backed:
            if not any(p == path for (_, p) in endpoints):
                raise ConfigError(f"record source endpoint {path} is type 'api' but no service covers it")
        for case in cases.values():
            select(case, known, known)
            for method, path in case.calls:
                if path in file_backed:
                    continue
                if (method, path) not in endpoints:
                    raise TestDataError(f"{case.tc_id} API: {method} {path} is not covered by any service "
                                        f"in framework/services/ (add it to the service for its Swagger tag)")
            for row in case.rows:
                expected_kind(row.expected_result)
                if row.component and row.component not in known:
                    raise TestDataError(f"Test Data - Components {case.tc_id} {row.row}: unknown component "
                                        f"'{row.component}'. Known: {sorted(known)}")
    except (ConfigError, TestDataError, UnknownEndpoint) as e:
        raise pytest.UsageError(str(e)) from None
    narrowed = any(config.getoption(o) for o in ("--system", "--subsystem", "--component"))
    config._servio = SimpleNamespace(settings=settings, cases=cases, scope=scope, swaggers=swaggers, narrowed=narrowed,
                                     suite=suite.capitalize() if suite else None)


# ---------------- what runs ----------------
def pytest_generate_tests(metafunc):
    marker = metafunc.definition.get_closest_marker("case")
    if marker is None or "run" not in metafunc.fixturenames:
        return
    ctx = metafunc.config._servio
    tc_id = marker.args[0]
    if tc_id not in ctx.cases:
        raise pytest.UsageError(f"{metafunc.function.__name__} implements {tc_id}, which is not in the Test Cases sheet")
    case = ctx.cases[tc_id]
    params = []
    # Runs that cannot run still go through the fixtures (labelled in the report), then skip with their reason.
    if not case.ready:
        reason = case.status if case.status.upper().startswith("BLOCKED") else f"BLOCKED: {case.status}"
        params.append(pytest.param(CaseRun(case, skip=reason), id=f"{tc_id}|blocked"))
    else:
        components = select(case, list(ctx.settings.components), ctx.scope, ctx.narrowed)
        if not components:
            params.append(pytest.param(CaseRun(case, skip="NOT APPLICABLE: no component left after "
                                                          "Applicable/Excluded and run scope"), id=f"{tc_id}|not-applicable"))
        for name in components:
            profile = ctx.settings.components[name] if name else None
            label = f"{tc_id}|{name}" if name else tc_id
            if case.category == "Send & Verify":
                rows = case.rows_for(name)
                if not rows:
                    params.append(pytest.param(CaseRun(case, profile, skip=f"BLOCKED: no test data"
                                                       f"{' for ' + name if name else ''}"), id=f"{label}|no-data"))
                params += [pytest.param(CaseRun(case, profile, row), id=f"{label}|{row.row}")
                           for row in rows]
            else:
                params.append(pytest.param(CaseRun(case, profile), id=label))
    reporting.title_from_run(metafunc.function)
    metafunc.parametrize("run", params)


def pytest_collection_modifyitems(config, items):
    suite = config._servio.suite
    if not suite:
        return
    keep, drop = [], []
    for item in items:
        m = item.get_closest_marker("case")
        in_suite = m is None or config._servio.cases[m.args[0]].suite == suite
        (keep if in_suite else drop).append(item)
    if drop:
        config.hook.pytest_deselected(items=drop)
        items[:] = keep


# ---------------- shared pieces ----------------
@pytest.fixture(scope="session")
def settings(pytestconfig) -> Settings:
    return pytestconfig._servio.settings


@pytest.fixture(scope="session")
def client_for(settings, pytestconfig):
    """API name -> its client (framework/connections.py). Logs in on its first call if the API needs a login."""
    return client_factory(settings, pytestconfig._servio.swaggers)


@pytest.fixture(scope="session")
def services(client_for) -> Services:
    return Services(client_for)


@pytest.fixture(scope="session")
def builder() -> RequestBuilder:
    return RequestBuilder()


@pytest.fixture(scope="session")
def vehicle_sample(pytestconfig, settings) -> VehicleSample:
    size = pytestconfig.getoption("--vehicle-sample")
    if size is None:
        size = settings.vehicle_sample_size
    vs = VehicleSample(size or None, pytestconfig.getoption("--vehicle-seed"))
    pytestconfig._servio.vehicle_sample = vs
    return vs


@pytest.fixture(scope="session")
def records(services, settings) -> RecordSource:
    return RecordSource(services, settings.record_sources)


@pytest.fixture(scope="session")
def features(services):
    """Mandatory/optional lists from the features API, fetched once per component."""
    cache = {}

    def get(component: str) -> dict:
        if component not in cache:
            resp = services.prediction.features(component)
            if resp.status != 200:
                pytest.fail(f"Prerequisite failed: features API for {component} returned {resp}", pytrace=False)
            cache[component] = resp.body
        return cache[component]
    return get


@pytest.fixture(scope="session")
def baseline(services, builder):
    """Response to the unchanged full request, sent once per API path and component (TC-01)."""
    cache = {}

    def get(path: str, component: str):
        key = (path, component)
        if key not in cache:
            cache[key] = services.call("POST", path, builder.full_request(path, component), component=component)
            if cache[key].status != 200:
                pytest.fail(f"Prerequisite failed: full request to {path} for {component} returned "
                            f"{cache[key]}", pytrace=False)
        return cache[key]
    return get


@pytest.fixture(scope="session")
def aggregates_ready(services, settings):
    """Aggregation prerequisite: refresh the cached vehicle profiles, then wait until the API says it is ready."""
    import time
    resp = services.aggregation.refresh()
    if resp.status != 200:
        pytest.fail(f"Prerequisite failed: GET /api/aggregate/fleet/refresh returned {resp}", pytrace=False)
    deadline = time.monotonic() + settings.flows["aggregation"]["ready_wait_seconds"]
    while True:
        ready = services.system.ready()
        if ready.status == 200 and isinstance(ready.body, dict) and ready.body.get("ready") is True:
            return True
        if time.monotonic() > deadline:
            pytest.fail(f"Prerequisite failed: /api/ready not ready after refresh - last {ready}", pytrace=False)
        time.sleep(2)


# ---------------- UI (U- cases) ----------------
@pytest.fixture(scope="session")
def browser(pytestconfig):
    """One browser for the run. Playwright is imported here, so runs without UI cases do not need it."""
    from playwright.sync_api import sync_playwright
    with sync_playwright() as pw:
        b = pw.chromium.launch(headless=not pytestconfig.getoption("--headed"))
        yield b
        b.close()


@pytest.fixture
def page(browser, request):
    """A fresh browser context per test (no cookies shared). On failure a screenshot goes to reports/screenshots/."""
    context = browser.new_context(viewport={"width": 1600, "height": 900})
    pg = context.new_page()
    yield pg
    rep = getattr(request.node, "rep_call", None)
    if rep is not None and rep.failed:
        out = ROOT / "reports" / "screenshots"
        out.mkdir(parents=True, exist_ok=True)
        name = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in request.node.name)
        shot = pg.screenshot(path=str(out / f"{name}.png"), full_page=True)
        reporting.attach_png("Screen at failure", shot)
    context.close()


@pytest.fixture
def ui_base_url(settings) -> str:
    return settings.apis["fleet_rul"].base_url


@pytest.fixture
def logged_in_page(page, ui_base_url):
    """Logged in through the login page as the test user (SERVIO_EMAIL / SERVIO_PASSWORD)."""
    from framework.auth import credentials
    from framework.pages import LoginPage
    LoginPage(page, ui_base_url).open().log_in(*credentials())
    return page


# ---------------- common prerequisites ----------------
@pytest.fixture(scope="session")
def _registry_text(services) -> str:
    resp = services.system.health()
    if resp.status != 200:
        pytest.exit(f"Prerequisite failed: API is not up - GET /health returned {resp}", returncode=3)
    reg = services.system.registry()
    if reg.status != 200:
        pytest.exit(f"Prerequisite failed: GET /api/registry returned {reg}", returncode=3)
    return reg.text


@pytest.fixture(autouse=True)
def _component_registered(request):
    run = request.node.callspec.params.get("run") if hasattr(request.node, "callspec") else None
    if run is None or run.component is None or run.skip:
        return
    if f'"{run.component.name}"' not in request.getfixturevalue("_registry_text"):
        pytest.skip(f"BLOCKED: {run.component.name} is not listed in GET /api/registry")


# ---------------- Allure report ----------------
# Report area per TC-ID prefix (the prefix is the naming convention of the Test Cases sheet).
AREAS = {"TC": "Fleet RUL model", "H": "Handover (model to booking)", "W": "Workflows",
         "A": "Aggregation", "U": "UI", "R": "RUL accuracy"}


@pytest.fixture(autouse=True)
def _report_labels_and_skips(request):
    """Every test carries its workbook labels in the Allure report (framework/reporting.py)."""
    run = request.node.callspec.params.get("run") if hasattr(request.node, "callspec") else None
    if run is not None:
        reporting.label_case(AREAS.get(run.case.tc_id.split("-")[0], "Other"), run.case,
                             run.component.name if run.component else None, run.row, str(run))
        if run.skip:
            pytest.skip(run.skip)
    else:
        reporting.label_framework_check(request.node.module.__name__.split(".")[-1])


@pytest.hookimpl(tryfirst=True)
def pytest_runtest_call(item):
    run = item.callspec.params.get("run") if hasattr(item, "callspec") else None
    if run is not None:
        reporting.describe(run.case, run.row)


def pytest_sessionfinish(session):
    """Run facts and failure categories for the Allure report (only when it is being written)."""
    out = session.config.getoption("allure_report_dir", default=None)
    ctx = getattr(session.config, "_servio", None)
    if not out or ctx is None:
        return
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    s = ctx.settings
    facts = {"Environment": s.env, "Workbook": s.excel.name, **{f"API {n}": a.base_url for n, a in s.apis.items()},
             **{f"Pinned {n}": (a.swagger_file or a.tools_file).name for n, a in s.apis.items() if a.swagger_file or a.tools_file}}
    (out / "environment.properties").write_text("\n".join(f"{k}={v}" for k, v in facts.items()) + "\n")
    (out / "categories.json").write_text(json.dumps([
        {"name": "Prerequisite failed (environment, credentials, data)", "matchedStatuses": ["failed", "broken"],
         "messageRegex": ".*Prerequisite failed.*"},
        {"name": "Blocked (cannot be tested now - not a defect)", "matchedStatuses": ["skipped"],
         "messageRegex": ".*BLOCKED.*"},
        {"name": "Not applicable", "matchedStatuses": ["skipped"], "messageRegex": ".*NOT APPLICABLE.*"},
        {"name": "Product defects", "matchedStatuses": ["failed"]},
        {"name": "Test errors (code or test data)", "matchedStatuses": ["broken"]},
    ], indent=2))


# ---------------- summary: one line per TC-ID ----------------
_RESULTS: dict[str, dict[str, int]] = defaultdict(lambda: defaultdict(int))


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    if rep.when == "call":
        item.rep_call = rep                 # lets the page fixture take a screenshot on failure
    m = item.get_closest_marker("case")
    if not m:
        return
    r = _RESULTS[m.args[0]]
    if rep.when == "call" and not rep.skipped:
        r["passed" if rep.passed else "failed"] += 1
    elif rep.when in ("setup", "call") and rep.skipped:
        reason = str(rep.longrepr[-1]) if isinstance(rep.longrepr, tuple) else ""
        r["not applicable" if "NOT APPLICABLE" in reason else "blocked"] += 1
    elif rep.when == "setup" and rep.failed:
        r["failed"] += 1


def pytest_terminal_summary(terminalreporter, config):
    if not _RESULTS:
        return
    tr = terminalreporter
    vs = getattr(config._servio, "vehicle_sample", None)
    if vs is not None:
        tr.section("Vehicle sample")
        tr.write_line("every vehicle" if vs.size is None else
                      f"up to {vs.size} vehicles per component, seed {vs.seed} "
                      f"(repeat with --vehicle-seed {vs.seed})")
    tr.section("Result by test case")
    tr.write_line(f"{'TC-ID':<8}{'Result':<16}{'Passed':>7}{'Failed':>7}{'Blocked':>8}{'N/A':>5}")
    for tc in sorted(_RESULTS):
        r = _RESULTS[tc]
        verdict = ("FAIL" if r["failed"] else "PASS" if r["passed"] and not r["blocked"]
                   else "PARTIAL" if r["passed"] else "BLOCKED" if r["blocked"] else "NOT APPLICABLE")
        tr.write_line(f"{tc:<8}{verdict:<16}{r['passed']:>7}{r['failed']:>7}{r['blocked']:>8}{r['not applicable']:>5}")
