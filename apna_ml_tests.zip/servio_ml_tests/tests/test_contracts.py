"""Has an API changed since it was pinned? (Not a test case of the workbook - a check on the pins.)

The Fleet RUL API added endpoints without changing its version number, so the version cannot be
trusted: the live description is compared with the pinned copy instead. On a difference: download
the new description, save it as a new dated file, point config/settings.yaml at it.
"""
import json


def _operations(doc: dict) -> set[tuple[str, str]]:
    return {(m.upper(), p) for p, methods in doc.get("paths", {}).items() for m in methods
            if m in ("get", "post", "put", "patch", "delete")}


def test_fleet_rul_api_matches_pinned_swagger(client_for, settings):
    api = settings.apis["fleet_rul"]
    live = client_for("fleet_rul").get_unchecked("/openapi.json")
    assert live.status == 200, f"GET /openapi.json returned {live}"
    pinned, now = _operations(json.loads(api.swagger_file.read_text())), _operations(live.body)
    added, removed = sorted(now - pinned), sorted(pinned - now)
    assert not (added or removed), (f"The API differs from {api.swagger_file.name} - re-pin it. "
                                    f"Added: {added}  Removed: {removed}")


def test_mcp_tools_match_pinned_list(services, settings):
    api = settings.apis["mcp_diagnostics"]
    resp = services.mcp.list_tools()
    assert resp.status == 200 and resp.body, f"tools/list returned {resp}"

    def shape(tools):
        return {t["name"]: sorted(t.get("inputSchema", {}).get("required", [])) for t in tools}
    pinned, now = shape(json.loads(api.tools_file.read_text())["tools"]), shape(resp.body.get("tools", []))
    assert pinned == now, f"The MCP tools differ from {api.tools_file.name} - re-pin it. Pinned: {pinned}  Now: {now}"
