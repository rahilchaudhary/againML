"""Aggregation cases (A-): cross-component vehicle profiles, the fleet dashboard and its summaries.

The aggregation rules (e.g. how component health is weighted) are not agreed yet, so these cases check
only what holds whatever the rules turn out to be: endpoints agree with each other, and with the
component predictions they are built from. A-02 and A-03 are Send & Verify rows (Test Data sheet).
Every case first refreshes the profiles and waits for /api/ready (fixture aggregates_ready).
"""
from __future__ import annotations

import pytest

from framework.flows import fail, send_and_verify
from framework.record_source import extract_records

# ASSUMED response field names (the Swagger gives no response schemas) - adjust when real responses are seen.
VEHICLE_ID = "vehicle_id"            # dashboard record / profile: the vehicle's ID (the VIN on the dashboard)
RANK_BY = "downtime_risk_score"      # dashboard is ranked by this, highest first
MIN_RUL = "min_rul_days"             # profile: lowest remaining life of any component
SUMMARY_TOTAL = "total_vehicles"
SUMMARY_PRIORITY = "priority_counts"       # {"P1": n, "P2": n, "P3": n}
SUMMARY_RISK = "risk_distribution"         # {"CRITICAL": n, "WATCH": n, "HEALTHY": n}


def dashboard(run, services) -> list[dict]:
    resp = services.aggregation.dashboard()
    if resp.status != 200:
        fail(run, [f"dashboard call returned {resp}"])
    records = extract_records(resp.body)
    if not records:
        fail(run, ["prerequisite: the dashboard has no vehicles"])
    return records


@pytest.mark.case("A-01")
def test_a01_dashboard_ranked_by_downtime_risk(run, services, aggregates_ready):
    records = dashboard(run, services)
    scores = [r.get(RANK_BY) for r in records]
    problems = [f"{r.get(VEHICLE_ID)}: no numeric {RANK_BY} ({r.get(RANK_BY)!r})"
                for r in records if not isinstance(r.get(RANK_BY), (int, float))]
    if not problems:
        problems = [f"position {i + 1}: {records[i].get(VEHICLE_ID)} ({scores[i]}) is ranked above "
                    f"{records[i + 1].get(VEHICLE_ID)} ({scores[i + 1]})"
                    for i in range(len(scores) - 1) if scores[i] < scores[i + 1]]
    fail(run, problems)


@pytest.mark.case("A-02")
def test_a02_dashboard_filter_returns_only_matching(run, services, builder, settings, aggregates_ready):
    send_and_verify(run, services, builder, settings)


@pytest.mark.case("A-03")
def test_a03_top_n_accepts_1_to_100(run, services, builder, settings, aggregates_ready):
    send_and_verify(run, services, builder, settings)


@pytest.mark.case("A-04")
def test_a04_summary_agrees_with_dashboard(run, services, aggregates_ready):
    records = dashboard(run, services)
    resp = services.aggregation.summary()
    if resp.status != 200:
        fail(run, [f"summary call returned {resp}"])
    summary = resp.body or {}
    problems = []
    if summary.get(SUMMARY_TOTAL) != len(records):
        problems.append(f"{SUMMARY_TOTAL} = {summary.get(SUMMARY_TOTAL)}, dashboard lists {len(records)} vehicles")
    for key, field in ((SUMMARY_PRIORITY, "priority"), (SUMMARY_RISK, "risk_level")):
        counted: dict[str, int] = {}
        for r in records:
            counted[str(r.get(field))] = counted.get(str(r.get(field)), 0) + 1
        stated = {k: v for k, v in (summary.get(key) or {}).items() if v}
        if stated != counted:
            problems.append(f"{key} = {stated}, dashboard counts {counted}")
    fail(run, problems)


@pytest.mark.case("A-05")
def test_a05_vehicle_components_match_component_predictions(run, services, settings, vehicle_sample, aggregates_ready):
    """For this component: each sampled vehicle's entry in its profile equals the component's own prediction."""
    comp = run.component.name
    tol = settings.flows["aggregation"]["tolerance"]
    fleet = services.fleet.fleet(comp)
    if fleet.status != 200:
        fail(run, [f"{comp} fleet call returned {fleet}"])
    by_vin = {r["vin"]: r for r in extract_records(fleet.body) if r.get("vin")}
    vins = vehicle_sample.pick(list(by_vin))
    problems = []
    for vin in vins:                       # ASSUMED: the aggregation's vehicle ID is the VIN
        resp = services.aggregation.vehicle_components(vin)
        if resp.status != 200:
            problems.append(f"{vin}: components call returned {resp}")
            continue
        entry = next((c for c in extract_records(resp.body) if c.get("component") == comp), None)
        if entry is None:
            problems.append(f"{vin}: {comp} missing from the vehicle's components")
            continue
        own = by_vin[vin]
        if entry.get("risk_level") != own.get("risk_level"):
            problems.append(f"{vin}: risk_level {entry.get('risk_level')} in the profile, "
                            f"{own.get('risk_level')} in the {comp} prediction")
        a, b = entry.get("rul_days"), own.get("rul_days")
        if not (isinstance(a, (int, float)) and isinstance(b, (int, float)) and abs(a - b) <= tol):
            problems.append(f"{vin}: rul_days {a} in the profile, {b} in the {comp} prediction")
    if problems:
        problems.append(f"checked {vehicle_sample.describe(len(vins), len(by_vin))}")
    fail(run, problems)


@pytest.mark.case("A-06")
def test_a06_vehicle_min_rul_is_lowest_component_rul(run, services, settings, vehicle_sample, aggregates_ready):
    tol = settings.flows["aggregation"]["tolerance"]
    all_ids = [r[VEHICLE_ID] for r in dashboard(run, services) if r.get(VEHICLE_ID)]
    ids = vehicle_sample.pick(all_ids)
    problems = []
    for vid in ids:
        profile = services.aggregation.vehicle(vid)
        comps = services.aggregation.vehicle_components(vid)
        if profile.status != 200 or comps.status != 200:
            problems.append(f"{vid}: profile {profile.status}, components {comps.status}")
            continue
        ruls = [c.get("rul_days") for c in extract_records(comps.body) if isinstance(c.get("rul_days"), (int, float))]
        stated = (profile.body or {}).get(MIN_RUL)
        if not ruls or not isinstance(stated, (int, float)) or abs(stated - min(ruls)) > tol:
            problems.append(f"{vid}: {MIN_RUL} = {stated}, lowest component rul_days = {min(ruls) if ruls else None}")
    if problems:
        problems.append(f"checked {vehicle_sample.describe(len(ids), len(all_ids))}")
    fail(run, problems)


@pytest.mark.case("A-07")
def test_a07_vehicle_health_follows_agreed_weighting(run, services, settings, aggregates_ready):
    """Blocked in the Test Cases sheet until the ML team gives the weighting. When it arrives: put the weights
    in config/flows.yaml (aggregation), compute each sampled vehicle's health score from its components'
    health scores, and compare with the profile within the tolerance."""
    raise NotImplementedError("A-07 is marked Ready but its rule is not written yet")
