"""Unit tests of the RUL accuracy calculation (framework/rul_accuracy/) - no API, run with every pytest run.

Small examples worked out by hand, so the numbers the R-01 report stands on are known to be right.
"""
import math

import pytest

from framework.rul_accuracy.evaluator import evaluate, gate_problems, prepare_rows
from framework.rul_accuracy.history import History
from framework.rul_accuracy.reference_life import ReferenceLife, ReferenceLifeError, load_reference_lives

ACCURACY = {"age_field": "radiator_age_hours", "cycle_id": "CYCLE-01", "threshold_source": "ASSUMED",
            "thresholds": {"overprediction_absolute_hours": 50, "overprediction_fraction": 0.10,
                           "underprediction_absolute_hours": 100, "underprediction_fraction": 0.20,
                           "minimum_pass_rate_pct": 50, "maximum_mae_hours": 250, "maximum_rmse_hours": 300,
                           "maximum_mean_over_under_hours": 200}}
LIVES = {("RAD-1", "CYCLE-01"): ReferenceLife("RAD-1", "CYCLE-01", 3000.0, "ASSUMED")}


def history(*pairs, unit="RAD-1"):
    """(age, predicted RUL) pairs -> one vehicle's history."""
    return History(unit, "http://x/history",
                   [{"unit_id": unit, "radiator_age_hours": a, "predicted_rul_hours": p} for a, p in pairs])


def test_expected_rul_and_signed_error():
    # life 3000: age 2900 -> expected 100, predicted 160 -> +60; age 2000 -> expected 1000, predicted 700 -> -300
    rows = prepare_rows("radiator", ACCURACY, [history((2900, 160), (2000, 700))], LIVES)
    assert [r["qa_expected_rul_hours"] for r in rows] == [100, 1000]
    assert [r["qa_signed_error_hours"] for r in rows] == [60, -300]
    assert [r["qa_prediction_direction"] for r in rows] == ["OVERPREDICTION", "UNDERPREDICTION"]


def test_allowed_error_is_tighter_for_overprediction():
    # over: max(50, 100 x 0.10) = 50, so +60 fails; under: max(100, 1000 x 0.20) = 200, so -150 passes
    rows = prepare_rows("radiator", ACCURACY, [history((2900, 160), (2000, 850))], LIVES)
    assert [r["qa_allowed_error_hours"] for r in rows] == [50, 200]
    assert [r["qa_record_status"] for r in rows] == ["FAIL", "PASS"]


def test_metrics_and_gates():
    rows = prepare_rows("radiator", ACCURACY, [history((2900, 160), (2000, 700))], LIVES)
    summary = evaluate(rows, ACCURACY)
    m = summary["qa_component_metrics"]
    assert m["qa_mae_hours"] == 180
    assert m["qa_rmse_hours"] == pytest.approx(math.sqrt((60 ** 2 + 300 ** 2) / 2))
    assert m["qa_mean_over_under_prediction_hours"] == -120
    assert m["qa_tolerance_pass_rate_pct"] == 0
    assert m["qa_quality_gates"] == {"pass_rate": False, "mae": True, "rmse": True, "mean_over_under": True}
    assert m["qa_quality_gate_status"] == "FAIL"
    assert gate_problems(summary) == ["0.0% of records within the allowed error, minimum 50%"]


def test_unreadable_history_is_an_execution_failure_not_an_exclusion_only():
    rows = prepare_rows("radiator", ACCURACY, [History("RAD-1", "http://x", error="history call returned HTTP 500")], LIVES)
    assert evaluate(rows, ACCURACY)["qa_execution_status"] == "FAIL"


def test_records_that_cannot_be_evaluated_are_kept_with_a_reason():
    rows = prepare_rows("radiator", ACCURACY, [history((3100, 10)), history((10, 5), unit="RAD-9")], LIVES)
    summary = evaluate(rows, ACCURACY)
    assert summary["qa_exclusion_summary"] == {"AGE_BEYOND_REFERENCE_LIFE": 1, "NO_REFERENCE_LIFE": 1}
    assert summary["qa_component_metrics"]["qa_metric_status"] == "NOT_CALCULATED"


def test_repeated_records_are_kept_with_distinct_ids():
    rows = prepare_rows("radiator", ACCURACY, [history((2900, 160), (2900, 160))], LIVES)
    assert len(rows) == 2 and rows[0]["qa_observation_id"] != rows[1]["qa_observation_id"]


def test_reference_life_file_rejects_duplicates(tmp_path):
    f = tmp_path / "radiator.csv"
    f.write_text("unit_id,cycle_id,reference_life_hours,source\nRAD-1,CYCLE-01,3000,ASSUMED\nRAD-1,CYCLE-01,3100,ASSUMED\n")
    with pytest.raises(ReferenceLifeError, match="appears twice"):
        load_reference_lives(f)
