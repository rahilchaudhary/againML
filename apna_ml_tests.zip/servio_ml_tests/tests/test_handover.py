"""Handover cases (H-): the model flags a vehicle, the scheduling API offers slots, a slot is booked.

Flow & Verify: each test is a short sequence of calls, each using what the previous one returned.
Runs once per component (Applicable Components). Bookings made here are cancelled afterwards.
Requirements (which risk levels lead to booking, slot fields) come from config/flows.yaml.
"""
from __future__ import annotations

from datetime import date

import pytest

from framework.flows import Flow
from framework.record_source import extract_records
from framework.request_builder import BookRequest

BOOKING_ID = "booking_id"     # ASSUMED: field holding the booking's ID in the /book response


def flagged_vehicles(flow, services, settings, component) -> list[dict]:
    """Vehicles the model flags for service, most at risk first (flag_risk_levels order) - the handover's input."""
    body = flow.step(f"Get {component} fleet predictions", services.fleet.fleet(component), 200)
    flags = settings.flows["handover"]["flag_risk_levels"]
    flagged = sorted((r for r in extract_records(body) if r.get("risk_level") in flags and r.get("vin")),
                     key=lambda r: flags.index(r["risk_level"]))
    if not flagged:
        flow.blocked(f"no {component} vehicle flagged {'/'.join(flags)} by the model")
    return flagged


def flagged_vehicle(flow, services, settings, component) -> dict:
    return flagged_vehicles(flow, services, settings, component)[0]


def offered_slots(flow, services, vin, component, title="Get slots") -> list[dict]:
    body = flow.step(f"{title} for {vin} ({component})", services.scheduling.slots(vin, component), 200)
    slots = (body or {}).get("available_slots")
    flow.require(isinstance(slots, list), f"no available_slots list in the slots response: {body}")
    return slots


def first_slot(flow, services, vin, component) -> dict:
    slots = offered_slots(flow, services, vin, component)
    if not slots:
        flow.blocked(f"no slots offered for {vin} ({component}) - check bay capacity (GET /api/schedule/bays)")
    return slots[0]


def book(flow, services, vin, component, slot) -> tuple[dict, dict]:
    """Book the slot as the UI does: the slot's own values, plus vin and component."""
    request = {f: slot[f] for f in BookRequest.model_fields if f in slot}
    request.update(vin=vin, component=component)
    booked = flow.step(f"Book slot {slot.get('slot_id')}", services.scheduling.book(request), 201) or {}
    booking_id = booked.get(BOOKING_ID)
    flow.require(bool(booking_id), f"the booking response has no {BOOKING_ID}: {booked}")
    flow.undo("Cancel the booking", lambda: services.scheduling.cancel(booking_id))
    return request, booked


def slot_ids(slots) -> set:
    return {s.get("slot_id") for s in slots}


@pytest.mark.case("H-01")
def test_h01_slots_offered_for_flagged_vehicle(run, request, services, settings):
    flow, comp = Flow(run, request), run.component.name
    vehicle = flagged_vehicle(flow, services, settings, comp)
    slots = offered_slots(flow, services, vehicle["vin"], comp)
    if not slots:
        flow.blocked(f"no slots offered for {vehicle['vin']} ({comp}) - check bay capacity (GET /api/schedule/bays)")
    fields = settings.flows["handover"]["slot_fields"]
    for s in slots:
        name = s.get("slot_id", "a slot")
        empty = [f for f in fields if s.get(f) in (None, "")]
        flow.check(not empty, f"{name}: no value in {empty}")
        try:
            flow.check(date.fromisoformat(str(s.get("date"))) >= date.today(), f"{name}: date {s.get('date')} is in the past")
        except ValueError:
            flow.check(False, f"{name}: date {s.get('date')!r} is not YYYY-MM-DD")
    flow.done()


@pytest.mark.case("H-02")
def test_h02_booking_keeps_vehicle_and_slot(run, request, services, settings):
    flow, comp = Flow(run, request), run.component.name
    vin = flagged_vehicle(flow, services, settings, comp)["vin"]
    slot = first_slot(flow, services, vin, comp)
    sent, booked = book(flow, services, vin, comp, slot)
    for f, value in sent.items():
        flow.check(booked.get(f) == value, f"booking {f} = {booked.get(f)!r}, sent {value!r}")
    listing = flow.step("List bookings", services.scheduling.bookings(), 200)
    match = [b for b in extract_records(listing) if b.get(BOOKING_ID) == booked[BOOKING_ID]]
    if flow.check(len(match) == 1, f"booking {booked[BOOKING_ID]} appears {len(match)} times in the bookings list"):
        for f in ("vin", "component", "slot_id"):
            flow.check(match[0].get(f) == sent[f], f"bookings list {f} = {match[0].get(f)!r}, sent {sent[f]!r}")
    flow.done()


@pytest.mark.case("H-03")
def test_h03_booked_slot_not_offered_again(run, request, services, settings):
    flow, comp = Flow(run, request), run.component.name
    vin = flagged_vehicle(flow, services, settings, comp)["vin"]
    slot = first_slot(flow, services, vin, comp)
    book(flow, services, vin, comp, slot)
    after_booking = offered_slots(flow, services, vin, comp, "Get slots again")
    flow.check(slot["slot_id"] not in slot_ids(after_booking), f"{slot['slot_id']} is still offered after it was booked")
    flow.undo_now("Cancel the booking")
    after_cancel = offered_slots(flow, services, vin, comp, "Get slots after cancelling")
    flow.check(slot["slot_id"] in slot_ids(after_cancel), f"{slot['slot_id']} is not offered again after the booking was cancelled")
    flow.done()
