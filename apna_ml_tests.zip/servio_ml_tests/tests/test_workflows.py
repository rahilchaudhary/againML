"""Workflow cases (W-): Proactive Health Nudge, up to the Service Advisor Agent, and the MCP diagnostics it uses.

W-01, W-02  Send & Verify: call the MCP tool get_dtc_details with the DTC in the Test Data sheet.
W-03..W-06  Flow & Verify: start the workflow once through its webhook, find the run in the
            executions API, then each case checks one thing about that same run.
Not per component (Applicable Components = n/a). Requirements come from config/flows.yaml.
"""
from __future__ import annotations

import json

import pytest

from framework.flows import fail
from framework.result_checker import check
from framework.settings import ROOT
from framework.workflow_run import parse_json_text, start_and_wait


# ---------------- MCP diagnostics ----------------
def dtc_lookup(run, services, settings):
    cfg = settings.flows["mcp_diagnostics"]
    resp = services.mcp.get_dtc_details(run.row.value)
    problems = check(resp, run.row, detail_fields=tuple(cfg["dtc_detail_fields"]))
    if run.row.expected_result.lower() == "found" and isinstance(resp.body, dict):
        severity = str(resp.body.get("severity", "")).lower()
        if severity not in cfg["severity_order"]:
            problems.append(f"severity {severity!r} is not one of {cfg['severity_order']}")
    fail(run, problems)


@pytest.mark.case("W-01")
def test_w01_known_dtc_is_found(run, services, settings):
    dtc_lookup(run, services, settings)


@pytest.mark.case("W-02")
def test_w02_unknown_dtc_is_not_found(run, services, settings):
    dtc_lookup(run, services, settings)


# ---------------- Proactive Health Nudge: one run, four checks ----------------
@pytest.fixture(scope="session")
def nudge(services, settings):
    cfg = settings.flows["proactive_health_nudge"]
    workflow_id = settings.workflow_ids.get("proactive_health_nudge")
    if not workflow_id:
        pytest.fail(f"Prerequisite failed: no workflow_ids: proactive_health_nudge for environment "
                    f"'{settings.env}' (config/settings.yaml)", pytrace=False)
    request = json.loads((ROOT / cfg["request"]).read_text())
    run, note = start_and_wait(services.n8n, workflow_id, request, cfg["wait_seconds"])
    if run is None:
        pytest.fail(f"Prerequisite failed: Proactive Health Nudge run - {note}", pytrace=False)
    return run


def sent_dtcs(nudge) -> list[str]:
    """DTCs sent, blanks dropped, repeats removed, first-seen order kept (as the agent is told to do)."""
    codes = [d.get("dtc_code", "").strip() for d in nudge.sent["payload"]["dtc_list"]]
    return list(dict.fromkeys(c for c in codes if c))


def advisor_output(run, nudge, nodes) -> dict:
    outputs = nudge.node_outputs(nodes["service_advisor"])
    if not outputs:
        fail(run, [f"'{nodes['service_advisor']}' did not run. Nodes that ran: {nudge.node_names()}"])
    try:
        return parse_json_text(outputs[0].get("output"))
    except ValueError:
        fail(run, [f"Service Advisor output is not JSON: {str(outputs[0].get('output'))[:200]}"])


@pytest.mark.case("W-03")
def test_w03_execution_succeeds(run, nudge):
    problems = []
    if nudge.status != "success":
        problems.append(f"execution status {nudge.status!r}, expected 'success'. Error: {str(nudge.error)[:200]}")
    if not nudge.finished:
        problems.append("execution is not marked finished")
    fail(run, problems)


@pytest.mark.case("W-04")
def test_w04_advisor_looks_up_each_sent_dtc(run, nudge, settings):
    nodes = settings.flows["proactive_health_nudge"]["nodes"]
    sent = sent_dtcs(nudge)
    problems = []
    for node in (nodes["dtc_tool"], nodes["mcp"]):
        called = [i.get("dtc_code") for i in nudge.node_inputs(node)]
        if sorted(called) != sorted(sent):
            problems.append(f"{node} was called with {called}, expected each of {sent} exactly once")
    fail(run, problems)


@pytest.mark.case("W-05")
def test_w05_advisor_output_is_complete(run, nudge, settings):
    cfg = settings.flows["proactive_health_nudge"]
    output = advisor_output(run, nudge, cfg["nodes"])
    empty = [f for f in cfg["service_advisor_fields"] if output.get(f) in (None, "", [])]
    fail(run, [f"Service Advisor output has no value in {empty}"] if empty else [])


@pytest.mark.case("W-06")
def test_w06_advisor_severity_matches_diagnostics(run, nudge, settings):
    cfg = settings.flows["proactive_health_nudge"]
    order = settings.flows["mcp_diagnostics"]["severity_order"]
    output = advisor_output(run, nudge, cfg["nodes"])
    said = str(output.get("severity", "")).split(":")[0].strip().lower()
    found = [str((o.get("structuredContent") or {}).get("severity", "")).lower()
             for o in nudge.node_outputs(cfg["nodes"]["mcp"])]
    known = [s for s in found if s in order]
    if not known:
        fail(run, [f"no usable severity from the diagnostics tool: {found}"])
    expected = max(known, key=order.index)
    fail(run, [] if said == expected else
         [f"Service Advisor severity {said!r} ({output.get('severity', '')[:60]!r}), diagnostics said {expected!r}"])
