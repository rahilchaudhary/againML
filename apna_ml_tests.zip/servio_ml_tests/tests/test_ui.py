"""UI cases (U-): the Fleet Dashboard and the Schedule Service wizard, checked against the APIs behind them.

Flow & Verify: each test drives the screen through page objects (framework/pages/) and compares what the
screen shows with what the API returns, so the UI checks stay thin and the API cases do the detailed checking.
A failing UI case saves a screenshot in reports/screenshots/.
"""
from __future__ import annotations

import pytest

from framework.auth import credentials
from framework.flows import Flow
from framework.pages import FleetDashboardPage, LoginPage
from framework.pages.dashboard_page import DOWNTIME_RISK, PRIORITY, VEHICLE_ID
from framework.record_source import extract_records
from tests.test_aggregation import VEHICLE_ID as API_VEHICLE_ID, RANK_BY, SUMMARY_TOTAL
from tests.test_handover import BOOKING_ID, flagged_vehicles


def _number(text: str) -> float | None:
    try:
        return float(text.replace("%", "").strip())
    except ValueError:
        return None


@pytest.mark.case("U-01")
def test_u01_login_lands_on_dashboard(run, request, page, ui_base_url, services, settings, aggregates_ready):
    flow = Flow(run, request)
    LoginPage(page, ui_base_url).open().log_in(*credentials())
    flow.did("Log in through the login page")
    dash = FleetDashboardPage(page, ui_base_url).open()
    flow.did("Open the Fleet Dashboard")
    role = settings.flows["ui"]["role_shown"]
    flow.check(dash.shows_role(role), f"the header does not show the role {role!r}")
    summary = flow.step("Get fleet summary", services.aggregation.summary(), 200) or {}
    registry = flow.step("Get model registry", services.system.registry(), 200) or {}
    flow.check(dash.header_count("Vehicles") == summary.get(SUMMARY_TOTAL),
               f"header shows {dash.header_count('Vehicles')} Vehicles, summary says {summary.get(SUMMARY_TOTAL)}")
    flow.check(dash.header_count("Components") == len(registry),
               f"header shows {dash.header_count('Components')} Components, registry lists {len(registry)}")
    flow.done()


@pytest.mark.case("U-02")
def test_u02_dashboard_rows_match_api(run, request, logged_in_page, ui_base_url, services, settings, aggregates_ready):
    flow, n = Flow(run, request), settings.flows["ui"]["rows_compared"]
    api = extract_records(flow.step("Get dashboard", services.aggregation.dashboard(), 200))[:n]
    shown = FleetDashboardPage(logged_in_page, ui_base_url).open().rows(n)
    flow.did(f"Read the first {n} table rows")
    flow.check(len(shown) == len(api), f"{len(shown)} rows shown, the API has {len(api)} in the first {n}")
    for i, (s, a) in enumerate(zip(shown, api), 1):
        if not flow.check(s.get(VEHICLE_ID) == a.get(API_VEHICLE_ID),
                          f"row {i}: {s.get(VEHICLE_ID)} shown, API has {a.get(API_VEHICLE_ID)} at this position"):
            continue
        flow.check(s.get(PRIORITY) == a.get("priority"), f"row {i} {s.get(VEHICLE_ID)}: priority {s.get(PRIORITY)}, API {a.get('priority')}")
        flow.check(_number(s.get(DOWNTIME_RISK, "")) == a.get(RANK_BY),
                   f"row {i} {s.get(VEHICLE_ID)}: downtime risk {s.get(DOWNTIME_RISK)}, API {a.get(RANK_BY)}")
    flow.done()


@pytest.mark.case("U-03")
def test_u03_risk_filter_shows_only_matching(run, request, logged_in_page, ui_base_url, services, settings, aggregates_ready):
    flow, level = Flow(run, request), settings.flows["ui"]["risk_filter"]
    api = extract_records(flow.step(f"Get dashboard filtered on {level}",
                                     services.aggregation.dashboard(risk_level=level), 200))
    if not api:
        flow.blocked(f"no vehicle is {level} right now, so the filter cannot be shown to work")
    dash = FleetDashboardPage(logged_in_page, ui_base_url).open()
    dash.filter_risk_level(level)
    flow.did(f"Filter Risk Level = {level}")
    shown = [r.get(VEHICLE_ID) for r in dash.rows()]
    expected = [r.get(API_VEHICLE_ID) for r in api]
    flow.check(shown == expected, f"shown {shown}, the API filter returns {expected}")
    flow.done()


@pytest.mark.case("U-04")
def test_u04_schedule_wizard_books_selected_slot(run, request, logged_in_page, ui_base_url, services, settings, aggregates_ready):
    flow, comp = Flow(run, request), run.component.name
    booked = {b.get("vin") for b in extract_records(flow.step("List bookings", services.scheduling.bookings(), 200))}
    dash = FleetDashboardPage(logged_in_page, ui_base_url).open()
    vin = next((v["vin"] for v in flagged_vehicles(flow, services, settings, comp)
                if v["vin"] not in booked and dash.has_row(v["vin"])), None)
    if vin is None:
        flow.blocked(f"no flagged {comp} vehicle without a booking is on the dashboard")
    api_slots = (flow.step(f"Get slots for {vin} ({comp})", services.scheduling.slots(vin, comp), 200) or {}).get("available_slots", [])
    if not api_slots:
        flow.blocked(f"no slots offered for {vin} ({comp})")

    wizard = dash.open_schedule(vin)
    flow.did(f"Click Schedule for {vin}")
    wizard.choose_component(comp)
    wizard.next_to_details()
    flow.did(f"Choose {comp}, Next")
    shown = wizard.slot_options()
    flow.check(len(shown) == len(api_slots), f"{len(shown)} slots shown, the API offers {len(api_slots)}")
    for i, (text, s) in enumerate(zip(shown, api_slots), 1):     # ASSUMED: the screen keeps the API's order
        flow.check(str(s.get("time")) in text, f"slot {i} shows {text!r}, the API's slot {i} is at {s.get('time')}")
    wizard.choose_slot(0)
    wizard.next_to_confirm()
    wizard.confirm()
    flow.did("Select the first slot, Next, Confirm")

    mine = [b for b in extract_records(flow.step("List bookings", services.scheduling.bookings(), 200)) if b.get("vin") == vin]
    flow.require(len(mine) == 1, f"{len(mine)} bookings for {vin} after Confirm, expected 1")
    booking = mine[0]
    flow.undo("Cancel the booking", lambda: services.scheduling.cancel(booking[BOOKING_ID]))
    for f in ("slot_id", "date", "time", "dealer_id"):
        flow.check(booking.get(f) == api_slots[0].get(f), f"booked {f} = {booking.get(f)!r}, selected slot has {api_slots[0].get(f)!r}")
    flow.check(booking.get("component") == comp, f"booked component {booking.get('component')!r}, chose {comp!r}")
    dash.wait_until_booked(vin)
    flow.did("Row shows Booked")
    flow.done()
