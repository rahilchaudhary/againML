"""RUL accuracy case (R-): is predicted RUL close enough to the RUL expected from a known end of life?

Read & Verify, once per component: read the history of every vehicle that has a reference life, compare each
prediction with the expected RUL, and pass when every quality gate passes.
A missed gate is FAIL only against agreed limits and reference lives. Against QA-assumed ones it is BLOCKED,
with the numbers - it cannot be called a model defect until the ML team agrees them. The calculation is in
framework/rul_accuracy/; requirements in config/components/<name>.yaml (rul_accuracy); reference lives in
testdata/reference_life/<name>.csv. Evidence and the HTML report go to reports/rul_accuracy/ (and into Allure).
"""
from __future__ import annotations

import pytest
import yaml

from framework import reporting
from framework.flows import fail
from framework.rul_accuracy.evaluator import evaluate, gate_problems, prepare_rows
from framework.rul_accuracy.history import fetch_histories, fleet_unit_ids
from framework.rul_accuracy.interpretation import is_assumed
from framework.rul_accuracy.reference_life import load_reference_lives
from framework.rul_accuracy.report import write_component_report, write_evidence, write_index
from framework.settings import ROOT

OUT_DIR = ROOT / "reports" / "rul_accuracy"


@pytest.fixture(scope="session")
def report_config() -> dict:
    return yaml.safe_load((ROOT / "config" / "rul_accuracy_report.yaml").read_text(encoding="utf-8"))


@pytest.mark.case("R-01")
def test_r01_rul_within_agreed_accuracy(run, services, settings, report_config):
    comp = run.component
    accuracy = comp.rul_accuracy
    if not accuracy:
        pytest.skip(f"BLOCKED: no rul_accuracy section in config/components/{comp.name}.yaml")
    lives_file = settings.reference_lives_file(comp.name)
    if not lives_file.exists():
        pytest.skip(f"BLOCKED: no reference lives for {comp.name} ({lives_file.relative_to(ROOT)})")
    lives = load_reference_lives(lives_file)

    fleet = fleet_unit_ids(services, comp.name)
    with_life = [u for u in fleet if (u, accuracy["cycle_id"]) in lives]     # only these can be evaluated
    if not with_life:
        pytest.skip(f"BLOCKED: none of the {len(fleet)} {comp.name} vehicles has a reference life "
                    f"for {accuracy['cycle_id']} in {lives_file.name}")

    rows = prepare_rows(comp.name, accuracy, fetch_histories(services, comp.name, with_life), lives)
    summary = evaluate(rows, accuracy)
    system, subsystem = settings.place_of(comp.name)
    summary.update(qa_component=comp.name, qa_component_display_name=settings.display(comp.name),
                   qa_system=settings.display(system), qa_subsystem=settings.display(subsystem),
                   qa_vehicles_in_fleet=len(fleet), qa_vehicles_with_reference_life=len(with_life),
                   qa_reference_life_assumed=any(r.get("qa_reference_life_source") == "ASSUMED" for r in rows))

    summary_path, records_path = write_evidence(OUT_DIR, comp.name, summary, rows)
    report_path = write_component_report(OUT_DIR / f"{comp.name}_report.html", summary, rows, report_config)
    write_index(OUT_DIR)
    reporting.attach_file(f"{comp.name} RUL accuracy report", report_path, "html")
    reporting.attach_file(f"{comp.name} accuracy summary", summary_path, "json")
    reporting.attach_file(f"{comp.name} accuracy records", records_path, "csv")

    metrics = summary["qa_component_metrics"]
    if metrics["qa_metric_status"] != "CALCULATED":
        pytest.skip(f"BLOCKED: no history record of {comp.name} could be evaluated - "
                    f"{summary['qa_exclusion_summary']} (see {records_path.name})")
    # History that could not be read is a defect, whatever the thresholds.
    fail(run, [f"{r['unit_id']}: {r['qa_exclusion_reason']}" for r in rows if r.get("qa_execution_status") == "FAIL"])
    missed = gate_problems(summary)
    if missed and is_assumed(summary):
        # Red means a real defect against agreed limits. Against QA-assumed limits or reference lives a miss
        # cannot be called a model defect: BLOCKED, with the numbers, until the ML team agrees them.
        pytest.skip(f"BLOCKED: quality gate missed against QA-assumed thresholds or reference lives - agree them "
                    f"with the ML team (config/components/{comp.name}.yaml, {lives_file.name}): "
                    + "; ".join(missed) + f". Report: {report_path.relative_to(ROOT)}")
    fail(run, missed + ([f"report {report_path.relative_to(ROOT)}"] if missed else []))
