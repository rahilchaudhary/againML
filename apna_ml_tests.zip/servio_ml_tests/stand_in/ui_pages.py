"""Stand-in pages for the UI cases: login, Fleet Dashboard, Schedule Service wizard.

Copied from the screenshots of the real UI (layout, labels, buttons), backed by the stand-in APIs.
The real UI's markup is not known, so the page objects (framework/pages/) find things by visible
labels and roles, as a user would - those are what these pages reproduce.

Fault switches (STANDIN_BUG=...):
  ui_wrong_count       header shows one vehicle more than the summary  -> U-01 fails
  ui_row_order         table rows in a different order than the API    -> U-02 fails
  ui_books_wrong_slot  Confirm books the slot after the selected one   -> U-04 fails
"""

LOGIN_HTML = """<!doctype html><html><head><title>Servio - Login</title></head><body>
<h1>SERVIO</h1><p>Aftersales Intelligence by KPIT</p>
<form method="post" action="/login">
  <label>Email <input name="email" type="email"></label>
  <label>Password <input name="password" type="password"></label>
  <button type="submit">Sign in</button>
</form></body></html>"""

DASHBOARD_HTML = """<!doctype html><html><head><title>Servio - Fleet Monitoring</title>
<style>body{font-family:sans-serif} td,th{padding:4px 8px;text-align:left}
[role=dialog]{position:fixed;top:40px;left:30%;background:#fff;border:1px solid #888;padding:16px}</style></head>
<body>
<header>
  <span>Good Afternoon, <b>FLEET MANAGER</b></span>
  <span>Live</span> <span id="vehicles"></span> <span id="components"></span>
  <span>fleet.manager@kpit.com</span> <span>FLEET MANAGER</span>
</header>
<nav><a>Fleet Overview</a> <a>Fleet Monitoring</a> <a>Upload &amp; Predict</a></nav>
<div>
  <label>Site: <select id="site"><option value="">All Sites</option></select></label>
  <label>Model: <select id="model"><option value="">All Models</option></select></label>
  <label>Priority: <select id="priority"><option value="">All Priorities</option>
    <option value="P1">P1</option><option value="P2">P2</option><option value="P3">P3</option></select></label>
  <label>Risk Level: <select id="risk"><option value="">All Risk Levels</option>
    <option value="CRITICAL">Critical</option><option value="WATCH">Watch</option><option value="HEALTHY">Healthy</option></select></label>
</div>
<h2>Fleet Dashboard — All Vehicles</h2>
<table><thead><tr><th>Vehicle ID</th><th>Model</th><th>Site</th><th>Health Score</th><th>Min RUL (days)</th>
<th>Downtime Risk</th><th>Priority</th><th>Actions</th><th>Schedule</th></tr></thead><tbody id="rows"></tbody></table>
<div id="wizard" role="dialog" aria-label="Schedule Service" hidden></div>
<script>
const BUG = "__BUG__";
let current = null, slots = [];
const j = (r) => r.json();
async function header() {
  const s = await fetch('/api/aggregate/fleet/summary').then(j);
  const reg = await fetch('/api/registry').then(j);
  document.getElementById('vehicles').textContent = (s.total_vehicles + (BUG === 'ui_wrong_count' ? 1 : 0)) + ' Vehicles';
  document.getElementById('components').textContent = Object.keys(reg).length + ' Components';
}
async function table() {
  const q = new URLSearchParams();
  for (const [id, key] of [['site','site'],['model','model'],['priority','priority'],['risk','risk_level']]) {
    const v = document.getElementById(id).value; if (v) q.set(key, v);
  }
  let rows = await fetch('/api/aggregate/fleet/dashboard' + (q.toString() ? '?' + q : '')).then(j);
  const booked = new Set((await fetch('/api/schedule/bookings').then(j)).bookings.map(b => b.vin));
  if (BUG === 'ui_row_order') rows = rows.slice().reverse();
  document.getElementById('rows').innerHTML = rows.map(r => `<tr>
    <td><a href="#">${r.vehicle_id}</a></td><td>${r.vehicle_model}</td><td>${r.site}</td><td>${Math.round(r.health_score)}%</td>
    <td>${r.min_rul_days}</td><td>${r.downtime_risk_score}</td><td>${r.priority}</td><td>${r.recommended_action}</td>
    <td>${booked.has(r.vehicle_id) ? '<button disabled>Booked</button>' : `<button data-vin="${r.vehicle_id}">Schedule</button>`}</td></tr>`).join('');
  document.querySelectorAll('button[data-vin]').forEach(b => b.onclick = () => openWizard(b.dataset.vin));
}
async function openWizard(vin) {
  current = {vin};
  const reg = await fetch('/api/registry').then(j);
  const w = document.getElementById('wizard'); w.hidden = false;
  w.innerHTML = `<h3>Schedule Service</h3><p>${vin}</p><p>1 Component · 2 Details · 3 Confirm</p>
    <label>Component to Service <select id="comp">${Object.keys(reg).map(c => `<option>${c}</option>`).join('')}</select></label>
    <label>Service Type <select id="stype"><option>Inspection</option><option>Repair</option></select></label>
    <button id="next1">Next</button>`;
  document.getElementById('next1').onclick = details;
}
async function details() {
  current.component = document.getElementById('comp').value;
  current.service_type = document.getElementById('stype').value;
  const r = await fetch('/api/schedule/slots', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({vin: current.vin, component: current.component, tenant_id: 'kpit-preventive'})}).then(j);
  slots = r.available_slots;
  const w = document.getElementById('wizard');
  w.innerHTML = `<h3>Schedule Service</h3><p>Details — available slots</p>` +
    (slots.length ? slots.map((s, i) => `<label><input type="radio" name="slot" value="${i}"> ${s.date} · ${s.time} · ${s.dealer_name}</label><br>`).join('')
                  : '<p>No slots available</p>') + `<button id="next2">Next</button>`;
  document.getElementById('next2').onclick = confirmStep;
}
function confirmStep() {
  const sel = document.querySelector('input[name=slot]:checked'); if (!sel) return;
  let i = Number(sel.value); if (BUG === 'ui_books_wrong_slot' && slots.length > 1) i = (i + 1) % slots.length;
  current.slot = slots[i];
  const w = document.getElementById('wizard');
  w.innerHTML = `<h3>Schedule Service</h3><p>Confirm</p><p>${slots[Number(sel.value)].date} · ${slots[Number(sel.value)].time}</p>
    <button id="confirm">Confirm Booking</button>`;
  document.getElementById('confirm').onclick = book;
}
async function book() {
  const s = current.slot;
  await fetch('/api/schedule/book', {method:'POST', headers:{'Content-Type':'application/json'}, body: JSON.stringify({
    vin: current.vin, slot_id: s.slot_id, dealer_id: s.dealer_id, dealer_name: s.dealer_name, date: s.date, time: s.time,
    component: current.component, service_type: current.service_type})});
  document.getElementById('wizard').hidden = true;
  await table();
}
['site','model','priority','risk'].forEach(id => document.getElementById(id).onchange = table);
header(); table();
</script></body></html>"""
