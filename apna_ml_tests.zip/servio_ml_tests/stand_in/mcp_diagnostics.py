"""Stand-in for the MCP server "Diagnostics & TSB" (mcp-diagnostics) - see stand_in/app.py.

JSON-RPC at /mcp: initialize (gives a session id), notifications/initialized, tools/list, tools/call.
Answers as server-sent events, as streamable-HTTP MCP servers do. get_dtc_details answers copy the
real ones seen for P0172 (found) and P099 (not found).

Fault switches (STANDIN_BUG=...):
  dtc_part_missing   a found DTC has no affected part        -> W-01 fails
  dtc_error          an unknown DTC gives a tool error       -> W-02 fails
  tool_renamed       tools/list names the tool differently   -> the MCP tool pin check fails
"""
from __future__ import annotations

import json
import os
import uuid
from http.server import BaseHTTPRequestHandler

BUG = os.environ.get("STANDIN_BUG", "")
DTCS = {
    "P0172": {"description": "System Too Rich Bank 1", "severity": "medium",
              "affected_part_id": "FUEL-INJ-021", "affected_part_name": "Fuel Injector Rail Assembly"},
    "P0217": {"description": "Engine Coolant Over Temperature Condition", "severity": "high",
              "affected_part_id": "COOL-RAD-007", "affected_part_name": "Radiator Assembly"},
}
TOOL = {"name": "get_dtc_details", "description": "Details of one DTC",
        "inputSchema": {"type": "object", "properties": {"dtc_code": {"type": "string"}}, "required": ["dtc_code"]}}


def dtc_details(code: str) -> dict:
    """Same shape as the real tool: found/resolved plus the fields, empty when not found."""
    if code in DTCS:
        d = {"dtc_code": code, **DTCS[code]}
        if BUG == "dtc_part_missing":
            d["affected_part_id"] = ""
        return {"dtc_code": code, "found": True, "resolved": True, **{k: v for k, v in d.items() if k != "dtc_code"},
                "details": d}
    return {"dtc_code": code, "found": False, "resolved": False, "description": "", "severity": "",
            "affected_part_id": "", "affected_part_name": "", "details": None}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _event(self, message: dict | None, status=200, headers=None):
        data = b"" if message is None else f"event: message\ndata: {json.dumps(message)}\n\n".encode()
        self.send_response(status)
        if message is not None:
            self.send_header("Content-Type", "text/event-stream")
        self.send_header("Content-Length", str(len(data)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if self.path.rstrip("/") != "/mcp":
            return self._event({"error": "Not Found"}, 404)
        msg = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        method, mid = msg.get("method"), msg.get("id")
        if method == "initialize":
            return self._event({"jsonrpc": "2.0", "id": mid, "result": {
                "protocolVersion": msg["params"]["protocolVersion"], "capabilities": {"tools": {}},
                "serverInfo": {"name": "Diagnostics & TSB", "version": "4.0.11"}}},
                headers={"mcp-session-id": uuid.uuid4().hex})
        if not self.headers.get("mcp-session-id"):
            return self._event({"jsonrpc": "2.0", "id": mid, "error": {"code": -32600, "message": "No session"}}, 400)
        if method == "notifications/initialized":
            return self._event(None, 202)
        if method == "tools/list":
            tool = dict(TOOL, name="get_dtc_info") if BUG == "tool_renamed" else TOOL
            return self._event({"jsonrpc": "2.0", "id": mid, "result": {"tools": [tool]}})
        if method == "tools/call" and msg["params"]["name"] == "get_dtc_details":
            code = str(msg["params"]["arguments"].get("dtc_code", ""))
            if BUG == "dtc_error" and code not in DTCS:
                return self._event({"jsonrpc": "2.0", "id": mid, "result": {
                    "content": [{"type": "text", "text": "Error: lookup failed"}], "isError": True}})
            d = dtc_details(code)
            return self._event({"jsonrpc": "2.0", "id": mid, "result": {
                "content": [{"type": "text", "text": json.dumps(d)}], "structuredContent": d, "isError": False}})
        return self._event({"jsonrpc": "2.0", "id": mid, "error": {"code": -32601, "message": "Method not found"}})
