"""Local stand-ins for the APIs under test - ONLY to check the test code without the real services.
Not part of the framework.

    python -m stand_in.app          (from the project folder)

starts three servers, matching environment local_stand_in in config/settings.yaml:
    Fleet RUL API (predictions + scheduling)   http://127.0.0.1:8765   stand_in/fleet_rul.py
    n8n (webhook + executions API)             http://127.0.0.1:8766   stand_in/n8n.py
    MCP Diagnostics & TSB                      http://127.0.0.1:8767   stand_in/mcp_diagnostics.py

Then:  pytest --env local_stand_in
with any values in SERVIO_EMAIL, SERVIO_PASSWORD and N8N_API_KEY (the stand-ins accept anything).
STANDIN_BUG=<switch> makes one stand-in misbehave, to see a case catch it; the switches are listed
at the top of each stand-in file.
"""
from __future__ import annotations

import os
import threading
from http.server import ThreadingHTTPServer

from stand_in import fleet_rul, mcp_diagnostics, n8n

SERVERS = [("Fleet RUL API", 8765, fleet_rul.Handler), ("n8n", 8766, n8n.Handler),
           ("MCP Diagnostics & TSB", 8767, mcp_diagnostics.Handler)]

if __name__ == "__main__":
    print(f"STANDIN_BUG={os.environ.get('STANDIN_BUG') or 'none'}")
    servers = []
    for name, port, handler in SERVERS:
        server = ThreadingHTTPServer(("127.0.0.1", port), handler)
        threading.Thread(target=server.serve_forever, daemon=True).start()
        servers.append(server)
        print(f"stand-in {name} on http://127.0.0.1:{port}")
    threading.Event().wait()
