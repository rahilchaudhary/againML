"""Stand-in for the Fleet RUL API (predictions + service scheduling) - see stand_in/app.py.

Prediction shapes copy the real responses (features, fleet, predict). Scheduling shapes are ASSUMED
(no real /slots or /book response seen yet). Scheduling needs the login cookie; predictions do not.

Fault switches (STANDIN_BUG=...):
  optional_affects   removing unit_id changes the prediction          -> TC-01 fails
  silent_default     missing mandatory feature is filled silently      -> TC-02 fails
  boundary           RUL equal to the CRITICAL cut-off gives CRITICAL  -> TC-04 fails
  negative_history   one history record has a negative RUL             -> TC-07 fails
  no_slots           no slots offered                                  -> H-01..H-03 BLOCKED
  past_slot          one slot is dated yesterday                       -> H-01 fails
  booking_mismatch   the booking moves the time by an hour             -> H-02 fails
  double_offer       a booked slot is still offered                    -> H-03 fails
  book_without_slot  a booking without slot_id is accepted             -> H-04 fails
  api_changed        /openapi.json lists one more endpoint             -> the Swagger pin check fails
  rul_inflated       history predicts 60% more RUL than the model would -> R-01 fails
  agg_unsorted       dashboard not ranked by downtime risk              -> A-01 fails
  agg_filter         risk_level filter lets one other vehicle through   -> A-02 fails
  agg_top_limit      top accepts n = 0                                  -> A-03 fails
  agg_summary_count  summary counts one vehicle too many                -> A-04 fails
  agg_component_mismatch  profile shows another risk for a component    -> A-05 fails
  agg_min_rul        profile min RUL is not the lowest component RUL    -> A-06 fails
Aggregation shapes are ASSUMED (the Swagger gives no response schemas).
Also serves stand-in pages for the UI cases (/login, /v2) - see stand_in/ui_pages.py.
STANDIN_FLEET_SIZE=N adds synthetic vehicles, to see how TC-07 behaves on a large fleet.
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import date, datetime, timedelta, timezone
from http.server import BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import parse_qs, urlparse

from stand_in.ui_pages import DASHBOARD_HTML, LOGIN_HTML

BUG = os.environ.get("STANDIN_BUG", "")
SPEC = Path(__file__).resolve().parent.parent / "spec" / "fleet_rul_openapi_2026-11-06.json"
TOKEN = "standin-session"
BOOKINGS: dict[str, dict] = {}            # booking_id -> booking
READY_AT = [0.0]                           # /api/ready says false until this time (after a refresh)
# A second, synthetic component per vehicle, so vehicle profiles aggregate more than one component.
ENGINE_OIL_RUL_DAYS = [0.4, 4.0, 45.0]
CUT = {"radiator": (100.0, 300.0)}
REQUIRED = ["radiator_age_hours", "ambient_c", "engine_load_pct", "payload_pct", "blockage_pct",
            "coolant_c", "temperature_drop_c", "coolant_flow_lpm", "overtemperature_minutes",
            "cooling_dtc_count"]
OPTIONAL = ["unit_id", "vin", "vehicle_model", "site", "timestamp"]
FLEET = [
    {"unit_id": "RAD-141", "vin": "MAT426031M1J10142", "vehicle_model": "TATA Signa SYN 6x4", "site": "North Pit",
     "timestamp": "2025-03-30T13:00:00", "radiator_age_hours": 2225, "ambient_c": 32.6, "engine_load_pct": 92.4,
     "payload_pct": 103.8, "blockage_pct": 79.3, "coolant_c": 99.1, "temperature_drop_c": 7.4,
     "coolant_flow_lpm": 28.0, "overtemperature_minutes": 0, "cooling_dtc_count": 0},
    {"unit_id": "RAD-135", "vin": "MAT353021S3C10136", "vehicle_model": "TATA Prima SYN 6x4", "site": "Highway Site",
     "timestamp": "2025-04-21T10:00:00", "radiator_age_hours": 2750, "ambient_c": 37.5, "engine_load_pct": 68.8,
     "payload_pct": 116.5, "blockage_pct": 79.3, "coolant_c": 97.5, "temperature_drop_c": 7.1,
     "coolant_flow_lpm": 22.7, "overtemperature_minutes": 0, "cooling_dtc_count": 0},
    {"unit_id": "RAD-033", "vin": "MAT492531P1J10034", "vehicle_model": "TATA Signa SYN 6x4", "site": "North Pit",
     "timestamp": "2025-06-05T05:00:00", "radiator_age_hours": 3825, "ambient_c": 27.2, "engine_load_pct": 64.8,
     "payload_pct": 103.2, "blockage_pct": 79.2, "coolant_c": 94.3, "temperature_drop_c": 7.3,
     "coolant_flow_lpm": 28.0, "overtemperature_minutes": 0, "cooling_dtc_count": 0},
]

for _i in range(int(os.environ.get("STANDIN_FLEET_SIZE", 0))):
    FLEET.append(dict(FLEET[0], unit_id=f"RAD-{1000 + _i}", vin=f"MAT426031M1J{20000 + _i}"))


def risk(component: str, rul: float) -> str:
    crit, watch = CUT[component]
    if (rul <= crit) if BUG == "boundary" else (rul < crit):
        return "CRITICAL"
    return "WATCH" if rul < watch else "HEALTHY"


def predict(rec: dict) -> dict:
    """Deterministic: same features -> same numbers. Time-based fields change per call, like the real API."""
    rul = max(0.0, 900 - 0.12 * rec["radiator_age_hours"] - 4 * rec["blockage_pct"]
              - 30 * rec["cooling_dtc_count"] + 2 * rec["coolant_flow_lpm"])
    if BUG == "optional_affects" and rec.get("unit_id"):
        rul += 1.0
    now = datetime.now(timezone.utc)
    out = {k: rec.get(k, d) for k, d in zip(OPTIONAL, ["", "", "Unknown", "Unknown", now.isoformat()])}
    out.update({k: rec[k] for k in REQUIRED})
    lower = round(rul * 0.7, 4)
    out.update({"predicted_rul_hours": round(rul, 4), "rul_lower_hours": lower,
                "rul_upper_hours": round(rul * 1.25, 4), "rul_days": round(rul / 18, 1),
                "risk_level": risk("radiator", lower), "recommended_action": "Continue monitoring",
                "cooling_health_score": 59.4, "health_score": 59.4, "failure_probability_pct": 40.6,
                "primary_reason": "Normal monitored degradation", "generated_at_utc": now.isoformat(),
                "service_due_date": (now + timedelta(hours=rul)).isoformat(),
                "service_window_start": (now + timedelta(hours=rul * 0.8)).isoformat(),
                "service_window_end": (now + timedelta(hours=rul * 1.2)).isoformat(),
                "service_urgency": "SCHEDULED", "component": "radiator"})
    return out


def level(rul_days: float) -> str:
    return "CRITICAL" if rul_days < 1 else "WATCH" if rul_days < 10 else "HEALTHY"


def vehicle_components(i: int, rec: dict) -> list[dict]:
    rad = predict(rec)
    if BUG == "agg_component_mismatch" and i == 0:
        rad["risk_level"] = "HEALTHY" if rad["risk_level"] != "HEALTHY" else "WATCH"
    oil_days = ENGINE_OIL_RUL_DAYS[i % 3]
    keys = ("component", "health_score", "rul_days", "risk_level", "failure_probability_pct",
            "recommended_action", "primary_reason")
    return [{k: rad.get(k) for k in keys},
            {"component": "engine_oil", "health_score": round(min(100.0, oil_days * 2 + 10), 1),
             "rul_days": oil_days, "risk_level": level(oil_days), "failure_probability_pct": 20.0,
             "recommended_action": "Oil change", "primary_reason": "Oil degradation"}]


def profiles() -> list[dict]:
    order = ["HEALTHY", "WATCH", "CRITICAL"]
    out = []
    for i, rec in enumerate(FLEET):
        comps = vehicle_components(i, rec)
        worst = max((c["risk_level"] for c in comps), key=order.index)
        health = round(sum(c["health_score"] for c in comps) / len(comps), 1)
        min_rul = min(c["rul_days"] for c in comps)
        if BUG == "agg_min_rul" and i == 1:
            min_rul += 3
        priority = {"CRITICAL": "P1", "WATCH": "P2", "HEALTHY": "P3"}[worst]
        out.append({"vehicle_id": rec["vin"], "vin": rec["vin"], "vehicle_model": rec["vehicle_model"],
                    "site": rec["site"], "health_score": health, "min_rul_days": min_rul, "risk_level": worst,
                    "priority": priority, "downtime_risk_score": round(100 - health + 10 * order.index(worst), 1),
                    "recommended_action": "See components", "components": comps})
    out.sort(key=lambda v: v["downtime_risk_score"], reverse=BUG != "agg_unsorted")
    return out


def slots_for(vin: str, component: str) -> list[dict]:
    """Three slots over the next days, minus the booked ones."""
    if BUG == "no_slots":
        return []
    out = []
    for i, (days, hour) in enumerate(((1, "09:00"), (2, "11:00"), (3, "14:00"))):
        day = date.today() + timedelta(days=days)
        if BUG == "past_slot" and i == 0:
            day = date.today() - timedelta(days=1)
        out.append({"slot_id": f"SLT-{day:%Y%m%d}-{hour[:2]}00-D01", "dealer_id": "D01",
                    "dealer_name": "Pune Service Centre", "date": day.isoformat(), "time": hour,
                    "service_type": f"{component.replace('_', ' ').title()} inspection"})
    booked = {b["slot_id"] for b in BOOKINGS.values()}
    if BUG == "double_offer":
        booked = set()
    return [s for s in out if s["slot_id"] not in booked]


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, status, body, headers=None):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def _html(self, status, html, headers=None):
        data = html.encode()
        self.send_response(status)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        for k, v in (headers or {}).items():
            self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    def _logged_in(self) -> bool:
        return f"sentio_token={TOKEN}" in self.headers.get("Cookie", "")

    def do_DELETE(self):
        p = urlparse(self.path).path.strip("/").split("/")
        if p[:3] == ["api", "schedule", "booking"] and len(p) == 4:
            if not self._logged_in():
                return self._send(401, {"detail": "Not authenticated"})
            if BOOKINGS.pop(p[3], None) is None:
                return self._send(404, {"detail": "Booking not found"})
            return self._send(200, {"deleted": True, "booking_id": p[3]})
        self._send(404, {"detail": "Not Found"})

    def do_GET(self):
        p = urlparse(self.path).path.strip("/").split("/")
        if p == ["login"]:
            return self._html(200, LOGIN_HTML)
        if p == ["v2"]:
            if not self._logged_in():
                return self._html(303, "", {"Location": "/login?next=/v2"})
            return self._html(200, DASHBOARD_HTML.replace("__BUG__", BUG))
        if p == ["openapi.json"]:
            spec = json.loads(SPEC.read_text())
            if BUG == "api_changed":
                spec["paths"]["/api/schedule/reschedule"] = {"post": {"tags": ["Service Scheduling"]}}
            return self._send(200, spec)
        if p == ["api", "ready"]:
            import time
            return self._send(200, {"ready": time.time() >= READY_AT[0]})
        if p[:2] == ["api", "aggregate"]:
            return self._aggregate(p[2:], {k: v[0] for k, v in parse_qs(urlparse(self.path).query).items()})
        if p == ["api", "schedule", "bookings"]:
            if not self._logged_in():
                return self._send(401, {"detail": "Not authenticated"})
            return self._send(200, {"bookings": list(BOOKINGS.values())})
        if p == ["health"]:
            return self._send(200, {"status": "ok"})
        if p == ["api", "registry"]:
            return self._send(200, {"radiator": {"subsystem": "cooling", "trained": True}})
        if p[:2] == ["api", "predict"] and len(p) == 4 and p[3] == "features" and p[2] in CUT:
            return self._send(200, {"component": p[2], "display_name": "Radiator", "required_features": REQUIRED,
                                    "feature_count": len(REQUIRED), "optional_metadata": OPTIONAL,
                                    "endpoint": f"POST /api/predict/{p[2]}"})
        if len(p) == 3 and p[0] == "api" and p[2] == "fleet" and p[1] in CUT:
            return self._send(200, [predict(r) for r in FLEET])
        if len(p) == 5 and p[0] == "api" and p[2] == "vehicle" and p[4] == "history" and p[1] in CUT:
            rec = next((r for r in FLEET if r["unit_id"] == p[3]), None)
            if rec is None:
                return self._send(404, {"detail": "Vehicle not found"})
            hist = [predict(rec), predict(dict(rec, radiator_age_hours=rec["radiator_age_hours"] - 200))]
            hist[1]["predicted_rul_hours"] = round(hist[0]["predicted_rul_hours"] + 190, 4)   # 200 h younger: ~190 h more life
            if BUG == "negative_history" and p[3] == "RAD-033":
                hist[1]["rul_lower_hours"] = -12.5
            if BUG == "rul_inflated":
                for h in hist:
                    h["predicted_rul_hours"] = round(h["predicted_rul_hours"] * 1.6, 4)
            return self._send(200, hist)
        self._send(404, {"detail": "Not Found"})

    def _aggregate(self, p: list[str], q: dict):
        import time
        all_profiles = profiles()
        if p == ["fleet", "refresh"]:
            READY_AT[0] = time.time() + 1.0
            return self._send(200, {"refreshed": True, "vehicles": len(all_profiles)})
        if p == ["fleet", "dashboard"]:
            rows = [v for v in all_profiles
                    if all(str(v.get({"model": "vehicle_model"}.get(k, k))) == val for k, val in q.items())]
            if BUG == "agg_filter" and "risk_level" in q:
                rows += [v for v in all_profiles if v not in rows][:1]
            return self._send(200, [{k: v for k, v in r.items() if k != "components"} for r in rows])
        if p == ["fleet", "top"]:
            try:
                n = int(q.get("n", 10))
            except ValueError:
                n = -1
            if not (0 if BUG == "agg_top_limit" else 1) <= n <= 100:
                return self._send(422, {"detail": [{"type": "less_than_equal" if n > 100 else "greater_than_equal",
                                                    "loc": ["query", "n"], "msg": "Input out of range"}]})
            return self._send(200, [{k: v for k, v in r.items() if k != "components"} for r in all_profiles[:n]])
        if p == ["fleet", "summary"]:
            count = lambda f: {val: sum(1 for v in all_profiles if v[f] == val) for val in {v[f] for v in all_profiles}}
            total = len(all_profiles) + (1 if BUG == "agg_summary_count" else 0)
            return self._send(200, {"total_vehicles": total, "priority_counts": count("priority"),
                                    "risk_distribution": count("risk_level"),
                                    "top_at_risk": [v["vehicle_id"] for v in all_profiles[:5]]})
        if len(p) in (2, 3) and p[0] == "vehicle":
            v = next((v for v in all_profiles if v["vehicle_id"] == p[1]), None)
            if v is None:
                return self._send(404, {"detail": "Vehicle not found"})
            if len(p) == 3 and p[2] == "components":
                return self._send(200, {"vehicle_id": v["vehicle_id"], "components": v["components"]})
            return self._send(200, {k: val for k, val in v.items() if k != "components"})
        self._send(404, {"detail": "Not Found"})

    def do_POST(self):
        p = urlparse(self.path).path.strip("/").split("/")
        n = int(self.headers.get("Content-Length", 0))
        raw = self.rfile.read(n) or b"{}"
        if p == ["login"]:
            form = {k: v[0] for k, v in parse_qs(raw.decode()).items()}
            if not (form.get("email") and form.get("password")):
                return self._send(422, {"detail": "email and password required"})
            return self._send(303, {}, {"Location": "/v2",
                                        "Set-Cookie": f"sentio_token={TOKEN}; HttpOnly; Path=/"})
        body = json.loads(raw)
        if p[:2] == ["api", "schedule"] and len(p) == 3 and p[2] in ("slots", "book"):
            if not self._logged_in():
                return self._send(401, {"detail": "Not authenticated"})
            required = ["vin"] if p[2] == "slots" else (["vin"] if BUG == "book_without_slot" else ["vin", "slot_id"])
            missing = [f for f in required if f not in body]
            if missing:
                return self._send(422, {"detail": [{"type": "missing", "loc": ["body", f], "msg": "Field required"}
                                                   for f in missing]})
            if p[2] == "slots":
                return self._send(200, {"available_slots": slots_for(body["vin"], body.get("component", ""))})
            booking = {"booking_id": f"BK-{uuid.uuid4().hex[:6].upper()}", "status": "confirmed",
                       **{k: body.get(k, "") for k in ("vin", "component", "slot_id", "dealer_id",
                                                        "dealer_name", "date", "time", "service_type")},
                       "created_at": datetime.now(timezone.utc).isoformat()}
            if BUG == "booking_mismatch":
                booking["time"] = "10:00" if booking["time"] != "10:00" else "11:00"
            BOOKINGS[booking["booking_id"]] = booking
            return self._send(201, booking)
        if p[:2] == ["api", "recommendation"] and len(p) == 3 and p[2] in CUT:
            rul = body.get("rul_lower_hours")
            if "rul_lower_hours" not in body:
                return self._send(422, {"detail": [{"type": "missing", "loc": ["body", "rul_lower_hours"],
                                                    "msg": "Field required"}]})
            if not isinstance(rul, (int, float)):
                return self._send(422, {"detail": [{"type": "float_type", "loc": ["body", "rul_lower_hours"],
                                                    "msg": "Input should be a valid number"}]})
            r = risk(p[2], rul)
            return self._send(200, {"component": p[2], "rul_lower_hours": rul, "vin": body.get("vin"),
                                    "risk_level": r, "recommended_action": "...", "service_urgency": "..."})
        if p[:2] == ["api", "predict"] and len(p) == 3 and p[2] in CUT:
            missing = [f for f in REQUIRED if f not in body]
            if missing and BUG == "silent_default":
                body.update({f: 0 for f in missing})
                missing = []
            if missing:
                return self._send(422, {"detail": {"error": "Missing required features",
                                                   "missing_features": missing}})
            return self._send(200, predict(body))
        self._send(404, {"detail": "Not Found"})

