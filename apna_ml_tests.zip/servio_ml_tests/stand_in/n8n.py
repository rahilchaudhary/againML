"""Stand-in for n8n: the Proactive Health Nudge webhook and the executions API - see stand_in/app.py.

The webhook answers at once and runs the workflow "in the background" (finished after ~2 s, so the
tests have to wait and poll as with the real n8n). Executions copy the shape of the real one seen
(runData per node; tool calls in inputOverride; agent output as JSON text). Only the nodes the tests
read are reproduced. The executions API needs the X-N8N-API-KEY header (any value here).

Fault switches (STANDIN_BUG=...):
  wf_error           the run ends with status error                        -> W-03 fails
  wf_skips_tool      the agent answers without calling the diagnostics tool -> W-04 fails
  wf_missing_field   customer_summary is missing from the agent output      -> W-05 fails
  wf_severity        the agent says "High" for a medium DTC                 -> W-06 fails
"""
from __future__ import annotations

import json
import os
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler
from urllib.parse import parse_qs, urlparse

from stand_in.mcp_diagnostics import dtc_details

BUG = os.environ.get("STANDIN_BUG", "")
WORKFLOW_ID = "h1z9yLUrhKcWHqLA"
EXECUTIONS: list[dict] = []
_lock = threading.Lock()


def node(kind: str, items: list[dict], inputs: list[dict] | None = None) -> list[dict]:
    run = {"executionStatus": "success", "data": {kind: [[{"json": j} for j in items]]}}
    if inputs is not None:
        run["inputOverride"] = {kind: [[{"json": j} for j in inputs]]}
    return [run]


def run_workflow(ex: dict, body: dict) -> None:
    time.sleep(2)
    codes = list(dict.fromkeys(d["dtc_code"] for d in body["payload"]["dtc_list"] if d.get("dtc_code")))
    details = [dtc_details(c) for c in codes]
    run_data = ex["data"]["resultData"]["runData"]
    if BUG != "wf_skips_tool":
        run_data["Single DTC Diagnostics Tool"] = [
            node("ai_tool", [{"output": json.dumps(d)}], [{"dtc_code": d["dtc_code"]}])[0] for d in details]
        run_data["mcp-diagnostics"] = [
            node("ai_tool", [{"response": [{"type": "text", "text": json.dumps(d)}], "structuredContent": d}],
                 [{"dtc_code": d["dtc_code"], "tool": "mcp_diagnostics_get_dtc_details"}])[0] for d in details]
    order = ["low", "medium", "high", "critical"]
    worst = max((d["severity"] for d in details if d["severity"]), key=order.index, default="low")
    if BUG == "wf_severity":
        worst = "high" if worst != "high" else "low"
    output = {"fault_found": "The engine is getting more fuel than it should.",
              "advice_action_required": "Please book a workshop inspection of the fuel delivery system.",
              "recommended_timeline": "Within the next 2 to 5 days.",
              "severity": f"{worst.title()}: the vehicle may be usable for a short time but should be checked soon.",
              "intermediate_steps": ["Drive only if necessary.", "Avoid heavy loads."],
              "customer_summary": "Your vehicle needs a fuel system check soon."}
    if BUG == "wf_missing_field":
        del output["customer_summary"]
    run_data["Service Advisor Agent"] = node("main", [{"output": json.dumps(output, indent=2)}])
    with _lock:
        ex["status"] = "error" if BUG == "wf_error" else "success"
        ex["finished"] = BUG != "wf_error"
        ex["stoppedAt"] = datetime.now(timezone.utc).isoformat()
        if BUG == "wf_error":
            ex["data"]["resultData"]["error"] = {"message": "Service Advisor Agent: model timeout"}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, status, body):
        data = json.dumps(body).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def do_POST(self):
        if urlparse(self.path).path != "/webhook/nudge-kpit-demo":
            return self._send(404, {"message": "webhook not registered"})
        body = json.loads(self.rfile.read(int(self.headers.get("Content-Length", 0))) or b"{}")
        with _lock:
            ex = {"id": str(3900 + len(EXECUTIONS)), "finished": False, "mode": "webhook", "status": "running",
                  "startedAt": datetime.now(timezone.utc).isoformat(), "stoppedAt": None, "workflowId": WORKFLOW_ID,
                  "data": {"resultData": {"runData": {"Webhook": node("main", [{"body": body}])}}}}
            EXECUTIONS.insert(0, ex)
        threading.Thread(target=run_workflow, args=(ex, body), daemon=True).start()
        self._send(200, {"message": "Workflow was started"})

    def do_GET(self):
        url = urlparse(self.path)
        if url.path != "/api/v1/executions":
            return self._send(404, {"message": "not found"})
        if not self.headers.get("X-N8N-API-KEY"):
            return self._send(401, {"message": "'X-N8N-API-KEY' header required"})
        q = {k: v[0] for k, v in parse_qs(url.query).items()}
        with _lock:
            found = [e for e in EXECUTIONS if e["workflowId"] == q.get("workflowId")][: int(q.get("limit", 20))]
            data = json.loads(json.dumps(found))
        self._send(200, {"data": data, "nextCursor": None})
