# Servio ML tests

Twenty-nine test cases from `testdata/servio_ml_test_cases.xlsx`, against three APIs and the dashboard UI:

| Cases | What | Against |
|---|---|---|
| TC-01 .. TC-07 | Fleet RUL model: predictions, risk, data | Fleet RUL API |
| H-01 .. H-04 | Handover: the model flags a vehicle, a service slot is offered and booked | Fleet RUL API (Service Scheduling) |
| W-01 .. W-06 | Proactive Health Nudge workflow up to the Service Advisor Agent, and the MCP diagnostics it uses | n8n, MCP Diagnostics & TSB |
| A-01 .. A-07 | Aggregation: vehicle profiles, fleet dashboard, summary - consistency only until the rules are agreed (A-07 blocked) | Fleet RUL API (Aggregation) |
| U-01 .. U-04 | UI: login, Fleet Dashboard, filter, Schedule wizard - each checked against the API behind it | Dashboard UI (`/v2`) |
| R-01 | RUL accuracy: predicted RUL against the RUL expected from a known end of life; metrics, quality gates, HTML report | Fleet RUL API (history) |

Contents: 1 Quick start · 2 Design principles · 3 Project map · 4 How it works · 5 Reports ·
6 Extending, module by module · 7 Checked locally only

---

## 1. Quick start

**Install** (Python 3.10 or newer), from this folder:

```bash
python -m venv .venv
.venv\Scripts\activate                 # Windows (Git Bash: source .venv/Scripts/activate; Linux/macOS: source .venv/bin/activate)
pip install -r requirements.txt
playwright install chromium            # once, for the UI cases
```

**Credentials** - environment variables only, never in config, the workbook or the repository:

| Variable | For | Note |
|---|---|---|
| `SERVIO_EMAIL`, `SERVIO_PASSWORD` | Fleet RUL API and UI login (TC-, H-, A-, U-, R- cases) | A **fleet_manager test user**, not admin |
| `N8N_API_KEY` | n8n executions API (W-03 .. W-06) | Sent only to the executions API, never to the webhook |

```powershell
$env:SERVIO_EMAIL="..."; $env:SERVIO_PASSWORD="..."; $env:N8N_API_KEY="..."     # PowerShell, this window only
```

A missing variable fails only the cases that need it, with a message naming it. In Jenkins, bind credentials
to these names. Also fill in the MCP server address in `config/settings.yaml` (`environments: dev: mcp_diagnostics`).

**Run**

```bash
pytest -v -rs                                   # everything; -rs lists every BLOCKED / N/A with its reason
pytest --suite smoke                            # smoke / sanity / regression
pytest -k "H-"                                  # one area: TC- model, H- handover, W- workflow, A- aggregation, U- UI, R- RUL accuracy
pytest --component radiator                     # one component (also --system, --subsystem)
pytest --env dev                                # environment from config/settings.yaml
pytest -k "U-" --headed                         # UI cases with the browser visible
pytest --vehicle-sample 0                       # per-vehicle cases check every vehicle (e.g. nightly)
pytest -k TC-07 --vehicle-seed 412907           # repeat the exact vehicles of an earlier run
pytest --alluredir=reports/allure-results       # also write the Allure report (section 5)
pytest tests/unit                               # unit tests of framework calculations only (no API)
```

---

## 2. Design principles

The design follows a few rules. Each change should keep them; when a change seems to need breaking one,
that is the moment to discuss the design, not to work around it.

| # | Principle | What it means here | Where you see it |
|---|---|---|---|
| 1 | **Separate what, how much and how** | *What* is tested is in the workbook, *the agreed answers* (cut-offs, field lists, rules) are in config, *how* it is tested is in code. A tester changes the first two without reading code. | `testdata/*.xlsx`, `config/`, `framework/` + `tests/` |
| 2 | **Independent oracle** | Expected answers never come from the system under test. Cut-offs, agreed fields and rules are written down by QA; the API is compared with them, not trusted. Not yet agreed = marked **ASSUMED REQUIREMENT**, so it is visible. | `config/components/`, `config/flows.yaml` |
| 3 | **One place for each thing** | Every API path is written once (a service), every selector once (a page object), every requirement once (config), the component hierarchy once (settings, used by every track), every secret nowhere (environment). | `framework/services/`, `framework/pages/`, `config/`, `framework/auth.py` |
| 4 | **Contract first, fail fast** | The APIs are pinned (Swagger, MCP tool list). Before any call, the run checks every path, word and name against them and stops with a clear message; a live-vs-pinned check reports when an API changes. | `spec/`, start-up checks in `tests/conftest.py`, `tests/test_contracts.py` |
| 5 | **Few shapes of test, written once** | Every case is one of three shapes - Send & Verify, Read & Verify, Flow & Verify. Each shape is code written once; a new case reuses it. No keywords to learn. Model accuracy too is a Read & Verify case (R-01), not a separate tool: one runner, one selection, one report. | `framework/flows.py` |
| 6 | **Grow by data, not by code** | A new component, a new row, a new environment needs no code. A new kind of check needs one rule in one place. | Section 6 |
| 7 | **Objects that hide the mechanics** | Tests speak in business steps (`services.scheduling.book(...)`, `dashboard.filter_risk_level(...)`); HTTP, login, JSON-RPC and selectors live underneath. | Service objects, page objects, `api_client.py` |
| 8 | **Thin UI on top of the API** | Detailed checks are API cases. A UI case checks that the screen shows what the API returned - few UI cases, fast and stable. | `tests/test_ui.py` |
| 9 | **Honest results** | PASS and FAIL mean the product. BLOCKED means it could not be tested now (no data, rule not agreed), NOT APPLICABLE means it does not apply, a prerequisite failure names what is missing. Nothing passes by being skipped. | Run summary, Allure categories |
| 10 | **Clean and independent runs** | A case removes what it creates (bookings), finds its own data at run time, uses a fresh browser and a unique correlation ID. Cases do not depend on each other's order. | `Flow.undo`, `workflow_run.py` |
| 11 | **Scale by sampling, reproducibly** | Per-vehicle checks take a random sample on large fleets; the seed is reported so a failing sample can be repeated. | `framework/vehicle_sample.py` |
| 12 | **Secrets never leave the machine** | Credentials come from the environment; reports mask passwords, tokens and keys. | `framework/auth.py`, `framework/reporting.py` |
| 13 | **Do not overdo** | A piece is added when a case needs it, not before. Stand-ins exist only to check the tests without the real services. | - |

---

## 3. Project map

```text
testdata/servio_ml_test_cases.xlsx   WHAT: Test Cases, Test Data, Test Data - Components
config/
  settings.yaml                      WHERE and HOW to run: APIs, environments, hierarchy, sampling
  components/<component>.yaml        AGREED ANSWERS per component: cut-offs, mandatory/optional fields, RUL accuracy limits
  flows.yaml                         AGREED ANSWERS for handover, workflow, aggregation, UI
  rul_accuracy_report.yaml           how the RUL accuracy report looks and reads (no requirements)
spec/                                pinned API contracts (Swagger, MCP tool list), named by date
framework/                           HOW: the pieces (section 4) - services/, pages/, flows, client ...
tests/                               one test function per test case, marked with its TC-ID
  unit/                              unit tests of framework calculations (no API) - run with every run
testdata/requests/, testdata/assumed/   full requests per API path; assumed data until APIs exist
testdata/reference_life/             known end of life per vehicle and cycle - the ground truth for R-01
stand_in/                            local stand-ins of all APIs and pages - only to check the tests
reports/                             run outputs: Allure results, screenshots, rul_accuracy/ (not kept in the repository)
requirements.txt                     every Python package, with tested versions
```

**What lives where**

| Thing | Where | Per component? |
|---|---|---|
| Test cases, API path + method per case | workbook, sheet **Test Cases** | No - `{component}` is filled in at run time |
| Test data for every component | workbook, sheet **Test Data** | No |
| Test data tied to one component | workbook, sheet **Test Data - Components** (Component column) | Yes |
| Every valid API path and method | `spec/fleet_rul_openapi_2026-11-06.json` | No |
| Every MCP tool the tests call | `spec/mcp_diagnostics_tools_ASSUMED.json` (replace with the real `tools/list`) | No |
| Cut-offs, agreed mandatory/optional fields | `config/components/<component>.yaml` | Yes, one file each |
| Handover, workflow, aggregation, UI requirements | `config/flows.yaml` | No |
| Full prediction request | `testdata/requests/predict/<component>.json` | Yes |
| Webhook request of a workflow | `testdata/requests/workflows/<workflow>.json` | No |
| Assumed training/testing sets (TC-05) | `testdata/assumed/<component>/` | Yes |
| Aggregation response field names (assumed) | top of `tests/test_aggregation.py` | No |
| Screen labels, buttons, selectors | `framework/pages/` | No |
| RUL accuracy limits (R-01) | `config/components/<component>.yaml` -> `rul_accuracy` | Yes |
| Reference lives (R-01 ground truth) | `testdata/reference_life/<component>.csv` (location: settings `reference_lives`) | Yes |
| How the RUL accuracy report looks | `config/rul_accuracy_report.yaml` | No |

**`config/settings.yaml` - update when**

| Section | Update when |
|---|---|
| `apis` | A new API under test; an API changes (re-pin `swagger` / `tools`); how it logs in |
| `environments` | A new environment, an address changes, or an n8n workflow ID changes |
| `excel` | The workbook moves or is renamed |
| `record_sources` | The training/testing APIs exist: `type: file` -> `type: api` |
| `just_below_step` | Almost never - QA's "Just below" (0.01) |
| `vehicle_sample_size` | To trade run time against coverage for per-vehicle cases; default 25 |
| `hierarchy` | A component is ready for testing, or the sub-system grouping changes. The one source of system -> sub-system -> component for every track; sub-system names are the product's own |
| `display_names` | A report should show a system, sub-system or component under a readable name |

**Anchors - names that must match across files.** All are checked at start-up; a mismatch stops the run before any call.

| Anchor | Links | If it does not match |
|---|---|---|
| Component name (`radiator`) | settings `hierarchy`, Applicable/Excluded columns, Component column, `config/components/<name>.yaml`, `testdata/requests/predict/<name>.json` | Run stops naming it |
| API path + Method | API/Method columns, a service, the pinned Swagger | Run stops: not covered by a service, or not in Swagger |
| MCP tool name | `TOOLS` in `mcp_service.py`, pinned tool list | Run stops |
| API name (`fleet_rul`, `n8n`, `mcp_diagnostics`) | settings `apis` and `environments`, `API` in each service | Run stops |
| Workflow node names | `config/flows.yaml` `nodes`, the n8n workflow | W-04 .. W-06 fail naming the nodes that ran |
| TC-ID | Test Cases sheet, `@pytest.mark.case("..")` | Traceability check fails |

---

## 4. How it works

**The three shapes of test case** (Category column)

| Category | Shape | Test data | Cases |
|---|---|---|---|
| Send & Verify | Change one input of a valid full request (or one query parameter of a GET), send it, check the response | Test Data rows | TC-01..04, H-04, W-01, W-02, A-02, A-03 |
| Read & Verify | Fetch existing records, apply a rule to every one, report all failures together | none | TC-05..07, A-01, A-04..07, R-01 |
| Flow & Verify | Several calls or screen actions in order, each using what the previous returned; anything created is removed afterwards | none | H-01..03, W-03..06, U-01..04 |

- In a Flow & Verify case the API and Method columns have one line per call, in order. A UI case's API column
  starts with the page (`/v2`, in Swagger under tag UI), followed by the APIs it compares the screen with.
- Applicable Components `n/a` = not about a component (W- and most A-/U- cases): runs once, and not when the
  run is narrowed with `--system`, `--subsystem` or `--component`.
- A Status other than `Ready` (e.g. `Blocked: weighting awaited from the ML team`) is reported BLOCKED with that text.

**The pieces (`framework/`)**

| Piece | Its only job |
|---|---|
| `settings.py` | Loads config: APIs, environments, hierarchy, component requirements, `flows.yaml` |
| `case_reader.py` | Reads the three sheets; stops on any unknown word (Category, Suite, Method, Action) |
| `component_selector.py` | Applicable minus Excluded, within the run's scope. Exclusion wins; empty = NOT APPLICABLE |
| `swagger.py` | Says whether a method + path exists in a pinned Swagger |
| `api_client.py` | HTTP only, one client per API; checks each path against its Swagger; logs in on first use; hands each call to the report |
| `auth.py` | How each API logs in; credentials from environment variables |
| `connections.py` | Builds clients and services from settings - for the tests and any script outside pytest |
| `rul_accuracy/` | RUL accuracy: reference lives, history, the calculation (pure functions), interpretation, report and index |
| `services/` | One service object per Swagger tag, workflow or MCP server: prediction, recommendation, fleet, system, auth, scheduling, aggregation, n8n, mcp, ui. The only place a path is written |
| `pages/` | One page object per page or dialog: login, Fleet Dashboard, Schedule wizard. The only place a selector is written |
| `request_builder.py` | Full request + one row's action. Fixed-shape requests are pydantic models (the POJO equivalent) |
| `value_resolver.py` | Words in the Value column -> values, e.g. "Just below CRITICAL cut-off" -> 99.99 for radiator |
| `result_checker.py` | Compares a response with Expected Status / Expected Result (Test Data sheets) |
| `record_source.py` | Records for Read & Verify, from a file or an API (chosen in config) |
| `flows.py` | Send & Verify written once; `Flow` for Flow & Verify: steps, collected checks, BLOCKED, clean-up |
| `workflow_run.py` | Starts an n8n workflow through its webhook, finds the run by correlation_id, reads node data |
| `vehicle_sample.py` | Reproducible random sample of vehicles for per-vehicle cases |
| `reporting.py` | Everything that goes into the Allure report; does nothing when Allure is off |

Tests: `test_send_and_verify.py`, `test_read_and_verify.py`, `test_handover.py`, `test_workflows.py`,
`test_aggregation.py`, `test_ui.py`. Two framework checks that are not workbook cases: `test_traceability.py`
(every Ready case has a test) and `test_contracts.py` (live APIs still match the pinned copies).

**Wording the code understands (Test Data sheets)**

| Column | Allowed |
|---|---|
| Action | `Remove`, `Set` |
| Value | a number; `At CRITICAL cut-off`, `Just below CRITICAL cut-off`, `At WATCH cut-off`, `Just below WATCH cut-off`; one word without spaces used as it is (`CRITICAL`, `P1`, `P0172`); `n/a` |
| Expected Result | `CRITICAL` / `WATCH` / `HEALTHY`; `Same as full request: <field>, <field>, ...`; `Error names <field>; no <field>`; `Every record: <field> = <value>` (at least one record, all with that value); `<min> to <max> records`; `Found` / `Not found` (DTC lookup) |

**Things a run does for you**
- W-03 .. W-06 share one workflow run, started once and found by its correlation_id (about 15 s). The workflow
  continues past the Service Advisor and sends the customer message; the request file's VIN is the test customer's.
- H-02, H-03 and U-04 make real bookings and cancel them afterwards; a failed cancel names the booking to remove.
- Every A- and U- case first refreshes the vehicle profiles and waits for `/api/ready` (once per run).

---

## 5. Reports

| Report | What | How |
|---|---|---|
| Run summary | One line per TC-ID: PASS, FAIL, PARTIAL, BLOCKED, NOT APPLICABLE; the vehicle sample seed | End of every `pytest` run |
| **Allure** | Every test case with its workbook labels, steps, each HTTP call (secrets masked), UI screenshot on failure | `pytest --alluredir=reports/allure-results`, then `allure serve reports/allure-results` |
| RUL accuracy (R-01) | Per component: metrics, quality gates, charts, interpretation; evidence JSON and CSV; an index of all components by system and sub-system | `reports/rul_accuracy/` (`index.html`), and attached to R-01 in Allure |
| Screenshots | The screen when a UI case fails | `reports/screenshots/` (also in Allure) |

**Allure, in more detail.** The Allure command line needs Java; install it once (`npm install -g allure-commandline`,
or `scoop install allure` on Windows), or use the Jenkins Allure plugin, which reads `reports/allure-results`.

| Allure view | Shows |
|---|---|
| Suites | Area (Fleet RUL model, Handover, Workflows, Aggregation, UI, RUL accuracy) -> Category -> test case -> each run (component, row) |
| Behaviors | Area -> test case -> component |
| Categories | Product defects · Prerequisite failed (environment, credentials, data) · Blocked · Not applicable · Test errors |
| A test | Title from the workbook, tag = suite, severity (Smoke critical, Sanity normal, Regression minor), description = Expected Result, Prerequisites, API and the Test Data row; steps; HTTP calls as attachments |
| Environment | The environment, every API address and every pinned contract used |

**In Jenkins**: run `pytest --alluredir=reports/allure-results`; publish `reports/allure-results` with the Allure
plugin and `reports/rul_accuracy/` with the HTML Publisher plugin (entry page `index.html`). One run, two views:
Allure for every case, the RUL accuracy pages for the model's accuracy in depth.

---

## 6. Extending, module by module

**At a glance**

| Change | Workbook | Config / data | Code |
|---|---|---|---|
| New component | Component-specific rows | settings hierarchy, component profile, request file, assumed sets | None |
| New case of an existing shape | Test Cases row (+ Test Data rows for Send & Verify) | Requirements in config if new | One test function |
| New workflow | Test Cases rows | Workflow ID per environment, webhook request, node names | Webhook in the n8n service; tests |
| New MCP tool | Test Cases rows | Re-pin the tool list | Add to `TOOLS` + one method |
| New UI case | Test Cases row (page first in API column) | `flows.yaml` (ui) if needed | Test function; page object methods for new screen parts |
| New page or dialog | - | - | Path in the `ui` service; one page object |
| New endpoint in an existing API area | - | Re-pin Swagger if new | One method in that service |
| New API area / new API | - | Re-pin; `apis` + `environments` for a new API | One service file + one line |
| New kind of Expected Result / Value word | Use it | - | One rule in `result_checker.py` / `value_resolver.py` |
| API changed | - | Re-pin | Only what the run flags |
| RUL accuracy for a component | - | `rul_accuracy` in its profile; reference lives | None |

### 6.1 Components (radiator today; turbocharger and others next)
A component is data. Adding one:
1. Exact key from `GET /api/registry` - it goes into every URL and file name.
2. `config/settings.yaml` -> `hierarchy`: under its sub-system.
3. `config/components/<name>.yaml`: copy `radiator.yaml`; cut-offs from the ML engineer, mandatory/optional
   fields from `GET /api/predict/<name>/features` as confirmed by the ML engineer.
4. `testdata/requests/predict/<name>.json`: one record from `GET /api/<name>/fleet`, inputs only.
5. **Test Data - Components**: its rows for component-specific cases (today TC-02).
6. `testdata/assumed/<name>/`: assumed training/testing sets until those APIs exist.
7. Run `pytest -v -rs --component <name>`. Every BLOCKED line says what is still missing.

Every case with Applicable `All` now runs for it - TC-, H-, A-05 and U-04 included. No code changes.
Optionally its readable name in `display_names`. R-01 runs for it once it has RUL accuracy limits and reference lives (6.7).

### 6.2 Fleet RUL model cases (TC-)
- **Send & Verify** (change an input): Test Cases row + Test Data rows; test function in `test_send_and_verify.py`:
  ```python
  @pytest.mark.case("TC-08")
  def test_tc08_short_name(run, services, builder, settings):
      send_and_verify(run, services, builder, settings)
  ```
- **Read & Verify** (rule over records): Test Cases row, no test data; a function in `test_read_and_verify.py`
  that fetches through `services`, collects every problem, then `fail(run, problems)`.
  Records without an API yet: `record_sources` in settings as `type: file`, read with `records.records(...)`.
- Forgetting the test function is caught: the traceability check names the Ready case without a test.

### 6.3 Handover cases (H-: model -> slots -> booking)
- Requirements in `config/flows.yaml` -> `handover`: which risk levels lead to booking, which slot fields must be filled.
- Helpers in `test_handover.py`: `flagged_vehicles` / `flagged_vehicle`, `offered_slots`, `first_slot`, `book`
  (registers the cancel). A new handover case is usually three of these plus its own check:
  ```python
  @pytest.mark.case("H-05")
  def test_h05_...(run, request, services, settings):
      flow, comp = Flow(run, request), run.component.name
      vin = flagged_vehicle(flow, services, settings, comp)["vin"]
      slot = first_slot(flow, services, vin, comp)
      sent, booked = book(flow, services, vin, comp, slot)      # cancelled afterwards, pass or fail
      flow.check(<condition>, "what is wrong")
      flow.done()
  ```
- New scheduling endpoint (e.g. reschedule): re-pin Swagger, add it to `scheduling_service.py`.
- Real `/slots` and `/book` responses seen: update `slot_fields` (flows.yaml) and `BOOKING_ID` (`test_handover.py`).

### 6.4 Workflow cases (W-) and MCP tools
- **Another check on the Proactive Health Nudge run**: a test function taking the `nudge` fixture - the run is
  shared, so it costs no extra workflow run. Read nodes with `nudge.node_inputs(name)` / `node_outputs(name)`;
  node names in `flows.yaml` -> `nodes`.
- **Another workflow**:
  1. `config/settings.yaml` -> `environments` -> `workflow_ids`: its ID per environment.
  2. `framework/services/n8n_service.py`: its webhook in `ENDPOINTS` + a trigger method.
  3. `testdata/requests/workflows/<workflow>.json` (its webhook body) and a `flows.yaml` section (nodes, fields, wait).
  4. A session fixture like `nudge` calling `workflow_run.start_and_wait`, then its cases.
- **Another MCP tool or server**: re-pin the tool list; add the tool to `TOOLS` and a method calling
  `call_tool(...)` in `mcp_service.py`. Another MCP server = another API under `apis` with its own service class.
- More DTCs: rows in **Test Data** under W-01 (found) or W-02 (not found).

### 6.5 Aggregation cases (A-)
- Real response shapes: update the field names at the top of `tests/test_aggregation.py` (and the stand-in).
- Filters and limits: rows in **Test Data** (A-02, A-03) - a GET row sets a query parameter.
- Weighting agreed: weights in `flows.yaml` -> `aggregation`, the rule in `test_a07_...`, A-07 Status -> `Ready`.
- Priority (P1/P2/P3) or downtime-risk rules agreed: new Read & Verify cases, same pattern as A-06.
- Per-component checks (like A-05) use Applicable `All` and run for every component automatically.

### 6.6 UI cases (U-)
- A UI case reads what the API returns, drives the screen through page objects, and compares. Detailed checks
  stay in API cases.
- **New UI case**: Test Cases row (Flow & Verify; API column = page, then compared APIs); function in `test_ui.py`
  with `logged_in_page` (or `page` for the login itself) and `Flow`; `flow.did(...)` records screen steps.
- **New screen part** (button, column, filter): a method in its page object - never a selector in a test.
- **New page or dialog**: path in `framework/services/ui_service.py` (must be in Swagger, tag UI);
  `framework/pages/<name>_page.py` based on `BasePage`; export it in `framework/pages/__init__.py`.
- Find things the way a user does: label, role, visible text. Wait for the API call behind an action
  (`BasePage.waiting_for(path)`), never for a fixed time.

### 6.7 RUL accuracy (R-01)
R-01 is an ordinary Read & Verify case, run once per component: it reads the history of every vehicle with a
reference life, works out the error of every prediction, and passes when every quality gate passes.

```text
expected RUL   = reference life - component age
signed error   = predicted RUL - expected RUL                (+ over-prediction, - under-prediction)
allowed error  = max(absolute hours, expected RUL x fraction) - tighter for over-prediction
gates          = share of records within the allowed error >= minimum; MAE, RMSE, |mean over/under| <= maximum
```

- **For a component**: a `rul_accuracy` block in `config/components/<name>.yaml` (copy radiator's: age field,
  cycle, `threshold_source`, thresholds) and `testdata/reference_life/<name>.csv`. No code. Without either,
  R-01 reports BLOCKED and says which is missing. (Turbocharger's assumed values when it is onboarded: the same
  limits as radiator; a reference life for TC-025 is already in `testdata/reference_life/turbocharger.csv`.)
- **Result**: PASS when every gate passes. A missed gate is **FAIL only against agreed limits and reference
  lives**; against QA-assumed ones it is **BLOCKED**, with the missed numbers in the message - so a red result
  always means a model defect, and every run reminds the team that the limits still need agreeing.
  History that cannot be read is FAIL either way.
- **Limits agreed**: change the numbers and set `threshold_source: AGREED` - the report then stops calling
  them QA-assumed, and a missed gate becomes FAIL. **Reference lives known**: put the real ones in the file, with `source` saying where they
  came from (anything but `ASSUMED`).
- **Report look**: charts, cards and wording in `config/rul_accuracy_report.yaml`; a new chart type is one
  branch in `framework/rul_accuracy/report.py`.
- **Calculation changes**: `framework/rul_accuracy/evaluator.py`, with a hand-worked unit test in
  `tests/unit/test_rul_accuracy_calculation.py`.
- **A component's later life** (part replaced): a new cycle row in the reference-life file; per-cycle results
  are already in the summary.
- Only vehicles with a reference life are fetched, so the run stays short as the fleet grows; the report
  still shows the fleet size and coverage.

### 6.8 APIs and contracts
- **New endpoint, existing area**: re-pin if new; one line in the service's `ENDPOINTS` + one method.
- **New area (Swagger tag)**: `framework/services/<area>_service.py` (`TAG`, `ENDPOINTS`, methods) + one line in
  `SERVICE_CLASSES`. Fixed-shape body: pydantic model in `FIXED_SHAPE` (`request_builder.py`).
- **New API** (another service or host): add it under `apis` and to every environment in settings, set `API` in its
  service classes, and its login in `framework/auth.py` if it has one.
- **The API changed**: `test_contracts.py` fails, listing what was added or removed (the version number is not
  trusted - four endpoints were added while it stayed 2.0.0). Download `/openapi.json` as
  `spec/fleet_rul_openapi_<date>.json`, point `apis` at it, run; the run flags anything that no longer exists.
- **Training/testing APIs arrive**: re-pin, add the endpoints to a service, `record_sources` -> `type: api`.

### 6.9 Test data wording and reporting
- **New Expected Result wording**: add it to `expected_kind()` and `check()` in `result_checker.py`, and to the
  table in section 4. Until then the run stops at start-up naming the wording - nothing runs half-checked.
- **New Value word**: `value_resolver.py`, and the table in section 4.
- **New report label or attachment**: `framework/reporting.py` only; a new area prefix: `AREAS` in `tests/conftest.py`.

### 6.10 Smaller changes

| Change | Edit |
|---|---|
| Cut-off agreed or changed | `config/components/<name>.yaml` |
| Exclude a component from a case | **Test Cases** -> Excluded Components |
| Another row for an existing case | **Test Data** (every component) or **Test Data - Components** (one) |
| Compare one more field in TC-01 | **Test Data** -> TC-01 Expected Result list |
| New environment | `config/settings.yaml` -> `environments` (one address per API), then `--env <name>` |
| A slot field, severity word, tolerance or UI value agreed | `config/flows.yaml` |
| The workflow renames a node | `config/flows.yaml` -> `nodes` |
| Fewer or more vehicles in per-vehicle cases | `vehicle_sample_size`, or `--vehicle-sample N` |

---

## 7. Checked locally only

The live APIs are not reachable from where this was built. `stand_in/` has stand-ins for all three APIs and the
pages (`python -m stand_in.app`, then `pytest --env local_stand_in` with any values in the three credential
variables). They were used to check every case, including that each one fails on the defect it is meant to catch
(`STANDIN_BUG=...`, switches listed at the top of each stand-in file). The stand-in environment uses its own
reference lives (`stand_in/reference_life/`), because its vehicles differ from dev's.

Shapes assumed, not yet seen from the real API - adjust if they differ:
- `GET /api/registry`: the component name appears in the response
- `GET /api/{component}/vehicle/{unit_id}/history`: a list of records like the fleet records
- Predict with a missing mandatory field: 422 whose body names the field
- `POST /api/schedule/slots`: `{"available_slots": [{slot_id, dealer_id, dealer_name, date, time, ...}]}`
- `POST /api/schedule/book`: 201 with the booking, ID in `booking_id`; `GET /api/schedule/bookings`: `{"bookings": [...]}`
- `POST /login`: sets a session cookie (seen); the scheduling endpoints need it
- MCP `tools/list`: the pinned list is assumed from the one tool call seen
- Aggregation (no response schemas in Swagger): dashboard and top return vehicle profiles with `vehicle_id` (= VIN),
  `risk_level`, `priority`, `downtime_risk_score`; a profile has `min_rul_days`; components return
  `{component, health_score, rul_days, risk_level, ...}`; summary has `total_vehicles`, `priority_counts`,
  `risk_distribution`; `/api/ready` returns `{"ready": true}`
- UI: selectors in `framework/pages/` were written from screenshots - expect one adjustment pass on the real page.
  Assumed: the dialog is named "Schedule Service", slots are radio options in the API's order, the Risk Level
  options' values are the API values
