"""Workflow run: start an n8n workflow through its webhook and read back what it did.

The webhook answers at once (n8n responseMode onReceived) and returns no execution ID, so the run
is found afterwards in the executions API by the unique correlation_id this code puts in the request.
Node data is read from runData (complete), not customData (cut off at 512 characters).
"""
from __future__ import annotations

import copy
import json
import time
import uuid
from datetime import datetime, timezone

UNFINISHED = ("new", "running", "waiting")


class WorkflowRun:
    """One finished execution, with plain accessors for what the tests check."""

    def __init__(self, execution: dict, sent: dict):
        self.execution = execution
        self.sent = sent
        self.run_data: dict = execution.get("data", {}).get("resultData", {}).get("runData", {})

    @property
    def status(self) -> str:
        return self.execution.get("status")

    @property
    def finished(self) -> bool:
        return bool(self.execution.get("finished"))

    @property
    def error(self):
        return self.execution.get("data", {}).get("resultData", {}).get("error")

    def node_names(self) -> list[str]:
        return list(self.run_data)

    def node_inputs(self, node: str) -> list[dict]:
        """What a tool node was called with, one entry per call (n8n keeps it in inputOverride)."""
        return [item.get("json", {})
                for run in self.run_data.get(node, [])
                for branch in _first_list(run.get("inputOverride", {}))
                for item in branch]

    def node_outputs(self, node: str) -> list[dict]:
        """What a node produced, one entry per item, across all its runs."""
        return [item.get("json", {})
                for run in self.run_data.get(node, [])
                for branch in _first_list(run.get("data", {}))
                for item in branch]


def _first_list(by_kind: dict) -> list:
    """n8n groups data by connection kind (main, ai_tool, ...); a node has one kind."""
    for value in by_kind.values():
        return value or []
    return []


def parse_json_text(value):
    """Agent outputs arrive as JSON text, sometimes inside ``` fences."""
    if isinstance(value, dict):
        return value
    text = str(value or "").strip()
    if text.startswith("```"):
        text = text.strip("`")
        text = text[text.find("{"):]
    return json.loads(text)


def start_and_wait(n8n, workflow_id: str, request: dict, wait_seconds: float, poll_seconds: float = 3.0):
    """Send the request with a fresh correlation_id; return (WorkflowRun or None, what happened)."""
    body = copy.deepcopy(request)
    stamp = datetime.now(timezone.utc)
    body["correlation_id"] = body["id"] = f"qa_{stamp:%Y%m%dT%H%M%S}_{uuid.uuid4().hex[:8]}"
    body["ts"] = stamp.isoformat().replace("+00:00", "Z")
    sent = n8n.trigger_nudge(body)
    if sent.status != 200:
        return None, f"webhook returned {sent}"
    deadline = time.monotonic() + wait_seconds
    last = "no execution with this correlation_id yet"
    while time.monotonic() < deadline:
        time.sleep(poll_seconds)
        resp = n8n.recent_executions(workflow_id)
        if resp.status != 200:
            return None, f"executions API returned {resp}"
        for ex in (resp.body or {}).get("data", []):
            run = WorkflowRun(ex, body)
            hook = run.node_outputs("Webhook")
            if hook and hook[0].get("body", {}).get("correlation_id") == body["correlation_id"]:
                if run.status not in UNFINISHED:
                    return run, f"execution {ex.get('id')}"
                last = f"execution {ex.get('id')} still {run.status}"
    return None, f"not finished within {wait_seconds} s ({last}), correlation_id {body['correlation_id']}"
