"""The three flows every test follows - written once, used by every test.

Send & Verify : resolve value -> build request -> send -> check   (one data row)
Read & Verify : the test fetches records and applies its rule; fail() reports all problems at once
Flow & Verify : several calls in order, each using what the previous one returned (Flow below).
                A failed step stops the flow; checks after a step are collected and reported together;
                anything the flow created is removed afterwards, pass or fail.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

import pytest

from framework import reporting
from framework.api_client import ApiResponse
from framework.case_reader import DataRow, TestCase
from framework.request_builder import RequestBuilder
from framework.result_checker import check
from framework.services import Services
from framework.settings import ComponentProfile, Settings
from framework.value_resolver import resolve


@dataclass(frozen=True)
class CaseRun:
    """One concrete run: a test case, for one component (None = not per component), with one data row (Send & Verify only)."""
    case: TestCase
    component: ComponentProfile | None = None
    row: DataRow | None = None
    skip: str | None = None          # BLOCKED / NOT APPLICABLE reason: reported, not run

    @property
    def api(self) -> str:
        """The case's API path from the Test Cases sheet (Send & Verify cases call one API)."""
        return self.case.apis[0]

    @property
    def title(self) -> str:
        """Report title: TC-ID, test case title, component, row."""
        return " | ".join([f"{self.case.tc_id} {self.case.title}"] + ([self.component.name] if self.component else [])
                          + ([self.row.row] if self.row else []))

    def __str__(self):
        return (f"{self.case.tc_id}" + (f" | {self.component.name}" if self.component else "")
                + (f" | {self.row.row}" if self.row else ""))


def send_and_verify(run: CaseRun, services: Services, builder: RequestBuilder, settings: Settings,
                    baseline: ApiResponse | None = None) -> ApiResponse:
    row, comp = run.row, run.component
    value = resolve(row.value, comp, settings.just_below_step) if row.action == "Set" else None
    path_values = {"component": comp.name} if comp else {}
    if run.case.method == "GET":       # GET: the row sets a query parameter
        if isinstance(value, float) and value.is_integer():
            value = int(value)
        params = {} if row.action == "Remove" else {row.field: value}
        resp = services.call("GET", run.api, params=params, **path_values)
    else:
        body = builder.build(run.api, comp.name if comp else "", row, value)
        resp = services.call(run.case.method, run.api, body=body, **path_values)
    fail(run, check(resp, row, baseline))
    return resp


def fail(run: CaseRun, problems: list[str]) -> None:
    if problems:
        pytest.fail(f"{run}:\n  - " + "\n  - ".join(problems), pytrace=False)


class Flow:
    """Flow & Verify: one test case run as numbered steps.

        flow.step("Get slots", resp, 200)   -> the body, or stops the flow if the status is wrong
        flow.check(ok, "what is wrong")     -> collects a problem, the flow goes on
        flow.require(ok, "what is wrong")   -> the flow cannot go on without it: stops now
        flow.did("Click Schedule")          -> records a UI step (no HTTP status)
        flow.blocked("no slots offered")    -> stops as BLOCKED (cannot be tested now; not a defect)
        flow.undo("Cancel booking", fn)     -> fn runs after the test, pass or fail
        flow.done()                         -> fails with every collected problem, and the steps taken
    """

    def __init__(self, run: CaseRun, request):
        self.run = run
        self.steps: list[str] = []
        self.problems: list[str] = []
        self._undo: list[tuple[str, Callable[[], ApiResponse], int]] = []
        request.addfinalizer(self._clean_up)

    def step(self, title: str, resp: ApiResponse, expected_status: int):
        self.steps.append(f"{len(self.steps) + 1}. {title}: HTTP {resp.status}")
        with reporting.step(self.steps[-1]):
            pass
        if resp.status != expected_status:
            self._stop(f"step {len(self.steps)} '{title}': HTTP {resp.status}, expected {expected_status}"
                       f" - {resp.text[:200]}")
        return resp.body

    def check(self, ok: bool, problem: str) -> bool:
        if not ok:
            self.problems.append(problem)
        return ok

    def require(self, ok: bool, problem: str) -> None:
        """Like check, but the flow cannot go on without it."""
        if not ok:
            self._stop(*self.problems, problem)

    def did(self, title: str) -> None:
        """Record a step that has no HTTP status (a UI action), so failures show how far the flow got."""
        self.steps.append(f"{len(self.steps) + 1}. {title}")
        with reporting.step(self.steps[-1]):
            pass

    def blocked(self, reason: str) -> None:
        pytest.skip(f"BLOCKED: {reason}")

    def undo(self, title: str, action: Callable[[], ApiResponse], expected_status: int = 200) -> None:
        self._undo.append((title, action, expected_status))

    def undo_now(self, title: str) -> ApiResponse:
        """Run a registered undo as a step of the flow itself (e.g. H-03 cancels on purpose)."""
        i = next(i for i, u in enumerate(self._undo) if u[0] == title)
        _, action, expected = self._undo.pop(i)
        resp = action()
        self.step(title, resp, expected)
        return resp

    def done(self) -> None:
        if self.problems:
            self._stop(*self.problems)

    def _stop(self, *problems: str) -> None:
        pytest.fail(f"{self.run}:\n  - " + "\n  - ".join(problems)
                    + "\n  steps: " + " | ".join(self.steps), pytrace=False)

    def _clean_up(self) -> None:
        left = []
        for title, action, expected in reversed(self._undo):
            resp = action()
            if resp.status != expected:
                left.append(f"{title}: HTTP {resp.status} - {resp.text[:150]}")
        if left:
            raise RuntimeError("Clean-up failed - remove by hand: " + "; ".join(left))
