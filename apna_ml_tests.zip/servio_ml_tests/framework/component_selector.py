"""Component selector: which components a test case runs for.

    runs for = (Applicable - Excluded)  AND  in the run's scope
Applicable: "All" or a comma list.  Excluded: "None", "All" or a comma list.
Exclusion always wins. An empty result means the case is NOT APPLICABLE.

Applicable "n/a": the case is not about a component (e.g. a workflow case). It runs once - result [None] -
unless the run is narrowed to some components (--system/--subsystem/--component), then it does not run.
"""
from __future__ import annotations

from framework.case_reader import TestCase, TestDataError


def _names(cell: str, known: list[str], where: str) -> set[str]:
    text = (cell or "").strip()
    if text.lower() == "all":
        return set(known)
    if text.lower() in ("none", "-", ""):
        return set()
    names = {n.strip() for n in text.split(",") if n.strip()}
    unknown = sorted(names - set(known))
    if unknown:
        raise TestDataError(f"{where}: unknown component(s) {unknown}. Known: {sorted(known)}")
    return names


def select(case: TestCase, known: list[str], in_scope: list[str], narrowed: bool = False) -> list[str | None]:
    """narrowed: the run was limited with --system/--subsystem/--component."""
    if not case.per_component:
        if (case.excluded or "None").strip().lower() not in ("none", "-", ""):
            raise TestDataError(f"{case.tc_id}: Excluded Components must be None when Applicable is n/a")
        return [] if narrowed else [None]
    applicable = _names(case.applicable, known, f"{case.tc_id} Applicable Components")
    excluded = _names(case.excluded, known, f"{case.tc_id} Excluded Components")
    return [c for c in in_scope if c in applicable and c not in excluded]
