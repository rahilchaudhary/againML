"""Page objects: one class per page or dialog of the UI - the UI counterpart of the service objects.

The only place a selector is written. Tests call e.g. dashboard.filter_risk_level("CRITICAL").
Things are found by visible labels, roles and text, as a user would find them, so cosmetic changes
do not break the tests. Selectors marked ASSUMED were written from screenshots, not the real page.
"""
from framework.pages.dashboard_page import FleetDashboardPage
from framework.pages.login_page import LoginPage
from framework.pages.schedule_wizard import ScheduleWizard

__all__ = ["LoginPage", "FleetDashboardPage", "ScheduleWizard"]
