"""Base for page objects: the browser page, the site address, and waiting for the API behind an action."""
from __future__ import annotations

from contextlib import contextmanager

TIMEOUT_MS = 15_000


class BasePage:
    def __init__(self, page, base_url: str):
        self.page = page
        self.base_url = base_url
        page.set_default_timeout(TIMEOUT_MS)

    @contextmanager
    def waiting_for(self, api_path: str):
        """Do a UI action and wait until the page has received the API call it triggers (path as Swagger writes it,
        query string ignored), so checks never read a half-loaded screen."""
        with self.page.expect_response(lambda r: r.url.split("?")[0].endswith(api_path)) as info:
            yield info
