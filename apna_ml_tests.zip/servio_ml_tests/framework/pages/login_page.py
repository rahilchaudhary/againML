"""Login page (GET /login): the email/password form posted to POST /login."""
from __future__ import annotations

from framework.pages.base_page import BasePage
from framework.services.ui_service import UiService


class LoginPage(BasePage):
    def open(self) -> "LoginPage":
        self.page.goto(self.base_url + UiService.path("login_page"))
        return self

    def log_in(self, email: str, password: str) -> None:
        # Field names are those of the login form in Swagger (Body_login_submit_login_post).
        self.page.locator("input[name=email]").fill(email)
        self.page.locator("input[name=password]").fill(password)
        self.page.locator("button[type=submit]").click()                 # ASSUMED: one submit button
        self.page.wait_for_url(f"**{UiService.path('dashboard_page')}**")
