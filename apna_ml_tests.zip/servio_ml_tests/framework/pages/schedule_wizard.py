"""Schedule Service wizard (dialog opened by a row's Schedule button): Component -> Details -> Confirm."""
from __future__ import annotations

import re

from framework.pages.base_page import BasePage
from framework.services.scheduling_service import SchedulingService

SLOTS_API = SchedulingService.ENDPOINTS["slots"][1]
BOOK_API = SchedulingService.ENDPOINTS["book"][1]


class ScheduleWizard(BasePage):
    @property
    def dialog(self):
        return self.page.get_by_role("dialog", name="Schedule Service")      # ASSUMED: dialog named by its title

    # step 1 - Component
    def choose_component(self, component: str, service_type: str = "Inspection") -> None:
        self.dialog.get_by_label("Component to Service").select_option(label=component)
        self.dialog.get_by_label("Service Type").select_option(label=service_type)

    def next_to_details(self) -> None:
        with self.waiting_for(SLOTS_API):
            self.dialog.get_by_role("button", name="Next").click()

    # step 2 - Details: the slots offered
    def slot_options(self) -> list[str]:
        """Text of each slot offered, in screen order. ASSUMED: slots are radio options."""
        radios = self.dialog.get_by_role("radio")
        return [radios.nth(i).locator("xpath=..").inner_text().strip() for i in range(radios.count())]

    def choose_slot(self, index: int) -> None:
        self.dialog.get_by_role("radio").nth(index).check()

    def next_to_confirm(self) -> None:
        self.dialog.get_by_role("button", name="Next").click()

    # step 3 - Confirm
    def confirm(self) -> None:
        with self.waiting_for(BOOK_API):
            self.dialog.get_by_role("button", name=re.compile(r"^Confirm")).click()
