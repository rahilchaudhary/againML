"""Fleet Dashboard (GET /v2): header counts, filters, the vehicle table and its Schedule buttons."""
from __future__ import annotations

import re

from framework.pages.base_page import BasePage
from framework.services.aggregation_service import AggregationService
from framework.services.ui_service import UiService

DASHBOARD_API = AggregationService.ENDPOINTS["dashboard"][1]
# Column headers as shown on screen (from the screenshot).
VEHICLE_ID, PRIORITY, DOWNTIME_RISK, MIN_RUL = "Vehicle ID", "Priority", "Downtime Risk", "Min RUL (days)"


class FleetDashboardPage(BasePage):
    def open(self) -> "FleetDashboardPage":
        with self.waiting_for(DASHBOARD_API):
            self.page.goto(self.base_url + UiService.path("dashboard_page"))
        self.page.locator("tbody tr").first.wait_for()
        return self

    # ---- header ----
    def header_count(self, what: str) -> int | None:
        """'150 Vehicles' -> 150 for what='Vehicles'."""
        text = self.page.get_by_text(re.compile(rf"^\s*\d+\s+{what}\s*$")).first.inner_text()
        return int(re.search(r"\d+", text).group())

    def shows_role(self, role: str) -> bool:
        return self.page.get_by_text(role, exact=True).first.is_visible()

    # ---- filters ----
    def filter_risk_level(self, level: str) -> None:
        with self.waiting_for(DASHBOARD_API):
            self.page.get_by_label("Risk Level").select_option(value=level)    # ASSUMED: option values are the API values

    # ---- table ----
    def rows(self, limit: int | None = None) -> list[dict[str, str]]:
        """The table as {column header: cell text}, in screen order."""
        headers = [h.strip() for h in self.page.locator("thead th").all_inner_texts()]
        out = []
        for row in self.page.locator("tbody tr").all()[:limit]:
            cells = [c.strip() for c in row.locator("td").all_inner_texts()]
            out.append(dict(zip(headers, cells)))
        return out

    def _row(self, vehicle_id: str):
        return self.page.locator("tbody tr").filter(has_text=vehicle_id)

    def has_row(self, vehicle_id: str) -> bool:
        return self._row(vehicle_id).count() > 0

    def schedule_state(self, vehicle_id: str) -> str:
        """The Schedule column's button text: 'Schedule' or 'Booked'."""
        return self._row(vehicle_id).get_by_role("button").last.inner_text().strip()

    def open_schedule(self, vehicle_id: str):
        from framework.pages.schedule_wizard import ScheduleWizard
        self._row(vehicle_id).get_by_role("button", name="Schedule").click()
        return ScheduleWizard(self.page, self.base_url)

    def wait_until_booked(self, vehicle_id: str) -> None:
        self._row(vehicle_id).get_by_role("button", name="Booked").wait_for()
