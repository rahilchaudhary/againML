"""Reporting: everything the framework adds to the Allure report, in one place.

Without allure-pytest installed, or without --alluredir, every function here does nothing,
so the suite runs the same either way.

What goes into the report:
  - each test case's labels from the workbook (area, TC-ID, title, category, suite, component, row)
  - every HTTP call: method, URL, request body and response (secrets masked, long bodies cut)
  - each Flow & Verify step as a step
  - UI screenshots on failure; files a test writes (e.g. the RUL accuracy report)
"""
from __future__ import annotations

import json
import re
from contextlib import nullcontext

try:
    import allure
except ImportError:                    # Allure not installed: reporting is off
    allure = None

SECRET = re.compile(r"pass(word)?|token|secret|api[-_]?key|cookie|authorization", re.IGNORECASE)
MAX_CHARS = 20_000
SEVERITY = {"Smoke": "critical", "Sanity": "normal", "Regression": "minor"}


def mask(value):
    """Copy of a body with every secret-looking field replaced by ***."""
    if isinstance(value, dict):
        return {k: "***" if SECRET.search(str(k)) else mask(v) for k, v in value.items()}
    if isinstance(value, list):
        return [mask(v) for v in value]
    return value


def _text(value) -> str:
    text = value if isinstance(value, str) else json.dumps(value, indent=2, ensure_ascii=False, default=str)
    return text if len(text) <= MAX_CHARS else text[:MAX_CHARS] + f"\n... ({len(text) - MAX_CHARS} more characters)"


def attach_http(method: str, url: str, params, body, form, status: int, response_text: str) -> None:
    if allure is None:
        return
    sent = {"params": params, "json": mask(body), "form": mask(form)}
    request = {k: v for k, v in sent.items() if v}
    try:
        response = mask(json.loads(response_text))
    except ValueError:
        response = response_text
    allure.attach(_text({"request": f"{method} {url}", **request, "status": status, "response": response}),
                  name=f"{method} {url.split('?')[0]} -> {status}", attachment_type=allure.attachment_type.JSON)


def step(title: str):
    """A report step (use as a context manager)."""
    return allure.step(title) if allure else nullcontext()


def attach_file(name: str, path, kind: str) -> None:
    """Attach a file the test wrote: kind is html, json or csv."""
    if allure is not None:
        types = {"html": allure.attachment_type.HTML, "json": allure.attachment_type.JSON,
                 "csv": allure.attachment_type.CSV}
        allure.attach.file(str(path), name=name, attachment_type=types[kind])


def attach_png(name: str, data: bytes) -> None:
    if allure is not None:
        allure.attach(data, name=name, attachment_type=allure.attachment_type.PNG)


def title_from_run(test_function) -> None:
    """Report title of every run of a case test: its CaseRun.title (TC-ID, title, component, row)."""
    test_function.__allure_display_name__ = "{run.title}"


def label_case(area: str, case, component: str | None, row, run_name: str) -> None:
    """Labels from the workbook, so the report groups and filters like the Test Cases sheet."""
    if allure is None:
        return
    d = allure.dynamic
    d.parent_suite(area)
    d.suite(case.category)
    d.sub_suite(f"{case.tc_id} {case.title}")
    d.epic(area)
    d.feature(f"{case.tc_id} {case.title}")
    if component:
        d.story(component)
    d.tag(case.suite)
    d.severity(SEVERITY.get(case.suite, "normal"))
    d.label("tc_id", case.tc_id)
    d.parameter("run", run_name)                 # readable, instead of the run object


def describe(case, row) -> None:
    """The test case's description from the workbook. Called when the test body starts, because allure-pytest
    replaces the description (with the function's docstring) at the end of setup."""
    if allure is None:
        return
    lines = [f"**Expected Result (Test Cases sheet):** {case.expected_result}",
             f"**Prerequisites:** {case.prerequisites}",
             f"**API:** " + ", ".join(f"{m} {p}" for m, p in case.calls)]
    if row:
        lines.append(f"**Test Data row {row.row}:** {row.field} - {row.action} {row.value} -> "
                     f"{row.expected_status}, {row.expected_result}")
    allure.dynamic.description("\n\n".join(lines))


def label_framework_check(name: str) -> None:
    if allure is not None:
        allure.dynamic.parent_suite("Framework checks")
        allure.dynamic.suite(name)
