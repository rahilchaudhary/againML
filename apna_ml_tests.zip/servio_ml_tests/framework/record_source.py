"""Record source: gives Read & Verify tests records that may not have an API yet.

config/settings.yaml (record_sources) says, per source, whether records come from
a file or from the API. Switching from file to API changes no test.
"""
from __future__ import annotations

import json

from framework.settings import ROOT


def extract_records(body) -> list[dict]:
    """Accept a plain list of records, or an object holding one list of records."""
    if isinstance(body, list):
        return body
    if isinstance(body, dict):
        for value in body.values():
            if isinstance(value, list) and (not value or isinstance(value[0], dict)):
                return value
    raise ValueError(f"Response does not contain a list of records: {str(body)[:200]}")


class RecordSource:
    def __init__(self, services, source_config: dict[str, dict]):
        self.services = services
        self.config = source_config

    def records(self, name: str, component: str) -> list[dict]:
        if name not in self.config:
            raise KeyError(f"Record source '{name}' is not in config/settings.yaml")
        src = self.config[name]
        if src["type"] == "file":
            return extract_records(json.loads((ROOT / src["path"].format(component=component)).read_text()))
        if src["type"] == "api":
            resp = self.services.call("GET", src["endpoint"], component=component)   # via its service
            if resp.status != 200:
                raise RuntimeError(f"{src['endpoint']} for {component} returned {resp}")
            return extract_records(resp.body)
        raise ValueError(f"Record source '{name}': unknown type '{src['type']}'")

    def file_backed_endpoints(self) -> set[str]:
        """API paths named in the API column of the Test Cases sheet that are served from files for now (so not yet in Swagger)."""
        return {s["endpoint"] for s in self.config.values() if s["type"] == "file"}
