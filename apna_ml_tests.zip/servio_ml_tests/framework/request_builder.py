"""Request builder: a valid full request + one row's action = the request to send.

Which full request is used depends on the API path (API column of the Test Cases sheet):
- Fixed shape for every component -> a pydantic model (the POJO equivalent), registered in FIXED_SHAPE.
- Shape differs per component    -> a file: testdata/requests/<name>/<component>.json,
  where <name> is the first fixed word of the path after /api/ (e.g. /api/predict/{component} -> predict).
"""
from __future__ import annotations

import copy
import json
from pathlib import Path

from pydantic import BaseModel

from framework.case_reader import DataRow, TestDataError
from framework.settings import ROOT


class RecommendationRequest(BaseModel):
    """POST /api/recommendation/{component} - shape from the Swagger schema RulRecommendationRequest."""
    rul_lower_hours: float = 1000.0
    vin: str | None = None


class BookRequest(BaseModel):
    """POST /api/schedule/book - shape from the Swagger schema BookRequest (vin and slot_id required).
    Values are a plausible booking; the Flow & Verify cases book a real offered slot instead."""
    vin: str = "MAT492531P2B10039"
    slot_id: str = "SLT-QA-PLACEHOLDER"
    dealer_id: str = "D01"
    dealer_name: str = "QA Dealer"
    date: str = "2099-01-01"
    time: str = "09:00"
    component: str = ""
    service_type: str = "Inspection"
    notes: str = "servio-api-tests"


FIXED_SHAPE: dict[str, type[BaseModel]] = {
    "/api/recommendation/{component}": RecommendationRequest,
    "/api/schedule/book": BookRequest,
}


def _folder_for(path: str) -> str:
    words = [w for w in path.strip("/").split("/") if w and w != "api" and not w.startswith("{")]
    if not words:
        raise TestDataError(f"Cannot work out a request folder for path {path}")
    return words[0]


class RequestBuilder:
    def __init__(self, requests_dir: Path = ROOT / "testdata" / "requests"):
        self.requests_dir = requests_dir
        self._cache: dict[tuple[str, str], dict] = {}

    def full_request(self, path: str, component: str) -> dict:
        if path in FIXED_SHAPE:
            model = FIXED_SHAPE[path]
            values = {"component": component} if component and "component" in model.model_fields else {}
            return model(**values).model_dump(exclude_none=True)
        key = (path, component)
        if key not in self._cache:
            file = self.requests_dir / _folder_for(path) / f"{component}.json"
            if not file.exists():
                raise TestDataError(f"No full request for {path} and '{component}': {file} is missing")
            self._cache[key] = json.loads(file.read_text())
        return copy.deepcopy(self._cache[key])

    def build(self, path: str, component: str, row: DataRow, value=None) -> dict:
        """Apply the row's action. 'value' is the already-resolved number for Set."""
        body = self.full_request(path, component)
        if row.action == "Remove":
            if row.field not in body:
                raise TestDataError(f"{row.tc_id} {row.row}: cannot remove '{row.field}' - "
                                    f"it is not in the full request for {path} ({component})")
            del body[row.field]
        elif row.action == "Set":
            body[row.field] = value
        return body
