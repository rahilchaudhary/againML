"""API client: the only place that makes HTTP calls. One client per API under test.

Callers pass the path as the API writes it (e.g. /api/predict/{component}).
If the API has a pinned Swagger, every call is checked against it first, so a path that
is not in the API fails with a clear message instead of a confusing 404.

Login: if the API needs one, the client logs in once, on its first call, and keeps the
session cookie for every later call. A failed login is reported once and repeated on every
later call of that run, instead of a stream of confusing 401s.

Every call is attached to the Allure report (framework/reporting.py), with secrets masked.
"""
from __future__ import annotations

import json
from typing import Callable

import requests

from framework import reporting
from framework.swagger import Swagger


class ApiResponse:
    def __init__(self, raw: requests.Response):
        self.status = raw.status_code
        self.url = raw.url
        self.text = raw.text
        self.headers = raw.headers
        self.is_error = False                 # set by services whose errors travel inside a 200 (MCP)
        try:
            self.body = raw.json()
        except ValueError:
            self.body = None

    def __repr__(self):
        return f"HTTP {self.status} {self.text[:300]}"


class ApiClient:
    def __init__(self, base_url: str, swagger: Swagger | None = None,
                 login: Callable[["ApiClient"], None] | None = None, timeout: float = 30.0):
        self.base_url = base_url
        self.swagger = swagger
        self.timeout = timeout
        self.http = requests.Session()
        self._login = login
        self._login_done = login is None
        self._login_error: BaseException | None = None

    def request(self, method: str, path: str, body: dict | None = None, params: dict | None = None,
                form: dict | None = None, headers: dict | None = None, **path_values) -> ApiResponse:
        self._ensure_login()
        if self.swagger:
            self.swagger.check(method, path)
        url = self.base_url + path.format(**path_values)
        headers = dict(headers or {})
        data = None
        if body is not None:
            data = json.dumps(body)
            headers.setdefault("Content-Type", "application/json")
        elif form is not None:
            data = form                       # sent as application/x-www-form-urlencoded
        raw = self.http.request(method.upper(), url, data=data, params=params, headers=headers or None,
                                timeout=self.timeout, allow_redirects=False)
        reporting.attach_http(method.upper(), raw.url, params, body, form, raw.status_code, raw.text)
        return ApiResponse(raw)

    def get(self, path: str, params: dict | None = None, **path_values) -> ApiResponse:
        return self.request("GET", path, params=params, **path_values)

    def post(self, path: str, body: dict, **path_values) -> ApiResponse:
        return self.request("POST", path, body=body, **path_values)

    def get_unchecked(self, path: str) -> ApiResponse:
        """For the few calls that are about the API itself (e.g. /openapi.json), so not in its Swagger."""
        return ApiResponse(self.http.get(self.base_url + path, timeout=self.timeout))

    def _ensure_login(self) -> None:
        if self._login_error:
            raise self._login_error
        if self._login_done:
            return
        self._login_done = True               # set first: the login call itself goes through request()
        try:
            self._login(self)
        except BaseException as e:            # includes pytest.fail(), so the reason is kept
            self._login_error = e
            raise
