"""Swagger: the pinned copy of the API's own description (GET /openapi.json).

Its only job: say whether a method + path exists in the API. Paths are never typed into config.
"""
from __future__ import annotations

import json
from pathlib import Path


class UnknownEndpoint(ValueError):
    """A method + path that the pinned Swagger does not contain."""


class Swagger:
    def __init__(self, path: Path):
        doc = json.loads(path.read_text())
        self.file = path.name
        self.version = doc["info"]["version"]
        self.operations = {(method.upper(), p) for p, methods in doc["paths"].items() for method in methods}

    def check(self, method: str, path: str, where: str = "") -> None:
        if (method.upper(), path) not in self.operations:
            prefix = f"{where}: " if where else ""
            raise UnknownEndpoint(f"{prefix}{method.upper()} {path} is not in Swagger "
                                  f"{self.file} (v{self.version})")
