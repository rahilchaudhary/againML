"""Vehicle sample: which vehicles a per-vehicle case checks when the fleet is large.

A random sample keeps the run short and, across runs, covers different vehicles.
The seed is reported so a failing sample can be repeated exactly (--vehicle-seed).
"""
from __future__ import annotations

import random


class VehicleSample:
    def __init__(self, size: int | None, seed: int | None = None):
        self.size = size                                   # None = every vehicle
        self.seed = seed if seed is not None else random.randrange(1, 10**6)

    def pick(self, unit_ids: list[str]) -> list[str]:
        ids = sorted(unit_ids)
        if self.size is None or len(ids) <= self.size:
            return ids
        return sorted(random.Random(self.seed).sample(ids, self.size))

    def describe(self, picked: int, total: int) -> str:
        if picked == total:
            return f"all {total} vehicles"
        return f"{picked} of {total} vehicles (seed {self.seed}; repeat with --vehicle-seed {self.seed})"
