"""Connections: builds the clients and service objects for a run, from config/settings.yaml.

Used by the pytest suite (tests/conftest.py), and usable by any script outside pytest,
so every track reaches the APIs the same way: same addresses, same pinned contracts, same login.
"""
from __future__ import annotations

import pytest

from framework.api_client import ApiClient
from framework.auth import LOGINS
from framework.services import Services
from framework.settings import Settings
from framework.swagger import Swagger


def pinned_swaggers(settings: Settings) -> dict[str, Swagger]:
    return {name: Swagger(api.swagger_file) for name, api in settings.apis.items() if api.swagger_file}


def client_factory(settings: Settings, swaggers: dict[str, Swagger] | None = None):
    """API name -> its client. Made on first use; logs in on its first call if the API needs a login."""
    swaggers = pinned_swaggers(settings) if swaggers is None else swaggers
    made: dict[str, ApiClient] = {}

    def get(name: str) -> ApiClient:
        if name not in made:
            api = settings.apis[name]
            if api.address_missing:
                pytest.fail(f"Prerequisite failed: no address for API '{name}' in environment "
                            f"'{settings.env}' (config/settings.yaml)", pytrace=False)
            made[name] = ApiClient(api.base_url, swaggers.get(name), login=LOGINS.get(api.auth))
        return made[name]
    return get


def build_services(settings: Settings) -> Services:
    return Services(client_factory(settings))
