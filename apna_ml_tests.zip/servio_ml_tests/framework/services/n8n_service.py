"""n8n: the Proactive Health Nudge workflow - its webhook (starts a run) and the executions API (reads the run).

The webhook needs no key, and none is sent: n8n stores the webhook's request headers in the execution.
The executions API needs the n8n API key (framework/auth.py).
"""
from framework.api_client import ApiResponse
from framework.auth import n8n_api_key_header
from framework.services.base import BaseService


class N8nService(BaseService):
    API = "n8n"
    TAG = "n8n workflows"
    ENDPOINTS = {
        "nudge_webhook": ("POST", "/webhook/nudge-kpit-demo"),
        "executions":    ("GET",  "/api/v1/executions"),
    }

    def trigger_nudge(self, body: dict) -> ApiResponse:
        return self.call("nudge_webhook", body=body)

    def recent_executions(self, workflow_id: str, limit: int = 5) -> ApiResponse:
        return self.call("executions", headers=n8n_api_key_header(),
                         params={"workflowId": workflow_id, "limit": limit, "includeData": "true"})
