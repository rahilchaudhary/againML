"""Swagger tag: Auth. Used by framework/auth.py to log in once per run."""
from framework.api_client import ApiResponse
from framework.services.base import BaseService


class AuthService(BaseService):
    TAG = "Auth"
    ENDPOINTS = {
        "login": ("POST", "/login"),
    }

    def login(self, email: str, password: str) -> ApiResponse:
        return self.call("login", form={"email": email, "password": password})
