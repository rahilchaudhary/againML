"""Swagger tag: UI - the pages the UI cases open. Page objects (framework/pages/) take their paths from here,
so a page path, like an API path, is written in one place and checked against Swagger."""
from framework.services.base import BaseService


class UiService(BaseService):
    TAG = "UI"
    ENDPOINTS = {
        "login_page":     ("GET", "/login"),
        "dashboard_page": ("GET", "/v2"),
    }

    @classmethod
    def path(cls, name: str) -> str:
        return cls.ENDPOINTS[name][1]
