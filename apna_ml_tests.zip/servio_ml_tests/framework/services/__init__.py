"""All service objects in one place.

A new API area = a new service file + one line in SERVICE_CLASSES. Tests never write paths.
"""
from __future__ import annotations

from framework.api_client import ApiClient, ApiResponse
from framework.services.aggregation_service import AggregationService
from framework.services.auth_service import AuthService
from framework.services.base import BaseService
from framework.services.fleet_service import FleetService
from framework.services.mcp_service import McpService
from framework.services.n8n_service import N8nService
from framework.services.prediction_service import PredictionService
from framework.services.recommendation_service import RecommendationService
from framework.services.scheduling_service import SchedulingService
from framework.services.system_service import SystemService
from framework.services.ui_service import UiService

SERVICE_CLASSES: dict[str, type[BaseService]] = {
    "prediction": PredictionService,
    "recommendation": RecommendationService,
    "fleet": FleetService,
    "system": SystemService,
    "aggregation": AggregationService,
    "auth": AuthService,
    "scheduling": SchedulingService,
    "n8n": N8nService,
    "mcp": McpService,
    "ui": UiService,
}


def known_endpoints() -> dict[tuple[str, str], tuple[str, str]]:
    """(method, path) -> (service key, endpoint name), for every endpoint any service covers."""
    return {(m, p): (key, name)
            for key, cls in SERVICE_CLASSES.items()
            for name, (m, p) in cls.ENDPOINTS.items()}


class Services:
    """One object per service. Each service talks to its own API's client, created only when first used,
    so a run that never touches an API never needs its address or login."""

    def __init__(self, client_for):
        self._client_for = client_for            # API name -> ApiClient
        self._made: dict[str, BaseService] = {}

    def __getattr__(self, key: str) -> BaseService:
        if key.startswith("_") or key not in SERVICE_CLASSES:
            raise AttributeError(key)
        if key not in self._made:
            cls = SERVICE_CLASSES[key]
            self._made[key] = cls(self._client_for(cls.API))
        return self._made[key]

    def call(self, method: str, path: str, body: dict | None = None, params: dict | None = None,
             **path_values) -> ApiResponse:
        """Used by the generic Send & Verify flow, where the path comes from the Test Cases sheet."""
        key, name = known_endpoints()[(method.upper(), path)]
        return getattr(self, key).call(name, body=body, params=params, **path_values)
