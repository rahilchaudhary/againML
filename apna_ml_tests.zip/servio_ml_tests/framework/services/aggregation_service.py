"""Swagger tag: Aggregation (cross-component vehicle profiles, fleet dashboard, summaries)."""
from framework.api_client import ApiResponse
from framework.services.base import BaseService


class AggregationService(BaseService):
    TAG = "Aggregation"
    ENDPOINTS = {
        "summary":            ("GET", "/api/aggregate/fleet/summary"),
        "dashboard":          ("GET", "/api/aggregate/fleet/dashboard"),
        "top":                ("GET", "/api/aggregate/fleet/top"),
        "vehicle":            ("GET", "/api/aggregate/vehicle/{vehicle_id}"),
        "vehicle_components": ("GET", "/api/aggregate/vehicle/{vehicle_id}/components"),
        "refresh":            ("GET", "/api/aggregate/fleet/refresh"),
    }

    def summary(self) -> ApiResponse:
        return self.call("summary")

    def dashboard(self, **filters) -> ApiResponse:
        """filters: site, model, risk_level, priority (query parameters)."""
        return self.call("dashboard", params=filters or None)

    def top(self, n: int) -> ApiResponse:
        return self.call("top", params={"n": n})

    def vehicle(self, vehicle_id: str) -> ApiResponse:
        return self.call("vehicle", vehicle_id=vehicle_id)

    def vehicle_components(self, vehicle_id: str) -> ApiResponse:
        return self.call("vehicle_components", vehicle_id=vehicle_id)

    def refresh(self) -> ApiResponse:
        return self.call("refresh")
