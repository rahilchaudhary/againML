"""Swagger tag: Service Scheduling (slots and bookings - the handover from the model to a service booking)."""
from framework.api_client import ApiResponse
from framework.services.base import BaseService


class SchedulingService(BaseService):
    TAG = "Service Scheduling"
    ENDPOINTS = {
        "slots":    ("POST",   "/api/schedule/slots"),
        "book":     ("POST",   "/api/schedule/book"),
        "bookings": ("GET",    "/api/schedule/bookings"),
        "cancel":   ("DELETE", "/api/schedule/booking/{booking_id}"),
    }

    def slots(self, vin: str, component: str) -> ApiResponse:
        return self.call("slots", body={"vin": vin, "component": component})

    def book(self, body: dict) -> ApiResponse:
        return self.call("book", body=body)

    def bookings(self) -> ApiResponse:
        return self.call("bookings")

    def cancel(self, booking_id: str) -> ApiResponse:
        return self.call("cancel", booking_id=booking_id)
