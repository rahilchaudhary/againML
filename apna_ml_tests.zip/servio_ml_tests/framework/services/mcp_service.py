"""MCP server: Diagnostics & TSB (mcp-diagnostics). JSON-RPC over HTTP at /mcp.

Each tool is like an endpoint: TOOLS lists the ones the tests call, and every one must be in the
pinned tool list (config/settings.yaml, apis: mcp_diagnostics: tools). The session is opened once
(initialize), then tools are called with tools/call. Replies may come as JSON or as server-sent events.
"""
from __future__ import annotations

import itertools
import json

from framework.api_client import ApiResponse
from framework.services.base import BaseService

PROTOCOL_VERSION = "2025-06-18"


class McpService(BaseService):
    API = "mcp_diagnostics"
    TAG = "MCP Diagnostics & TSB"
    ENDPOINTS = {
        "rpc": ("POST", "/mcp"),
    }
    TOOLS = ("get_dtc_details",)

    def __init__(self, client):
        super().__init__(client)
        self._ids = itertools.count(1)
        self._headers: dict[str, str] | None = None

    def get_dtc_details(self, dtc_code: str) -> ApiResponse:
        """Returns the reply with .body = the tool's structuredContent and .is_error = the MCP isError flag."""
        return self.call_tool("get_dtc_details", {"dtc_code": dtc_code})

    def list_tools(self) -> ApiResponse:
        resp = self._rpc("tools/list", {})
        resp.body = (resp.body or {}).get("result", {})
        return resp

    def call_tool(self, tool: str, arguments: dict) -> ApiResponse:
        resp = self._rpc("tools/call", {"name": tool, "arguments": arguments})
        envelope = resp.body or {}
        result = envelope.get("result") or {}
        resp.is_error = bool(result.get("isError")) or "error" in envelope
        resp.body = result.get("structuredContent")
        if resp.body is None and result.get("content"):          # older servers: JSON as text only
            try:
                resp.body = json.loads(result["content"][0].get("text", ""))
            except (ValueError, KeyError, IndexError):
                resp.body = None
        return resp

    # ---- protocol ----
    def _open(self) -> dict[str, str]:
        if self._headers is None:
            headers = {"Accept": "application/json, text/event-stream"}
            init = self._send({"jsonrpc": "2.0", "id": next(self._ids), "method": "initialize",
                               "params": {"protocolVersion": PROTOCOL_VERSION, "capabilities": {},
                                          "clientInfo": {"name": "servio-api-tests", "version": "1"}}}, headers)
            session = init.headers.get("mcp-session-id")
            if session:
                headers["mcp-session-id"] = session
            self._send({"jsonrpc": "2.0", "method": "notifications/initialized"}, headers)
            self._headers = headers
        return self._headers

    def _rpc(self, method: str, params: dict) -> ApiResponse:
        headers = self._open()
        return self._send({"jsonrpc": "2.0", "id": next(self._ids), "method": method, "params": params}, headers)

    def _send(self, message: dict, headers: dict) -> ApiResponse:
        resp = self.call("rpc", body=message, headers=headers)
        if resp.body is None and "data:" in resp.text:            # server-sent events: take the JSON message
            for line in resp.text.splitlines():
                if line.startswith("data:"):
                    try:
                        resp.body = json.loads(line[5:].strip())
                    except ValueError:
                        continue
        return resp
