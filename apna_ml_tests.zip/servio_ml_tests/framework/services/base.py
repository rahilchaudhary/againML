"""Base for service objects: one class per Swagger tag (or per workflow / MCP server),
the only place an API path is written.

API       : which API it belongs to (a name under apis: in config/settings.yaml)
ENDPOINTS : name -> (method, path as the API writes it)
Its methods call self.call(name, ...). HTTP itself stays in ApiClient.
"""
from __future__ import annotations

from framework.api_client import ApiClient, ApiResponse


class BaseService:
    API: str = "fleet_rul"                          # which API (config/settings.yaml apis:)
    TAG: str = ""                                   # the Swagger tag this service covers
    ENDPOINTS: dict[str, tuple[str, str]] = {}      # name -> (method, path)

    def __init__(self, client: ApiClient):
        self.client = client

    def call(self, name: str, body: dict | None = None, params: dict | None = None,
             **kwargs) -> ApiResponse:
        method, path = self.ENDPOINTS[name]
        return self.client.request(method, path, body=body, params=params, **kwargs)
