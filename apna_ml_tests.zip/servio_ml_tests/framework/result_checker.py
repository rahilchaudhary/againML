"""Result checker: compares a response with Expected Status and Expected Result.

Allowed Expected Result wording (anything else is a test data error):
    CRITICAL / WATCH / HEALTHY                     risk_level must equal it
    Same as full request: <field>, <field>, ...    these fields equal the full-request response
    Error names <field>; no <field2>               <field> appears in the error, and <field2> is not returned
    Every record: <field> = <value>                at least one record, and every record has that value
    <min> to <max> records                         the number of records returned is within the range
    Found                                          (DTC lookup) found is true, the code is echoed, detail fields filled
    Not found                                      (DTC lookup) found is false, detail fields empty, not an error
"""
from __future__ import annotations

import re

from framework.api_client import ApiResponse
from framework.case_reader import DataRow, TestDataError
from framework.record_source import extract_records
from framework.settings import CRITICAL, HEALTHY, WATCH

_ERROR_NAMES = re.compile(r"^Error names\s+(\S+?)\s*;\s*no\s+(\S+)$", re.IGNORECASE)
_SAME_AS_FULL = re.compile(r"^Same as full request\s*:\s*(.+)$", re.IGNORECASE)
_EVERY_RECORD = re.compile(r"^Every record\s*:\s*(\S+)\s*=\s*(.+)$", re.IGNORECASE)
_COUNT = re.compile(r"^(\d+)\s+to\s+(\d+)\s+records$", re.IGNORECASE)


def expected_kind(text: str) -> str:
    """Classify the wording once, so a typo is caught before any call is made."""
    t = (text or "").strip()
    if t in (CRITICAL, WATCH, HEALTHY):
        return "risk"
    if _SAME_AS_FULL.match(t):
        return "same_as_full"
    if _ERROR_NAMES.match(t):
        return "error_names"
    if _EVERY_RECORD.match(t):
        return "every_record"
    if _COUNT.match(t):
        return "count"
    if t.lower() in ("found", "not found"):
        return t.lower().replace(" ", "_")
    raise TestDataError(f"Expected Result '{t}' is not understood. Use CRITICAL/WATCH/HEALTHY, "
                        f"'Same as full request: <field>, <field>', 'Error names <field>; no <field>', "
                        f"'Every record: <field> = <value>', '<min> to <max> records', 'Found' or 'Not found'")


def compared_fields(text: str) -> list[str]:
    """Fields listed after 'Same as full request:'."""
    return [f.strip() for f in _SAME_AS_FULL.match(text.strip()).group(1).split(",") if f.strip()]


def check(resp: ApiResponse, row: DataRow, baseline: ApiResponse | None = None,
          detail_fields: tuple[str, ...] = ()) -> list[str]:
    """Return every mismatch (empty list = pass). detail_fields: the agreed fields for Found / Not found."""
    problems = []
    if resp.status != row.expected_status:
        problems.append(f"status {resp.status}, expected {row.expected_status} - {resp.text[:200]}")
    body = resp.body if isinstance(resp.body, dict) else {}
    kind = expected_kind(row.expected_result)
    if kind == "risk":
        actual = body.get("risk_level")
        if actual != row.expected_result:
            problems.append(f"risk_level {actual}, expected {row.expected_result}")
    elif kind == "error_names":
        field, absent = _ERROR_NAMES.match(row.expected_result.strip()).groups()
        if not _error_names(body, resp.text, field):
            problems.append(f"error does not name '{field}': {resp.text[:200]}")
        if absent in body:
            problems.append(f"{absent} returned ({body[absent]}) although the request was rejected")
    elif kind in ("every_record", "count"):
        try:
            records = extract_records(resp.body)
        except ValueError as e:
            return problems + [str(e)]
        if kind == "every_record":
            field, value = _EVERY_RECORD.match(row.expected_result.strip()).groups()
            if not records:
                problems.append("no records returned - cannot show the filter works")
            wrong = [r for r in records if str(r.get(field)) != value.strip()]
            if wrong:
                problems.append(f"{len(wrong)} of {len(records)} records have another {field}: "
                                f"{sorted({str(r.get(field)) for r in wrong})}")
        else:
            low, high = map(int, _COUNT.match(row.expected_result.strip()).groups())
            if not low <= len(records) <= high:
                problems.append(f"{len(records)} records, expected {low} to {high}")
    elif kind in ("found", "not_found"):
        if resp.is_error:
            problems.append(f"the tool reported an error instead of an answer: {resp.text[:200]}")
        want = kind == "found"
        if body.get("found") is not want:
            problems.append(f"found = {body.get('found')}, expected {want}")
        if want and body.get(row.field) != row.value:
            problems.append(f"{row.field} = {body.get(row.field)}, expected {row.value} (the code sent)")
        for f in detail_fields:
            filled = body.get(f) not in (None, "")
            if filled != want:
                problems.append(f"{f} {'is empty' if want else 'is filled'} ({body.get(f)!r})")
    elif kind == "same_as_full":
        base = baseline.body if baseline and isinstance(baseline.body, dict) else {}
        for f in compared_fields(row.expected_result):
            if f not in base:
                problems.append(f"'{f}' is not in the full-request response - check the field name in Expected Result (Test Data sheet)")
            elif body.get(f) != base.get(f):
                problems.append(f"{f} = {body.get(f)}, full request gave {base.get(f)}")
    return problems


def _error_names(body: dict, text: str, field: str) -> bool:
    """The error points at the field: in a validation error's 'loc' when there is one, else anywhere in the text."""
    detail = body.get("detail")
    if isinstance(detail, list) and detail and all(isinstance(d, dict) and "loc" in d for d in detail):
        return any(field in [str(x) for x in d["loc"]] for d in detail)
    return field in text
