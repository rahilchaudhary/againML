"""Plain-language reading of a component's accuracy summary. Wording and ranges: config/rul_accuracy_report.yaml."""
from __future__ import annotations

INFO, WARNING, ERROR = "INFO", "WARNING", "ERROR"


def basis(summary: dict) -> str:
    return "QA-assumed" if summary.get("qa_threshold_source") == "ASSUMED" else "agreed"


def is_assumed(summary: dict) -> bool:
    return summary.get("qa_threshold_source") == "ASSUMED" or summary.get("qa_reference_life_assumed", False)


def interpret(summary: dict, config: dict) -> list[tuple[str, str, str]]:
    """(topic, severity, message) items, in reading order."""
    msg, m, t = config["messages"], summary["qa_component_metrics"], summary["qa_thresholds"]
    eligible, excluded = m.get("qa_eligible_record_count", 0), m.get("qa_excluded_record_count", 0)
    items = [("Execution", INFO, msg["execution_pass"].format(eligible=eligible))
             if summary["qa_execution_status"] == "PASS" else ("Execution", ERROR, msg["execution_fail"])]
    if m.get("qa_metric_status") != "CALCULATED":
        items.append(("Metrics", ERROR, msg["not_calculated"]))
    else:
        rate, minimum = m["qa_tolerance_pass_rate_pct"], float(t["minimum_pass_rate_pct"])
        key = "tolerance_met" if rate >= minimum else "tolerance_below"
        items.append(("Tolerance", INFO if rate >= minimum else WARNING,
                      msg[key].format(pass_rate=rate, minimum=minimum, basis=basis(summary))))
        diff = m["qa_mean_over_under_prediction_hours"]
        side = "overprediction" if diff > 0 else "underprediction" if diff < 0 else "balanced"
        bias_ok = m["qa_quality_gates"]["mean_over_under"]
        items.append(("Prediction direction", INFO if bias_ok else WARNING, msg[side].format(hours=abs(diff))))
        mae, rmse = m["qa_mae_hours"], m["qa_rmse_hours"]
        if mae > 0:
            spread = rmse / mae >= config["rmse_mae_ratio_warning"]
            items.append(("Error pattern", WARNING if spread else INFO,
                          msg["errors_spread" if spread else "errors_consistent"].format(mae=mae, rmse=rmse)))
        r2 = m.get("qa_r2_score")
        for low, high, text in config["r2_ranges"]:
            if r2 is not None and (low is None or r2 >= low) and (high is None or r2 < high):
                items.append(("Agreement", INFO, text.format(r2=r2)))
                break
    if excluded:
        items.append(("Exclusions", WARNING, msg["exclusions"].format(excluded=excluded)))
    status = m.get("qa_quality_gate_status", "NOT_EVALUATED")
    items.append(("Quality gate", WARNING if status == "FAIL" else INFO, msg["gate"].format(status=status, basis=basis(summary))))
    if is_assumed(summary):
        items.append(("Assumptions", INFO, msg["assumption"]))
    return items
