"""The vehicles of a component and their prediction history - through the fleet service, like every other case."""
from __future__ import annotations

from dataclasses import dataclass, field

from framework.record_source import extract_records


@dataclass(frozen=True)
class History:
    unit_id: str
    url: str
    records: list[dict] = field(default_factory=list)
    error: str = ""             # why the history could not be read; empty = read

    @property
    def ok(self) -> bool:
        return not self.error


def fleet_unit_ids(services, component: str) -> list[str]:
    """Every vehicle of the component, in fleet order, each once."""
    resp = services.fleet.fleet(component)
    if resp.status != 200:
        raise RuntimeError(f"fleet call for {component} returned {resp}")
    return list(dict.fromkeys(str(r["unit_id"]) for r in extract_records(resp.body) if r.get("unit_id")))


def fetch_histories(services, component: str, unit_ids: list[str]) -> list[History]:
    out = []
    for unit in unit_ids:
        resp = services.fleet.history(component, unit)
        if resp.status != 200:
            out.append(History(unit, resp.url, error=f"history call returned HTTP {resp.status}"))
            continue
        try:
            out.append(History(unit, resp.url, extract_records(resp.body)))
        except ValueError as e:                      # the response is not a list of records
            out.append(History(unit, resp.url, error=str(e)))
    return out
