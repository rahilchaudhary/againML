"""RUL accuracy outputs, in reports/rul_accuracy/:

    <component>_summary.json     the summary (metrics, gates, exclusions, per vehicle and cycle)
    <component>_records.csv      one line per history record - the evidence behind every number
    <component>_report.html      charts, gate cards, interpretation (layout: config/rul_accuracy_report.yaml)
    index.html                   every component's report, grouped by system and sub-system

The report shows whether the thresholds and reference lives are QA-assumed or agreed.
"""
from __future__ import annotations

import csv
import html
import json
from collections import defaultdict
from pathlib import Path

from framework.rul_accuracy.evaluator import EXACT, OVER, UNDER
from framework.rul_accuracy.interpretation import basis, interpret, is_assumed

FIRST_COLUMNS = ["unit_id", "vehicle_model", "site", "timestamp", "{age}", "predicted_rul_hours", "rul_lower_hours",
                 "rul_upper_hours", "qa_component", "qa_cycle_id", "qa_observation_sequence", "qa_observation_id",
                 "qa_reference_life_hours", "qa_reference_life_source", "qa_expected_rul_hours",
                 "qa_signed_error_hours", "qa_absolute_error_hours", "qa_prediction_direction",
                 "qa_allowed_error_hours", "qa_record_status", "qa_execution_status", "qa_metric_status",
                 "qa_exclusion_reason", "qa_history_url"]
COLORS = {"PASS": "#167d5b", "FAIL": "#c2413b", OVER: "#7c3aed", UNDER: "#2563eb", EXACT: "#15803d",
          "expected": "#2563eb", "predicted": "#f59e0b", "allowed": "#2563eb", "histogram": "#0f766e"}


# ---------------- evidence ----------------
def write_evidence(out_dir: Path, component: str, summary: dict, rows: list[dict]) -> tuple[Path, Path]:
    out_dir.mkdir(parents=True, exist_ok=True)
    summary_path, records_path = out_dir / f"{component}_summary.json", out_dir / f"{component}_records.csv"
    summary_path.write_text(json.dumps(summary, indent=2, sort_keys=True, default=str), encoding="utf-8")
    first = [c.format(age=summary["qa_age_field"]) for c in FIRST_COLUMNS]
    present = {k for r in rows for k in r}
    columns = [c for c in first if c in present] + sorted(present - set(first))
    with records_path.open("w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=columns, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)
    return summary_path, records_path


# ---------------- component report ----------------
def write_component_report(path: Path, summary: dict, rows: list[dict], config: dict) -> Path:
    from plotly.offline import get_plotlyjs          # imported here: only report writing needs plotly
    report = config["report"]
    used = [r for r in rows if r.get("qa_metric_status") == "CALCULATED"]
    m = summary["qa_component_metrics"]
    charts = "".join(_chart_panel(c, used, summary, report["theme"]) for c in report["charts"] if c.get("enabled", True))
    cards = "".join(_card(field, label, fmt, summary) for field, label, fmt in report["summary_cards"])
    advice = "".join(f'<li class="{sev.lower()}"><strong>{html.escape(topic)}</strong>: {html.escape(text)}</li>'
                     for topic, sev, text in interpret(summary, config["interpretation"]))
    notice = ('<div class="notice"><strong>Assumption notice:</strong> PASS / FAIL uses QA-assumed thresholds or '
              'reference lives, not yet agreed with the ML team.</div>') if is_assumed(summary) else ""
    script = (f"<script>{get_plotlyjs()}</script>" if report.get("embed_chart_library", True)
              else '<script src="https://cdn.plot.ly/plotly-3.1.0.min.js"></script>')
    title = report["title"].format(component=summary["qa_component_display_name"])
    cycles = sorted({r["qa_cycle_id"] for r in used}) or ["N/A"]
    page = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>{html.escape(title)}</title>{script}<style>{REPORT_CSS}</style></head><body><main>
<h1>{html.escape(title)}</h1>
<p class="hierarchy"><strong>Hierarchy:</strong> {html.escape(summary['qa_system'])} &rarr; {html.escape(summary['qa_subsystem'])}
 &rarr; {html.escape(summary['qa_component_display_name'])} &rarr; Cycle ({html.escape(', '.join(cycles))})</p>
<div class="coverage">{''.join(f'<span><strong>{k}:</strong> {v}</span>' for k, v in _coverage(summary).items())}</div>
{_gate_banner(m)}{notice}<div class="cards">{cards}</div>
<section class="panel"><h2>Interpretation</h2><ul class="advice">{advice}</ul></section>
{charts}
<p class="evidence">Evidence: <code>{summary['qa_component']}_summary.json</code> and <code>{summary['qa_component']}_records.csv</code></p>
</main></body></html>"""
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(page, encoding="utf-8")
    return path


def _coverage(summary: dict) -> dict[str, str]:
    fleet = summary.get("qa_vehicles_in_fleet", 0)
    evaluated = sum(v["qa_vehicle_metrics"].get("qa_eligible_record_count", 0) > 0 for v in summary["qa_vehicle_results"])
    return {"Vehicles in fleet": f"{fleet:,}", "With reference life": f"{summary.get('qa_vehicles_with_reference_life', 0):,}",
            "Evaluated": f"{evaluated:,}", "Coverage of fleet": f"{(evaluated / fleet * 100) if fleet else 0:.2f}%"}


def _value(value, fmt: str) -> str:
    if value is None:
        return "N/A"
    return {"integer": f"{int(value):,}", "hours": f"{float(value):,.2f} h", "percent": f"{float(value):,.2f}%",
            "decimal3": f"{float(value):,.3f}"}.get(fmt, str(value))


GATE_OF_CARD = {"qa_tolerance_pass_rate_pct": ("pass_rate", "minimum_pass_rate_pct", "&ge; {}%"),
                "qa_mae_hours": ("mae", "maximum_mae_hours", "&le; {} h"),
                "qa_rmse_hours": ("rmse", "maximum_rmse_hours", "&le; {} h"),
                "qa_mean_over_under_prediction_hours": ("mean_over_under", "maximum_mean_over_under_hours", "&plusmn; {} h")}


def _card(field: str, label: str, fmt: str, summary: dict) -> str:
    m, value = summary["qa_component_metrics"], _value(summary["qa_component_metrics"].get(field), fmt)
    if field not in GATE_OF_CARD:
        return f'<div class="card"><span>{html.escape(label)}</span><strong>{value}</strong></div>'
    gate, limit_key, limit_text = GATE_OF_CARD[field]
    result = m.get("qa_quality_gates", {}).get(gate)
    status = {True: "PASS", False: "FAIL"}.get(result, "NOT EVALUATED")
    return (f'<div class="card gate-{status.split()[0].lower()}"><div class="card-head"><span>{html.escape(label)}</span>'
            f'<b>{status}</b></div><strong>{value}</strong><small>{basis(summary)} limit '
            f'{limit_text.format(summary["qa_thresholds"][limit_key])}</small></div>')


def _gate_banner(m: dict) -> str:
    status = m.get("qa_quality_gate_status", "NOT_EVALUATED")
    gates = m.get("qa_quality_gates", {})
    detail = (f"{sum(gates.values())} of {len(gates)} gates passed" if gates else "not evaluated")
    return (f'<div class="banner gate-{status.split("_")[0].lower()}"><strong>Overall quality gate</strong>'
            f'<b>{status}</b><span>{detail}</span></div>')


# ---------------- charts ----------------
def _hover(r: dict, age_field: str) -> str:
    return (f"Vehicle: {r['unit_id']}<br>Cycle: {r['qa_cycle_id']}<br>Observation: {r['qa_observation_id']}<br>"
            f"Age: {r.get(age_field)} h<br>Expected RUL: {r['qa_expected_rul_hours']:.1f} h<br>"
            f"Predicted RUL: {r['predicted_rul_hours']} h<br>Error: {r['qa_signed_error_hours']:+.1f} h "
            f"(allowed {r['qa_allowed_error_hours']:.1f} h)<br>Record: {r['qa_record_status']}")


def _scatter(go, rows, x, y, name, color, age_field, mode="markers"):
    return go.Scatter(x=[x(r) for r in rows], y=[y(r) for r in rows], mode=mode, name=name,
                      marker={"color": color, "size": 7, "opacity": 0.75},
                      text=[_hover(r, age_field) for r in rows], hovertemplate="%{text}<extra></extra>")


def _chart_panel(chart: dict, rows: list[dict], summary: dict, theme: str) -> str:
    import plotly.graph_objects as go
    age = summary["qa_age_field"]
    t = summary["qa_thresholds"]
    fig = go.Figure()
    exp, pred = (lambda r: r["qa_expected_rul_hours"]), (lambda r: float(r["predicted_rul_hours"]))
    err, age_of = (lambda r: r["qa_signed_error_hours"]), (lambda r: float(r[age]))
    by = lambda key, value: [r for r in rows if r.get(key) == value]                     # noqa: E731
    cid = chart["id"]
    if cid == "expected_vs_predicted":
        for status in ("PASS", "FAIL"):
            fig.add_trace(_scatter(go, by("qa_record_status", status), exp, pred, status, COLORS[status], age))
        top = max([exp(r) for r in rows] + [pred(r) for r in rows] + [1])
        fig.add_trace(go.Scatter(x=[0, top], y=[0, top], mode="lines", name="Perfect agreement",
                                 line={"dash": "dash", "color": COLORS["expected"]}, hoverinfo="skip"))
        axes = ("Expected RUL (hours)", "Predicted RUL (hours)")
    elif cid == "rul_by_age":
        groups = defaultdict(list)
        for r in rows:
            groups[(r["unit_id"], r["qa_cycle_id"])].append(r)
        for (unit, cycle), part in groups.items():
            part = sorted(part, key=age_of)
            fig.add_trace(_scatter(go, part, age_of, exp, f"{unit} {cycle} expected", COLORS["expected"], age, "lines+markers"))
            fig.add_trace(_scatter(go, part, age_of, pred, f"{unit} {cycle} predicted", COLORS["predicted"], age, "lines+markers"))
        axes = ("Component age (hours)", "RUL (hours)")
    elif cid == "over_under_by_age":
        for side in (UNDER, OVER, EXACT):
            fig.add_trace(_scatter(go, by("qa_prediction_direction", side), age_of, err, side.title(), COLORS[side], age))
        fig.add_hline(y=0, line_dash="dash", line_color="#111827")
        axes = ("Component age (hours)", "Over (+) / under (-) prediction (hours)")
    elif cid == "error_vs_allowed":
        seq = list(range(1, len(rows) + 1))
        fig.add_trace(go.Scatter(x=seq, y=[r["qa_absolute_error_hours"] for r in rows], mode="markers", name="Absolute error",
                                 marker={"color": COLORS["FAIL"], "size": 6}, text=[_hover(r, age) for r in rows],
                                 hovertemplate="%{text}<extra></extra>"))
        fig.add_trace(go.Scatter(x=seq, y=[r["qa_allowed_error_hours"] for r in rows], mode="lines", name="Allowed error",
                                 line={"color": COLORS["allowed"], "width": 2}, hoverinfo="skip"))
        axes = ("Record (in history order)", "Hours")
    elif cid == "error_distribution":
        fig.add_trace(go.Histogram(x=[r["qa_absolute_error_hours"] for r in rows], nbinsx=40,
                                   marker_color=COLORS["histogram"], name="Records"))
        axes = ("Absolute error (hours)", "Records")
    elif cid == "error_vs_expected":
        for side in (OVER, UNDER, EXACT):
            fig.add_trace(_scatter(go, by("qa_prediction_direction", side), exp, err, side.title(), COLORS[side], age))
        fig.add_hline(y=0, line_dash="dash", line_color="#111827")
        axes = ("Expected RUL (hours)", "Signed error (hours)")
    else:
        raise ValueError(f"config/rul_accuracy_report.yaml: unknown chart id '{cid}'")
    subtitle = (f"<br><sup>Allowed error: over-prediction max({t['overprediction_absolute_hours']} h, "
                f"{float(t['overprediction_fraction']) * 100:.0f}%), under-prediction max({t['underprediction_absolute_hours']} h, "
                f"{float(t['underprediction_fraction']) * 100:.0f}%) of expected RUL</sup>") if cid == "over_under_by_age" else ""
    fig.update_layout(template=theme, title=chart["title"] + subtitle, xaxis_title=axes[0], yaxis_title=axes[1])
    body = fig.to_html(full_html=False, include_plotlyjs=False, config={"responsive": True, "displaylogo": False})
    return (f'<section class="panel"><p class="question"><strong>Question this chart answers:</strong> '
            f'{html.escape(chart.get("question", ""))}</p>{body}</section>')


# ---------------- index of all component reports ----------------
def write_index(out_dir: Path) -> Path:
    """index.html: every component report found in out_dir, by system and sub-system."""
    grouped = defaultdict(lambda: defaultdict(list))
    for path in sorted(out_dir.glob("*_summary.json")):
        s = json.loads(path.read_text(encoding="utf-8"))
        report = f"{s['qa_component']}_report.html"
        if (out_dir / report).exists():
            grouped[s["qa_system"]][s["qa_subsystem"]].append((s, report))
    sections = []
    for system in sorted(grouped):
        subs = []
        for sub in sorted(grouped[system]):
            cards = []
            for s, report in sorted(grouped[system][sub], key=lambda x: x[0]["qa_component_display_name"]):
                status = s["qa_component_metrics"].get("qa_quality_gate_status", "NOT_EVALUATED")
                facts = "".join(f"<div><span>{k}</span><strong>{v}</strong></div>" for k, v in _coverage(s).items())
                cards.append(f'<article class="component"><div class="head"><h4>{html.escape(s["qa_component_display_name"])}</h4>'
                             f'<b class="gate-{status.split("_")[0].lower()}">{status}</b></div><div class="facts">{facts}</div>'
                             f'<p class="basis">Thresholds: {basis(s)}</p><a href="{html.escape(report)}">Open report</a></article>')
            subs.append(f'<section class="sub"><h3>{html.escape(sub)}</h3><div class="grid">{"".join(cards)}</div></section>')
        sections.append(f'<section class="system"><h2>{html.escape(system)}</h2>{"".join(subs)}</section>')
    body = "".join(sections) or '<section class="system"><h2>No reports yet</h2></section>'
    page = f"""<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>RUL Accuracy Reports</title><style>{INDEX_CSS}</style></head><body><main>
<header><h1>RUL Accuracy Reports</h1><p>One report per component, by system and sub-system. Accuracy is
measured per component; nothing is rolled up across components.</p></header>{body}</main></body></html>"""
    path = out_dir / "index.html"
    path.write_text(page, encoding="utf-8")
    return path


# ---------------- styles ----------------
_STATUS_CSS = (".gate-pass{border-left-color:#16a34a}.gate-fail{border-left-color:#dc2626}.gate-not{border-left-color:#64748b}"
               ".gate-pass b,b.gate-pass{background:#16a34a}.gate-fail b,b.gate-fail{background:#dc2626}"
               ".gate-not b,b.gate-not{background:#64748b}")
REPORT_CSS = ("body{font-family:Arial,sans-serif;background:#f5f7fb;color:#172033;margin:0}"
              "main{max-width:1220px;margin:auto;padding:28px}h1{margin:0 0 8px}.hierarchy{color:#475569}"
              ".coverage{display:flex;gap:10px;flex-wrap:wrap;margin:0 0 14px}"
              ".coverage span{background:#eef2f7;border-radius:6px;padding:7px 9px;color:#475569;font-size:12px}"
              ".banner{display:flex;align-items:center;gap:10px;background:#fff;border:1px solid #dce3ed;"
              "border-left:4px solid;border-radius:8px;padding:10px 12px;margin-bottom:14px}"
              ".banner b,.card-head b{padding:3px 8px;border-radius:999px;color:#fff;font-size:11px}"
              ".notice{background:#fff7d6;border-left:5px solid #d69e00;padding:12px 14px;margin:0 0 16px}"
              ".cards{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:12px;margin-bottom:16px}"
              "@media(max-width:900px){.cards{grid-template-columns:repeat(2,minmax(0,1fr))}}"
              "@media(max-width:560px){.cards{grid-template-columns:1fr}}"
              ".card{background:#fff;border:1px solid #dce3ed;border-left:4px solid #94a3b8;border-radius:10px;padding:14px}"
              ".card span{color:#64748b;font-size:12px;text-transform:uppercase}.card strong{display:block;font-size:26px;margin:8px 0}"
              ".card small{color:#64748b}.card-head{display:flex;justify-content:space-between}"
              ".panel{background:#fff;border:1px solid #dce3ed;border-radius:10px;padding:15px;margin-bottom:18px}"
              ".advice li{margin:8px 0;line-height:1.45}.advice li.warning{color:#8a4b08}.advice li.error{color:#a51d27}"
              ".question{margin:0 0 8px;padding:9px 11px;background:#f8fafc;border-left:3px solid #3b82f6;color:#475569}"
              "code{background:#eef2f7;padding:2px 5px;border-radius:4px}" + _STATUS_CSS)
INDEX_CSS = ("body{font-family:Arial,sans-serif;background:#f4f7fb;color:#172033;margin:0}"
             "main{max-width:1080px;margin:auto;padding:32px 22px}header{background:#0f3d66;color:#fff;border-radius:14px;"
             "padding:24px;margin-bottom:20px}header p{color:#dcecf8;margin:0}"
             ".system{background:#fff;border:1px solid #dce3ed;border-radius:12px;padding:20px;margin:18px 0}"
             ".sub{border-top:1px solid #e5eaf1;padding-top:12px}.grid{display:grid;"
             "grid-template-columns:repeat(auto-fit,minmax(260px,1fr));gap:14px}"
             ".component{border:1px solid #dce3ed;border-radius:10px;padding:16px;background:#fbfdff}"
             ".head{display:flex;justify-content:space-between;align-items:flex-start}.head h4{margin:0}"
             ".head b{padding:4px 9px;border-radius:999px;color:#fff;font-size:11px}"
             ".facts{display:grid;grid-template-columns:repeat(2,1fr);gap:8px;margin:14px 0}"
             ".facts span{display:block;color:#64748b;font-size:10px;text-transform:uppercase}.basis{color:#64748b;font-size:12px}"
             "a{display:inline-block;background:#1d5b8f;color:#fff;text-decoration:none;border-radius:7px;padding:8px 12px}"
             + _STATUS_CSS)
