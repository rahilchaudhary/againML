"""RUL accuracy: how close predicted RUL is to the RUL expected from a known end of life (reference life).

    reference_life.py   ground truth per vehicle and cycle (testdata/reference_life/<component>.csv)
    history.py          the vehicles and their prediction history, through the fleet service
    evaluator.py        per record: expected RUL, error, allowed error; per component/vehicle/cycle: metrics, gates
    interpretation.py   plain-language reading of the metrics (rules in config/rul_accuracy_report.yaml)
    report.py           evidence (JSON, CSV), the HTML report per component, the index page

Used by test case R-01 (tests/test_rul_accuracy.py). Requirements per component: config/components/<name>.yaml.
"""
