"""The RUL accuracy calculation. Plain functions: records in, numbers out - no API, no files.

Per history record of a vehicle with a reference life:
    expected RUL   = reference life - component age
    signed error   = predicted RUL - expected RUL          (+ over-prediction, - under-prediction)
    allowed error  = max(absolute hours, expected RUL x fraction), with the over- or under-prediction limits
    record status  = PASS if |signed error| <= allowed error
Per component, vehicle and cycle: MAE, RMSE, mean over/under, R2, % of records within the allowed error,
and four quality gates (pass rate, MAE, RMSE, mean over/under). All four pass = the component passes.

Every history record is kept, also repeated ones (each gets its own observation ID). A record that cannot be
evaluated is kept with the reason, and counted as excluded - never silently dropped.
QA-added fields start with qa_, so they never clash with the API's own fields.
"""
from __future__ import annotations

import hashlib
import json
import math
from collections import Counter, defaultdict
from statistics import mean

from framework.rul_accuracy.history import History
from framework.rul_accuracy.reference_life import ReferenceLife

OVER, UNDER, EXACT = "OVERPREDICTION", "UNDERPREDICTION", "EXACT"
CALCULATED, NOT_CALCULATED = "CALCULATED", "NOT_CALCULATED"
GATES = ("pass_rate", "mae", "rmse", "mean_over_under")


def direction(signed_error: float) -> str:
    return OVER if signed_error > 0 else UNDER if signed_error < 0 else EXACT


def allowed_error(expected_rul: float, signed_error: float, thresholds: dict) -> float:
    side = "overprediction" if signed_error > 0 else "underprediction"
    return max(float(thresholds[f"{side}_absolute_hours"]), expected_rul * float(thresholds[f"{side}_fraction"]))


def _observation_id(component: str, unit: str, cycle: str, sequence: int, record: dict, seen: Counter) -> str:
    digest = hashlib.sha256(json.dumps(record, sort_keys=True, default=str).encode()).hexdigest()[:12]
    seen[digest] += 1
    return f"{component}__{unit}__{cycle}__{sequence:06d}__{digest}__{seen[digest]:02d}"


def prepare_rows(component: str, accuracy: dict, histories: list[History],
                 lives: dict[tuple[str, str], ReferenceLife]) -> list[dict]:
    """One row per history record (or one row per vehicle whose history could not be read)."""
    age_field, cycle, thresholds = accuracy["age_field"], accuracy["cycle_id"], accuracy["thresholds"]
    rows = []
    for h in histories:
        base = {"unit_id": h.unit_id, "qa_component": component, "qa_cycle_id": cycle, "qa_history_url": h.url}
        if not h.ok:
            rows.append({**base, "qa_execution_status": "FAIL", "qa_metric_status": NOT_CALCULATED,
                         "qa_exclusion_reason": h.error})
            continue
        seen: Counter = Counter()
        life = lives.get((h.unit_id, cycle))
        for sequence, record in enumerate(h.records, start=1):
            row = {**record, **base, "qa_observation_sequence": sequence,
                   "qa_observation_id": _observation_id(component, h.unit_id, cycle, sequence, record, seen),
                   "qa_execution_status": "PASS"}
            rows.append(row)
            if life is None:
                row.update(qa_metric_status=NOT_CALCULATED, qa_exclusion_reason="NO_REFERENCE_LIFE")
                continue
            try:
                age, predicted = float(record[age_field]), float(record["predicted_rul_hours"])
            except KeyError as e:
                row.update(qa_execution_status="FAIL", qa_metric_status=NOT_CALCULATED,
                           qa_exclusion_reason=f"MISSING_FIELD:{e.args[0]}")
                continue
            except (TypeError, ValueError):
                row.update(qa_execution_status="FAIL", qa_metric_status=NOT_CALCULATED,
                           qa_exclusion_reason="NOT_A_NUMBER")
                continue
            expected = life.hours - age
            if expected < 0:
                row.update(qa_metric_status=NOT_CALCULATED, qa_exclusion_reason="AGE_BEYOND_REFERENCE_LIFE")
                continue
            signed = predicted - expected
            allowed = allowed_error(expected, signed, thresholds)
            row.update(qa_reference_life_hours=life.hours, qa_reference_life_source=life.source,
                       qa_expected_rul_hours=expected, qa_signed_error_hours=signed,
                       qa_absolute_error_hours=abs(signed), qa_prediction_direction=direction(signed),
                       qa_allowed_error_hours=allowed,
                       qa_record_status="PASS" if abs(signed) <= allowed else "FAIL",
                       qa_metric_status=CALCULATED, qa_exclusion_reason="")
    return rows


def metrics(rows: list[dict], thresholds: dict) -> dict:
    """Metrics and gates over a set of rows (a component, a vehicle or a cycle)."""
    used = [r for r in rows if r.get("qa_metric_status") == CALCULATED]
    if not used:
        return {"qa_metric_status": NOT_CALCULATED, "qa_quality_gate_status": "NOT_EVALUATED",
                "qa_eligible_record_count": 0, "qa_excluded_record_count": len(rows)}
    errors = [r["qa_signed_error_hours"] for r in used]
    expected = [r["qa_expected_rul_hours"] for r in used]
    within = sum(r["qa_record_status"] == "PASS" for r in used)
    pass_rate = within / len(used) * 100
    mae = mean(abs(e) for e in errors)
    rmse = math.sqrt(mean(e * e for e in errors))
    mean_over_under = mean(errors)
    spread = sum((x - mean(expected)) ** 2 for x in expected)
    r2 = None if len(used) < 2 or spread == 0 else 1 - sum(e * e for e in errors) / spread

    def rate(side):
        part = [r for r in used if r["qa_prediction_direction"] == side]
        return (sum(r["qa_record_status"] == "PASS" for r in part) / len(part) * 100) if part else None

    gates = {"pass_rate": pass_rate >= float(thresholds["minimum_pass_rate_pct"]),
             "mae": mae <= float(thresholds["maximum_mae_hours"]),
             "rmse": rmse <= float(thresholds["maximum_rmse_hours"]),
             "mean_over_under": abs(mean_over_under) <= float(thresholds["maximum_mean_over_under_hours"])}
    return {"qa_metric_status": CALCULATED,
            "qa_quality_gate_status": "PASS" if all(gates.values()) else "FAIL",
            "qa_quality_gates": gates,
            "qa_eligible_record_count": len(used), "qa_excluded_record_count": len(rows) - len(used),
            "qa_records_within_tolerance": within, "qa_records_outside_tolerance": len(used) - within,
            "qa_tolerance_pass_rate_pct": pass_rate,
            "qa_overprediction_record_count": sum(r["qa_prediction_direction"] == OVER for r in used),
            "qa_underprediction_record_count": sum(r["qa_prediction_direction"] == UNDER for r in used),
            "qa_overprediction_pass_rate_pct": rate(OVER), "qa_underprediction_pass_rate_pct": rate(UNDER),
            "qa_mae_hours": mae, "qa_rmse_hours": rmse, "qa_mean_over_under_prediction_hours": mean_over_under,
            "qa_r2_score": r2}


def evaluate(rows: list[dict], accuracy: dict) -> dict:
    """The component's summary: metrics, gates, exclusions, and the same per vehicle and per cycle."""
    thresholds = accuracy["thresholds"]
    excluded = [r for r in rows if r.get("qa_metric_status") != CALCULATED]
    by_vehicle, by_cycle = defaultdict(list), defaultdict(list)
    for r in rows:
        by_vehicle[r["unit_id"]].append(r)
        by_cycle[(r["unit_id"], r["qa_cycle_id"])].append(r)
    return {
        "qa_execution_status": "FAIL" if any(r.get("qa_execution_status") == "FAIL" for r in rows) else "PASS",
        "qa_threshold_source": accuracy["threshold_source"],
        "qa_thresholds": dict(thresholds),
        "qa_age_field": accuracy["age_field"],
        "qa_component_metrics": metrics(rows, thresholds),
        "qa_exclusion_summary": dict(sorted(Counter(r.get("qa_exclusion_reason") or "UNSPECIFIED" for r in excluded).items())),
        "qa_excluded_records": [{k: r.get(k, "") for k in ("unit_id", "qa_cycle_id", "qa_observation_id", "timestamp",
                                                            accuracy["age_field"], "qa_exclusion_reason", "qa_history_url")}
                                for r in excluded],
        "qa_vehicle_results": [
            {"unit_id": unit, "qa_vehicle_metrics": metrics(vrows, thresholds),
             "qa_cycle_results": [{"qa_cycle_id": cycle, "qa_cycle_metrics": metrics(crows, thresholds)}
                                  for (u, cycle), crows in sorted(by_cycle.items()) if u == unit]}
            for unit, vrows in sorted(by_vehicle.items())],
    }


def gate_problems(summary: dict) -> list[str]:
    """The failed gates in words, with the value and the limit."""
    m, t = summary["qa_component_metrics"], summary["qa_thresholds"]
    if m.get("qa_metric_status") != CALCULATED:
        return []
    text = {"pass_rate": f"{m['qa_tolerance_pass_rate_pct']:.1f}% of records within the allowed error, "
                         f"minimum {t['minimum_pass_rate_pct']}%",
            "mae": f"MAE {m['qa_mae_hours']:.1f} h, maximum {t['maximum_mae_hours']} h",
            "rmse": f"RMSE {m['qa_rmse_hours']:.1f} h, maximum {t['maximum_rmse_hours']} h",
            "mean_over_under": f"mean over/under-prediction {m['qa_mean_over_under_prediction_hours']:+.1f} h, "
                               f"limit +/-{t['maximum_mean_over_under_hours']} h"}
    return [text[g] for g in GATES if not m["qa_quality_gates"][g]]
