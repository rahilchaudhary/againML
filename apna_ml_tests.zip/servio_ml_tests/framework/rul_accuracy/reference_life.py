"""Reference lives: the known end of life of a component on a vehicle - the ground truth for RUL accuracy.

File: testdata/reference_life/<component>.csv (location in config/settings.yaml, reference_lives)
    unit_id,cycle_id,reference_life_hours,source
    RAD-047,CYCLE-01,3100,ASSUMED
A cycle is one life of the component on that vehicle; a replaced component starts a new cycle.
"""
from __future__ import annotations

import csv
from dataclasses import dataclass
from pathlib import Path

COLUMNS = ("unit_id", "cycle_id", "reference_life_hours", "source")


class ReferenceLifeError(ValueError):
    """The reference-life file cannot be used as it is."""


@dataclass(frozen=True)
class ReferenceLife:
    unit_id: str
    cycle_id: str
    hours: float
    source: str                 # ASSUMED, or where the life came from


def load_reference_lives(path: Path) -> dict[tuple[str, str], ReferenceLife]:
    """(unit_id, cycle_id) -> ReferenceLife. Stops on a missing column, a bad value or a duplicate key."""
    lives: dict[tuple[str, str], ReferenceLife] = {}
    with Path(path).open(newline="", encoding="utf-8-sig") as f:
        reader = csv.DictReader(f)
        missing = [c for c in COLUMNS if c not in (reader.fieldnames or [])]
        if missing:
            raise ReferenceLifeError(f"{Path(path).name}: missing columns {missing}")
        for line, row in enumerate(reader, start=2):
            if not any((v or "").strip() for v in row.values()):
                continue
            where = f"{Path(path).name} line {line}"
            unit, cycle = row["unit_id"].strip(), row["cycle_id"].strip()
            try:
                hours = float(row["reference_life_hours"])
            except (TypeError, ValueError):
                raise ReferenceLifeError(f"{where}: reference_life_hours {row['reference_life_hours']!r} is not a number") from None
            if not unit or not cycle or hours <= 0:
                raise ReferenceLifeError(f"{where}: unit_id and cycle_id are required, and the life must be above 0")
            if (unit, cycle) in lives:
                raise ReferenceLifeError(f"{where}: {unit} {cycle} appears twice")
            lives[(unit, cycle)] = ReferenceLife(unit, cycle, hours, (row["source"] or "").strip().upper())
    return lives
