"""Auth: how the tests log in to each API. Secrets come from environment variables only -
never from config, the workbook or the repository.

    login        SERVIO_EMAIL, SERVIO_PASSWORD   (use a fleet_manager test user, not admin)
    n8n_api_key  N8N_API_KEY                      (sent as X-N8N-API-KEY, executions API only)
"""
from __future__ import annotations

import os

import pytest


def _env(*names: str) -> list[str]:
    missing = [n for n in names if not os.environ.get(n)]
    if missing:
        pytest.fail(f"Prerequisite failed: set the environment variable(s) {', '.join(missing)} "
                    f"(never put credentials in config or the workbook)", pytrace=False)
    return [os.environ[n] for n in names]


def credentials() -> tuple[str, str]:
    """The test user for the Fleet RUL API and its UI."""
    email, password = _env("SERVIO_EMAIL", "SERVIO_PASSWORD")
    return email, password


def servio_login(client) -> None:
    """Log in once through the Auth service; the session keeps the cookie."""
    from framework.services.auth_service import AuthService      # avoids an import loop
    email, password = credentials()
    resp = AuthService(client).login(email, password)
    if resp.status >= 400 or not client.http.cookies:
        pytest.fail(f"Prerequisite failed: login as {email} did not give a session (HTTP {resp.status}). "
                    f"Check SERVIO_EMAIL / SERVIO_PASSWORD.", pytrace=False)


def n8n_api_key_header() -> dict[str, str]:
    (key,) = _env("N8N_API_KEY")
    return {"X-N8N-API-KEY": key}


LOGINS = {"login": servio_login}
