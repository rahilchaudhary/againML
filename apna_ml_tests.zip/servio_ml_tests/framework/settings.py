"""Settings: run settings, component requirements and the component hierarchy.

Only loads and exposes facts from config/. No HTTP, no test case workbook, no test logic.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import yaml

ROOT = Path(__file__).resolve().parent.parent

CRITICAL, WATCH, HEALTHY = "CRITICAL", "WATCH", "HEALTHY"


class ConfigError(ValueError):
    """Something in config/ is missing or inconsistent."""


RUL_ACCURACY_KEYS = ("age_field", "cycle_id", "threshold_source", "thresholds")
RUL_THRESHOLD_KEYS = ("overprediction_absolute_hours", "overprediction_fraction", "underprediction_absolute_hours",
                      "underprediction_fraction", "minimum_pass_rate_pct", "maximum_mae_hours",
                      "maximum_rmse_hours", "maximum_mean_over_under_hours")


@dataclass(frozen=True)
class ComponentProfile:
    """One component's requirements (config/components/<name>.yaml)."""
    name: str
    critical_cut_off: float
    watch_cut_off: float
    mandatory_fields: tuple[str, ...]
    optional_fields: tuple[str, ...]
    rul_accuracy: dict | None = None     # R-01 settings; None = not set up for this component yet

    def expected_risk(self, rul_lower_hours: float) -> str:
        if rul_lower_hours < self.critical_cut_off:
            return CRITICAL
        if rul_lower_hours < self.watch_cut_off:
            return WATCH
        return HEALTHY

    @classmethod
    def load(cls, name: str) -> "ComponentProfile":
        path = ROOT / "config" / "components" / f"{name}.yaml"
        if not path.exists():
            raise ConfigError(f"Component '{name}' is in the hierarchy but {path} is missing")
        raw = yaml.safe_load(path.read_text())
        try:
            accuracy = raw.get("rul_accuracy")
            if accuracy is not None:
                missing = ([k for k in RUL_ACCURACY_KEYS if k not in accuracy]
                           + [f"thresholds.{k}" for k in RUL_THRESHOLD_KEYS if k not in accuracy.get("thresholds", {})])
                if missing:
                    raise ConfigError(f"{path.name}: rul_accuracy is missing {missing}")
            return cls(name=name,
                       critical_cut_off=float(raw["cut_offs"]["critical"]),
                       watch_cut_off=float(raw["cut_offs"]["watch"]),
                       mandatory_fields=tuple(raw["mandatory_fields"]),
                       optional_fields=tuple(raw["optional_fields"]),
                       rul_accuracy=accuracy)
        except KeyError as e:
            raise ConfigError(f"{path.name}: missing {e}") from None


@dataclass(frozen=True)
class ApiSettings:
    """One API under test (apis: + environments: in config/settings.yaml)."""
    name: str
    base_url: str
    swagger_file: Path | None = None     # pinned OpenAPI description
    tools_file: Path | None = None       # pinned MCP tool list
    auth: str | None = None              # login | n8n_api_key | None

    @property
    def address_missing(self) -> bool:
        return "FILL-IN" in self.base_url


AUTH_KINDS = ("login", "n8n_api_key")


class Settings:
    def __init__(self, env: str | None = None):
        raw = yaml.safe_load((ROOT / "config" / "settings.yaml").read_text())
        self.env = env or raw["environment"]
        if self.env not in raw["environments"]:
            raise ConfigError(f"Unknown environment '{self.env}'. Known: {list(raw['environments'])}")
        env_raw = raw["environments"][self.env]
        self.apis: dict[str, ApiSettings] = {}
        for name, api in raw["apis"].items():
            if name not in env_raw:
                raise ConfigError(f"Environment '{self.env}' has no address for API '{name}'")
            pinned = {}
            for key in ("swagger", "tools"):
                if api.get(key):
                    pinned[key] = ROOT / api[key]
                    if not pinned[key].exists():
                        raise ConfigError(f"API '{name}': pinned file not found: {pinned[key]}")
            if api.get("auth") and api["auth"] not in AUTH_KINDS:
                raise ConfigError(f"API '{name}': auth '{api['auth']}' is not one of {AUTH_KINDS}")
            self.apis[name] = ApiSettings(name, env_raw[name].rstrip("/"), pinned.get("swagger"),
                                          pinned.get("tools"), api.get("auth"))
        self.workflow_ids: dict[str, str] = env_raw.get("workflow_ids", {})
        self._reference_lives: str = env_raw.get("reference_lives") or raw["reference_lives"]
        self.flows: dict = yaml.safe_load((ROOT / "config" / "flows.yaml").read_text())
        self.excel: Path = ROOT / raw["excel"]
        self.record_sources: dict[str, dict] = raw["record_sources"]
        self.just_below_step: float = float(raw["just_below_step"])
        size = raw.get("vehicle_sample_size")
        self.vehicle_sample_size: int | None = int(size) if size else None
        self.hierarchy: dict[str, dict[str, list[str]]] = raw["hierarchy"]
        self.display_names: dict[str, str] = raw.get("display_names") or {}
        self.components: dict[str, ComponentProfile] = {
            name: ComponentProfile.load(name)
            for subsystems in self.hierarchy.values()
            for names in subsystems.values()
            for name in names}

    def place_of(self, component: str) -> tuple[str, str]:
        """(system, sub-system) of a component, from the hierarchy."""
        for system, subsystems in self.hierarchy.items():
            for subsystem, names in subsystems.items():
                if component in names:
                    return system, subsystem
        raise ConfigError(f"Component '{component}' is not in the hierarchy in config/settings.yaml - "
                          f"onboard it first (README 6.1)")

    def reference_lives_file(self, component: str) -> Path:
        return ROOT / self._reference_lives.format(component=component)

    def display(self, name: str) -> str:
        """How reports show a system, sub-system or component name."""
        return self.display_names.get(name, name)

    def components_in_scope(self, system: str | None = None, subsystem: str | None = None,
                            component: str | None = None) -> list[str]:
        """Narrow the hierarchy by whatever the user passed at run time."""
        systems = self.hierarchy
        if system:
            if system not in systems:
                raise ConfigError(f"Unknown system '{system}'. Known: {list(systems)}")
            systems = {system: systems[system]}
        found = []
        for subs in systems.values():
            for sub_name, names in subs.items():
                if subsystem and sub_name != subsystem:
                    continue
                found += names
        if subsystem and not found:
            raise ConfigError(f"Unknown sub-system '{subsystem}' in the chosen system")
        if component:
            if component not in found:
                raise ConfigError(f"Component '{component}' is not in the chosen system/sub-system")
            found = [component]
        return found
